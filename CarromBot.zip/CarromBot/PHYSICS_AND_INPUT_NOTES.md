# Physics + finger input (what changed)

* Physics (cpp/brain.cpp) now follows the game's own model, in game units (playing field = 68 units wide):
  striker speed = power * 120 u/s (power 0.24..1.0); a piece first slides (friction 196 u/s^2, gains spin) and
  then rolls with a CONSTANT slow-down of 11 u/s^2 (distance grows with speed^2); cushion keeps 76 % of the
  normal speed; piece/piece = equal masses. Full power rolls about 5 board lengths, power 0.5 about 1.3.
* Finger (input/InputInjector.drag): press -> slow pull -> [read the game's aim arrow and correct angle/power]
  -> hold -> release. Timings per speed profile in engine/SpeedProfile (MEDIUM = 0.12 s / 0.45 s / 0.20 s).
  If the system cancels the gesture it is retried once.
* Not in the source and therefore still measured / assumed: pocket capture radius (taken from the screen),
  px-per-unit scale (field width / 68), power <-> pull length (linear, checked live through the arrow).

## Learned from the full reference source (logic only, no memory access)
* Power gauge is NOT linear:  shot speed = (1 - sqrt(1 - gauge)) * 120.  engine/ShotPlanner.gaugeForSpeed()/
  speedForGauge() convert; the finger pulls `gauge * dragFull * fieldWidth`, the aim assistant converts the
  arrow length back to speed before simulating.  Half pull = 29 % speed, 80 % pull = 55 %, full pull = 100 %.
* Pockets: within 3.3 units a pocket pulls a piece toward its centre (a = 120 * distance), closer than ~2.2 units
  it drops.  The simulator uses exactly this rule.
* Striker may slide +-22 units on its baseline (about 20 % .. 80 % of the field width): the planner uses it.
* Physics tick of the game is 0.002 s; our integrator uses an adaptive step (<= 1/60 s).

## Rules + safety + prediction controls (latest)
* Game mode (menu): DISC POOL / CARROM / FREESTYLE.  Disc pool & carrom: black and RED are targets, white is an obstacle,
  the LAST black may not drop before the red (the simulator flags it as a foul and the planner never picks it).
  Freestyle: every piece scores (black 10, white 20, red 50).
* Opening (all pieces in one pile): full-power break from the best spot, never a soft tap.
* Physics friction scale 1.2 (GameConfig.frictionScale): shots stop a little sooner than the perfect model, so the
  planner picks stronger shots (pieces no longer die right next to the hole). A shot must still pot with 20 % less power.
* Finger safety: every gesture chain ends with a lift; InputInjector.panicLift() clears a stuck touch (a finger left
  down froze the game screen).
* Auto Queue and its taught screen macros were removed.
* Shot Preview Mode: OFF hides trajectory lines; FREEZE captures the first stable aim in a drag and keeps that line fixed;
  FOLLOW updates the simulated path continuously with the live aim arrow. Highlight Pockets independently controls pot markers.
* Menu access: floating icon is optional. On Android 11+ the accessibility service can optionally open the menu with a
  three-finger single tap; this uses Android's system multi-finger gesture recognizer rather than a touch-blocking overlay.
