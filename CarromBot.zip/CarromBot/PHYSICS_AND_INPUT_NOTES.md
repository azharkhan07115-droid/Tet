# Physics + finger input (what changed)

* Physics (cpp/brain.cpp) now follows the game's own model, in game units (playing field = 68 units wide):
  striker speed = power * 120 u/s (power 0.24..1.0); a piece first slides (friction 196 u/s^2, gains spin) and
  then rolls with a CONSTANT slow-down of 11 u/s^2 (distance grows with speed^2); cushion keeps 76 % of the
  normal speed; piece/piece = equal masses. Full power rolls about 5 board lengths, power 0.5 about 1.3.
* Finger (input/InputInjector.drag): press -> slow pull -> [read the game's aim arrow and correct angle/power]
  -> hold -> release. Timings per speed profile in engine/SpeedProfile (MEDIUM = 0.12 s / 0.45 s / 0.20 s).
  If the system cancels the gesture it is retried once.
* Not in the source and therefore still measured / assumed: pocket capture radius (taken from the screen),
  px-per-unit scale (field width / 68), power <-> pull length (linear, checked live through the arrow).
