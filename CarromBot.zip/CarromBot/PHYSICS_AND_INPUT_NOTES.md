# Physics + finger input (what changed)

* Physics (cpp/brain.cpp) now follows the game's own model, in game units (playing field = 68 units wide):
  striker speed = power * 120 u/s (power 0.24..1.0); a piece first slides (friction 196 u/s^2, gains spin) and
  then rolls with a CONSTANT slow-down of 11 u/s^2 (distance grows with speed^2); cushion keeps 76 % of the
  normal speed; piece/piece = equal masses. Full power rolls about 5 board lengths, power 0.5 about 1.3.
* Finger (input/InputInjector.drag): press -> slow pull -> [read the game's aim arrow and correct angle/power]
  -> hold -> release. Timings per speed profile in engine/SpeedProfile (MEDIUM = 0.12 s / 0.45 s / 0.20 s).
  If the system cancels the gesture it is retried once.
* Not in the source and therefore still measured / assumed: pocket capture radius (taken from the screen),
  px-per-unit scale (field width / 68), power <-> pull length (linear, checked live through the arrow).

## Learned from the full reference source (logic only, no memory access)
* Power gauge is NOT linear:  shot speed = (1 - sqrt(1 - gauge)) * 120.  engine/ShotPlanner.gaugeForSpeed()/
  speedForGauge() convert; the finger pulls `gauge * dragFull * fieldWidth`, the aim assistant converts the
  arrow length back to speed before simulating.  Half pull = 29 % speed, 80 % pull = 55 %, full pull = 100 %.
* Pockets: within 3.3 units a pocket pulls a piece toward its centre (a = 120 * distance), closer than ~2.2 units
  it drops.  The simulator uses exactly this rule.
* Striker may slide +-22 units on its baseline (about 20 % .. 80 % of the field width): the planner uses it.
* Physics tick of the game is 0.002 s; our integrator uses an adaptive step (<= 1/60 s).
