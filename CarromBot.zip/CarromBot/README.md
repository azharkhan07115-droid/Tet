# CarromBot — Android Automation Research Tool

## Setup
1. Open in Android Studio
2. OpenCV 4.9.0 Maven Central se automatically aata hai (org.opencv:opencv:4.9.0)
3. Sync Gradle → Build Debug APK
4. Install APK
5. Grant: Overlay, Accessibility, Notification
6. Launch Carrom Pool → Start Floating Menu

## Bot Guards
- Only works when `com.miniclip.carrom` is in foreground
- Other apps → bot auto-pauses
- Off toggle → no action anywhere

## Disclaimer
Educational / research use only.
