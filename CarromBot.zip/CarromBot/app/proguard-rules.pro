# ---- R8 / ProGuard rules ----
# Goal: shrink + rename (obfuscate) everything we can, and keep ONLY what must keep its
# original name to keep working. The previous "-keep class com.carrombot.tool.** { *; }"
# exempted the entire app from obfuscation, which defeats the point - removed.

# JNI binds these by exact "Java_<package>_<Class>_<method>" symbol name, so the declaring
# classes and their native methods must not be renamed, or the .so can't find them at runtime.
-keepclasseswithmembernames,includedescriptorclasses class * {
    native <methods>;
}
-keep class com.carrombot.tool.auth.NativeAuth { *; }
-keep class com.carrombot.tool.vision.NativeVision { *; }
-keep class com.carrombot.tool.engine.NativeBrain { *; }

# Activities / Services / the Application class declared in AndroidManifest.xml are already
# kept automatically by the Android Gradle Plugin's built-in rules - no manual -keep needed.

# Standard Android hygiene.
-keepattributes *Annotation*
-keepattributes SourceFile,LineNumberTable   # keeps real line numbers in crash stack traces
-renamesourcefileattribute SourceFile        # ...without leaking real file names
-dontwarn org.opencv.**
