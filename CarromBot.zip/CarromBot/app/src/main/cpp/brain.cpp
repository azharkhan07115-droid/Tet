#include "brain.h"
#include <algorithm>
#include <cmath>

namespace carrom {
namespace {

struct Weights { float mine, queen, opp, striker, minCos, contact; };
// Only BLACK (my) pieces are targets. White and red are obstacles: potting them or even touching them costs points.
Weights weightsFor(int mode) {
    if (mode == 1) return {10, -6, -8, -20, 0.25f, 5.0f};   // AGGRO: wider cuts, same rules
    if (mode == 2) return {10, -6, -8, -20, 0.35f, 6.0f};   // PRO
    return {10, -6, -10, -20, 0.55f, 7.0f};                 // SAFE: only clean shots
}

float scoreOf(const SimOut& o, const Weights& w) {
    float s = o.potMine * w.mine + o.potQueen * w.queen + o.potOpp * w.opp - o.contacts * w.contact;
    if (o.strikerPotted) s += w.striker;
    return s;
}

inline float clampf(float v, float lo, float hi) { return std::max(lo, std::min(hi, v)); }

}  // namespace

// ------------------------------------------------------------------------------------------------------
//  Physics = the game's own model (units of the game board: the playing field is 68 units wide):
//   - striker speed = power * 120 units/s            (power 0.24 .. 1.0)
//   - a piece first SLIDES (friction 196 u/s^2 until the contact point stops: it gains spin), then ROLLS and
//     slows down at a CONSTANT 11 u/s^2   (so the distance grows with the SQUARE of the speed, not linearly)
//   - piece/piece: equal masses, normals exchanged     - cushion: normal speed * 0.76
// ------------------------------------------------------------------------------------------------------
namespace {

struct Body { double x, y, vx, vy, sx, sy, r; bool gone; };

inline void calcVelocity(Body& b, double dt) {
    if (b.vx * b.vx + b.vy * b.vy < 1e-8 && b.sx * b.sx + b.sy * b.sy < 1e-8) return;
    const double r = b.r;
    const double relY = r * b.sx - b.vy;
    const double relX = -b.vx - b.sy * r;
    const double sl = std::sqrt(relX * relX + relY * relY);
    const double eq = sl * 0.0008789064581287676;                    // time until the sliding stops
    if (sl > 1e-9 && eq > 1e-5) {
        const double d = std::min(eq, dt);
        const double factor = 196.0 * d / sl;
        const double dvx = relX * factor, dvy = relY * factor;
        b.vx += dvx; b.vy += dvy;
        b.sx -= dvy * (2.5 / r);
        b.sy += dvx * (2.5 / r);
    }
    if (eq < dt) {                                                   // rolling: constant deceleration
        const double speed = std::sqrt(b.vx * b.vx + b.vy * b.vy);
        if (speed > 1e-9) {
            double scale = 1.0 - ((dt - eq) * 11.0 / speed);
            if (scale < 0) scale = 0;
            if (scale > 1) scale = 1;
            b.vx *= scale; b.vy *= scale;
            b.sx = b.vy / r; b.sy = -b.vx / r;
        }
    }
}

}  // namespace

// distance (game units) a lone striker rolls before it stops, for a given power (no walls)
static double stopDistanceUnits(double power, double rUnits) {
    Body b{0, 0, power * 120.0, 0, 0, 0, rUnits, false};
    double t = 0;
    while (t < 30.0) {
        double v = std::sqrt(b.vx * b.vx + b.vy * b.vy);
        if (v < 1e-3) break;
        double dt = std::max(1.0 / 600.0, std::min(1.0 / 60.0, 0.35 / v));
        b.x += b.vx * dt;
        calcVelocity(b, dt);
        t += dt;
    }
    return b.x;
}

void simulate(const Geo& g, std::vector<BPiece> P, float angleDeg, float power,
              const Params& prm, bool record, SimOut& out) {
    out = SimOut();
    const int n = (int)P.size();
    int si = -1;
    for (int i = 0; i < n; i++) if (P[i].type == 0) { si = i; break; }
    if (si < 0) return;
    if (power < 0.24f) power = 0.24f;
    if (power > 1.0f) power = 1.0f;

    // pixels -> game units (the field is 68 units wide)
    const double scale = (double)(g.fr - g.fl) / 68.0;
    const double inv = 1.0 / scale;
    const double wl = g.fl * inv, wr = g.fr * inv, wt = g.ft * inv, wb = g.fb * inv;
    const double cush = prm.restitution > 0.1f && prm.restitution < 1.0f ? prm.restitution : 0.76;
    std::vector<Body> B(n);
    for (int i = 0; i < n; i++) B[i] = {P[i].x * inv, P[i].y * inv, 0, 0, 0, 0, P[i].r * inv, false};
    const double a = angleDeg * 3.14159265358979 / 180.0;
    B[si].vx = std::cos(a) * power * 120.0;
    B[si].vy = std::sin(a) * power * 120.0;

    std::vector<Traj> tr;
    std::vector<int> trIdx;
    std::vector<double> lastX, lastY, lastDx, lastDy;
    std::vector<BPiece> start;
    if (record) {
        trIdx.assign(n, -1); lastX.resize(n); lastY.resize(n); lastDx.assign(n, 0); lastDy.assign(n, 0);
        for (int i = 0; i < n; i++) { lastX[i] = B[i].x; lastY[i] = B[i].y; }
        start = P;
    }
    auto touch = [&](int i) -> Traj& {
        if (trIdx[i] < 0) {
            Traj t; t.idx = i; t.type = start[i].type; t.potted = false; t.r = start[i].r;
            t.pts.push_back(start[i].x); t.pts.push_back(start[i].y);
            trIdx[i] = (int)tr.size(); tr.push_back(t);
        }
        return tr[trIdx[i]];
    };

    const double pr = (double)g.pocketR * 0.9 * inv, pr2 = pr * pr;
    double pkx[4], pky[4];
    for (int q = 0; q < 4; q++) { pkx[q] = g.pk[q * 2] * inv; pky[q] = g.pk[q * 2 + 1] * inv; }

    double t = 0;
    for (int tick = 0; tick < 12000 && t < 40.0; tick++) {
        double vmax2 = 0;
        for (int i = 0; i < n; i++) if (!B[i].gone) vmax2 = std::max(vmax2, B[i].vx * B[i].vx + B[i].vy * B[i].vy);
        if (vmax2 < 1e-6) break;                                      // everything stopped
        const double vmax = std::sqrt(vmax2);
        const double dt = std::max(1.0 / 600.0, std::min(1.0 / 60.0, 0.35 / vmax));
        t += dt;

        for (int i = 0; i < n; i++) {
            Body& b = B[i];
            if (b.gone || (b.vx == 0 && b.vy == 0)) continue;
            b.x += b.vx * dt; b.y += b.vy * dt;
        }
        for (int i = 0; i < n; i++) {                                 // cushions
            Body& b = B[i];
            if (b.gone) continue;
            if (b.x - b.r < wl) { b.x = wl + b.r; b.vx = std::fabs(b.vx) * cush; }
            if (b.x + b.r > wr) { b.x = wr - b.r; b.vx = -std::fabs(b.vx) * cush; }
            if (b.y - b.r < wt) { b.y = wt + b.r; b.vy = std::fabs(b.vy) * cush; }
            if (b.y + b.r > wb) { b.y = wb - b.r; b.vy = -std::fabs(b.vy) * cush; }
        }
        for (int i = 0; i < n; i++) {                                 // pockets
            Body& b = B[i];
            if (b.gone) continue;
            for (int q = 0; q < 4; q++) {
                double dx = b.x - pkx[q], dy = b.y - pky[q];
                if (dx * dx + dy * dy < pr2) {
                    b.gone = true; b.vx = b.vy = 0;
                    if (P[i].type == 0) out.strikerPotted = true;
                    else {
                        out.potted.push_back(i);
                        if (P[i].type == 1) out.potMine++;
                        else if (P[i].type == 2) out.potOpp++;
                        else out.potQueen++;
                    }
                    if (record) {
                        Traj& tj = touch(i);
                        tj.pts.push_back((float)(pkx[q] * scale)); tj.pts.push_back((float)(pky[q] * scale));
                        tj.potted = true; tj.endX = (float)(pkx[q] * scale); tj.endY = (float)(pky[q] * scale);
                    }
                    break;
                }
            }
        }
        for (int i = 0; i < n; i++) {                                 // piece / piece
            Body& A = B[i];
            if (A.gone) continue;
            bool im = (A.vx != 0 || A.vy != 0);
            for (int j = i + 1; j < n; j++) {
                Body& C = B[j];
                if (C.gone) continue;
                if (!im && C.vx == 0 && C.vy == 0) continue;
                double dx = C.x - A.x, dy = C.y - A.y, md = A.r + C.r, d2 = dx * dx + dy * dy;
                if (d2 >= md * md || d2 < 1e-12) continue;
                double d = std::sqrt(d2), nx = dx / d, ny = dy / d;
                double vn = (C.vx - A.vx) * nx + (C.vy - A.vy) * ny;
                if (vn < -1e-3) {
                    bool iMine = P[i].type <= 1, jMine = P[j].type <= 1;
                    if (iMine != jMine) out.contacts++;               // my side touched a white / red piece
                }
                if (vn <= 0) { C.vx -= vn * nx; C.vy -= vn * ny; A.vx += vn * nx; A.vy += vn * ny; }
                double ov = md - d;
                A.x -= nx * ov / 2; A.y -= ny * ov / 2; C.x += nx * ov / 2; C.y += ny * ov / 2;
                im = true;
            }
        }
        if (record) {
            for (int i = 0; i < n; i++) {
                Body& b = B[i];
                if (b.gone || (b.vx == 0 && b.vy == 0)) continue;
                Traj& tj = touch(i);
                if (tj.pts.size() > 1200) continue;
                double dx = b.x - lastX[i], dy = b.y - lastY[i];
                double dist = std::hypot(dx, dy) * scale;
                bool turn = false;
                double ldl = std::hypot(lastDx[i], lastDy[i]);
                if (dist > 0.5 && ldl > 0.5 * inv) {
                    double c = (dx * lastDx[i] + dy * lastDy[i]) / (std::hypot(dx, dy) * ldl);
                    turn = c < 0.995;
                }
                if (dist >= 10.0 || turn) {
                    tj.pts.push_back((float)(b.x * scale)); tj.pts.push_back((float)(b.y * scale));
                    lastX[i] = b.x; lastY[i] = b.y; lastDx[i] = dx; lastDy[i] = dy;
                }
            }
        }
        for (int i = 0; i < n; i++) if (!B[i].gone) calcVelocity(B[i], dt);   // sliding -> rolling -> stop
        for (int i = 0; i < n; i++) {
            Body& b = B[i];
            if (!b.gone && b.vx * b.vx + b.vy * b.vy < 1e-8) { b.vx = 0; b.vy = 0; b.sx = 0; b.sy = 0; }
        }
    }

    for (int i = 0; i < n; i++) {
        P[i].x = (float)(B[i].x * scale); P[i].y = (float)(B[i].y * scale);
    }
    out.score = scoreOf(out, weightsFor(prm.mode));
    for (int i = 0; i < n; i++) if (!B[i].gone) out.end.push_back(P[i]);
    if (record) {
        for (Traj& tj : tr) {
            if (!tj.potted) {
                tj.endX = P[tj.idx].x; tj.endY = P[tj.idx].y;
                tj.pts.push_back(tj.endX); tj.pts.push_back(tj.endY);
            }
            out.trajs.push_back(tj);
        }
    }
}

namespace {

struct Cand { float x, angle, power, geo; int ti; };

bool blockedSeg(const std::vector<BPiece>& P, float ax, float ay, float bx, float by, float mr, int skipA, int skipB) {
    float vx = bx - ax, vy = by - ay, l2 = vx * vx + vy * vy;
    for (int i = 0; i < (int)P.size(); i++) {
        if (i == skipA || i == skipB) continue;
        float u = l2 < 1e-9f ? 0.f : ((P[i].x - ax) * vx + (P[i].y - ay) * vy) / l2;
        u = clampf(u, 0.f, 1.f);
        float cx = ax + u * vx, cy = ay + u * vy;
        if (std::hypot(P[i].x - cx, P[i].y - cy) < (mr + P[i].r) * 0.98f) return true;
    }
    return false;
}

}  // namespace


namespace {
// power (0.24..1) that makes a lone striker roll `distPx` pixels (inverse of the real, quadratic law)
float powerForDistance(float distPx, const Geo& g, float strikerRpx) {
    const double scale = (double)(g.fr - g.fl) / 68.0;
    const double want = distPx / scale, rU = strikerRpx / scale;
    double lo = 0.24, hi = 1.0;
    if (stopDistanceUnits(hi, rU) <= want) return 1.0f;
    if (stopDistanceUnits(lo, rU) >= want) return 0.24f;
    for (int i = 0; i < 14; i++) {
        double mid = 0.5 * (lo + hi);
        if (stopDistanceUnits(mid, rU) < want) lo = mid; else hi = mid;
    }
    return (float)(0.5 * (lo + hi));
}
}  // namespace

PlanOut plan(const Geo& g, const std::vector<BPiece>& pieces, const Params& prm) {
    PlanOut best;
    int si = -1;
    for (int i = 0; i < (int)pieces.size(); i++) if (pieces[i].type == 0) { si = i; break; }
    if (si < 0) return best;
    const BPiece st = pieces[si];
    const Weights w = weightsFor(prm.mode);
    const float L = g.L;

    // x positions the striker may use on its baseline
    std::vector<float> xs;
    xs.push_back(st.x);
    if (prm.allowSlide) {
        float fw = g.fr - g.fl, from = g.fl + 0.23f * fw, to = g.fl + 0.77f * fw;
        for (float x = from; x <= to + 0.1f; x += 0.02f * fw) {
            bool occ = false;
            for (int i = 0; i < (int)pieces.size(); i++) {
                if (i == si) continue;
                if (std::hypot(pieces[i].x - x, pieces[i].y - st.y) < st.r + pieces[i].r + 2) { occ = true; break; }
            }
            if (!occ && std::fabs(x - st.x) > 2) xs.push_back(x);
        }
    }

    // ---- 1) geometric candidates: ghost-ball position for every (piece, pocket) ----
    std::vector<Cand> cands;
    for (float sx : xs) {
        for (int ti = 0; ti < (int)pieces.size(); ti++) {
            const BPiece& t = pieces[ti];
            if (t.type != 1) continue;                          // only BLACK pieces are targets
            for (int q = 0; q < 4; q++) {
                float tx = g.pk[q * 2] - t.x, ty = g.pk[q * 2 + 1] - t.y;
                float dTP = std::hypot(tx, ty);
                if (dTP < 1) continue;
                float dx = tx / dTP, dy = ty / dTP;
                float gx = t.x - dx * (st.r + t.r), gy = t.y - dy * (st.r + t.r);
                if (!(gx > g.fl + st.r && gx < g.fr - st.r && gy > g.ft + st.r && gy < g.fb - st.r)) continue;
                float sxv = gx - sx, syv = gy - st.y, dSG = std::hypot(sxv, syv);
                if (dSG < 1) continue;
                float cs = (sxv / dSG) * dx + (syv / dSG) * dy;
                if (cs < w.minCos) continue;
                // striker path must be free (the striker piece itself is at its old x - skip it)
                if (blockedSeg(pieces, sx, st.y, gx, gy, st.r, si, ti)) continue;
                if (blockedSeg(pieces, t.x, t.y, g.pk[q * 2], g.pk[q * 2 + 1], t.r, si, ti)) continue;
                float geo = 10.f * cs - 4.f * (dSG + dTP) / L - 0.8f * std::fabs(sx - st.x) / L;
                float need = dSG + prm.margin * dTP / std::max(cs, 0.3f) + 0.1f * L;
                float pw = powerForDistance(need, g, st.r);
                cands.push_back({sx, (float)(std::atan2(syv, sxv) * 180.0 / 3.14159265), pw, geo, ti});
            }
        }
    }
    // ---- 1b) bank shots: the black piece bounces off a wall into the pocket (mirror-pocket trick) ----
    for (float sx : xs) {
        for (int ti = 0; ti < (int)pieces.size(); ti++) {
            const BPiece& t = pieces[ti];
            if (t.type != 1) continue;
            for (int wall = 0; wall < 4; wall++) {
                float lineV = wall == 0 ? g.fl + t.r : wall == 1 ? g.fr - t.r : wall == 2 ? g.ft + t.r : g.fb - t.r;
                for (int q = 0; q < 4; q++) {
                    float qx = g.pk[q * 2], qy = g.pk[q * 2 + 1];
                    float mx = (wall < 2) ? 2 * lineV - qx : qx;           // mirrored pocket
                    float my = (wall < 2) ? qy : 2 * lineV - qy;
                    float vx = mx - t.x, vy = my - t.y, dTM = std::hypot(vx, vy);
                    if (dTM < 1) continue;
                    // where does the piece reach the wall line?
                    float u;
                    if (wall < 2) { if (std::fabs(vx) < 1e-3f) continue; u = (lineV - t.x) / vx; }
                    else          { if (std::fabs(vy) < 1e-3f) continue; u = (lineV - t.y) / vy; }
                    if (u <= 0.05f || u >= 0.95f) continue;
                    float bxp = t.x + vx * u, byp = t.y + vy * u;           // bounce point (piece centre)
                    if (bxp < g.fl + 2 * t.r || bxp > g.fr - 2 * t.r || byp < g.ft + 2 * t.r || byp > g.fb - 2 * t.r) continue;
                    float dx = vx / dTM, dy = vy / dTM;
                    float gx = t.x - dx * (st.r + t.r), gy = t.y - dy * (st.r + t.r);
                    if (!(gx > g.fl + st.r && gx < g.fr - st.r && gy > g.ft + st.r && gy < g.fb - st.r)) continue;
                    float sxv = gx - sx, syv = gy - st.y, dSG = std::hypot(sxv, syv);
                    if (dSG < 1) continue;
                    float cs = (sxv / dSG) * dx + (syv / dSG) * dy;
                    if (cs < std::max(0.45f, w.minCos)) continue;
                    if (blockedSeg(pieces, sx, st.y, gx, gy, st.r, si, ti)) continue;
                    if (blockedSeg(pieces, t.x, t.y, bxp, byp, t.r, si, ti)) continue;
                    if (blockedSeg(pieces, bxp, byp, qx, qy, t.r, si, ti)) continue;
                    float dTP = std::hypot(bxp - t.x, byp - t.y) + std::hypot(qx - bxp, qy - byp);
                    float geo = 10.f * cs - 4.f * (dSG + dTP) / L - 0.8f * std::fabs(sx - st.x) / L - 2.5f;
                    float need = dSG + prm.margin * 1.3f * dTP / std::max(cs, 0.3f) + 0.1f * L;
                    float pw = powerForDistance(need, g, st.r);
                    cands.push_back({sx, (float)(std::atan2(syv, sxv) * 180.0 / 3.14159265), pw, geo, ti});
                }
            }
        }
    }
    best.candidates = (int)cands.size();
    std::sort(cands.begin(), cands.end(), [](const Cand& a, const Cand& b) { return a.geo > b.geo; });
    // every target piece keeps its 2 best geometric candidates, then the best 20 overall go to the simulator
    {
        std::vector<Cand> pick; std::vector<int> cnt(pieces.size(), 0);
        for (const Cand& c : cands) if (cnt[c.ti] < 2) { pick.push_back(c); cnt[c.ti]++; }
        if (pick.size() > 16) pick.resize(16);
        cands.swap(pick);
    }

    // ---- 2) chance of potting: coarse pass on every candidate, fine pass (all powers) on the best few ----
    //      success = black piece drops, no scratch, nothing white/red potted or even touched.
    // clean pot = 1.0, pot that had to touch a white/red piece = 0.45, anything else = 0
    auto okShot = [&](const SimOut& o) -> float {
        if (o.potMine <= 0 || o.strikerPotted || o.potOpp > 0 || o.potQueen > 0) return 0.f;
        return o.contacts == 0 ? 1.0f : 0.45f;
    };
    struct Eval { float prob, avg, nominal; int mine; };
    auto evalAt = [&](const std::vector<BPiece>& P, float angle, float pw, const float* angOff, int nAng,
                      const float* powMul, int nPow) {
        Eval e{0, 0, 0, 0}; float succ = 0; int runs = 0;
        for (int a = 0; a < nAng; a++)
            for (int k = 0; k < nPow; k++) {
                SimOut o;
                simulate(g, P, angle + angOff[a], clampf(pw * powMul[k], 0.24f, 1.0f), prm, false, o);
                runs++; e.avg += o.score;
                succ += okShot(o);
                if (angOff[a] == 0.f && powMul[k] == 1.0f) { e.nominal = o.score; e.mine = o.potMine; }
            }
        e.prob = succ / runs; e.avg /= runs;
        return e;
    };
    const float coarseAng[3] = {-0.5f, 0.f, 0.5f}, coarsePow[1] = {1.0f};
    const float fineAng[5] = {-0.7f, -0.35f, 0.f, 0.35f, 0.7f}, finePow[3] = {0.86f, 1.0f, 1.1f};   // robust to power error

    struct Scored { Cand c; float pw; float val; };
    std::vector<Scored> coarse;
    for (const Cand& c : cands) {
        std::vector<BPiece> P = pieces; P[si].x = c.x;
        float coarsePowers[2] = {1.0f, 0.6f};
        if (prm.powerPolicy == 0) { coarsePowers[0] = c.power; coarsePowers[1] = clampf(c.power * 1.15f, 0.2f, 1.f); }
        float bestV = -1e9f, bestP = c.power;
        for (float pw : coarsePowers) {
            Eval e = evalAt(P, c.angle, pw, coarseAng, 3, coarsePow, 1);
            float v = e.prob * 100.f + e.avg * 0.5f + c.geo * 0.2f;
            if (v > bestV) { bestV = v; bestP = pw; }
        }
        coarse.push_back({c, bestP, bestV});
    }
    std::sort(coarse.begin(), coarse.end(), [](const Scored& a, const Scored& b) { return a.val > b.val; });
    if (coarse.size() > 4) coarse.resize(4);

    float bestVal = -1e9f;
    for (const Scored& sc : coarse) {
        std::vector<BPiece> P = pieces; P[si].x = sc.c.x;
        std::vector<float> powers;
        if (prm.powerPolicy == 0) { powers = {sc.c.power, clampf(sc.c.power * 1.15f, 0.2f, 1.0f)}; }
        else { powers = {1.0f, 0.85f, 0.7f, 0.55f, 0.4f}; }                  // physics picks the power
        for (float pw : powers) {
            Eval e = evalAt(P, sc.c.angle, pw, fineAng, 5, finePow, 3);
            // chance dominates; among equal chances prefer the stronger shot (PRO) / gentler shot (SAFE)
            float val = e.prob * 100.f + e.avg * 0.5f + sc.c.geo * 0.2f
                      + (prm.powerPolicy == 1 ? pw * 3.f : -pw * 2.f);
            if (val > bestVal) {
                bestVal = val;
                best.found = e.prob > 0.f && e.nominal > 0;
                best.angle = sc.c.angle; best.power = pw; best.strikerX = sc.c.x;
                best.score = e.nominal; best.predMine = e.mine; best.prob = e.prob;
            }
        }
    }
    if (best.found) return best;

    // ---- 3) no clean pot: brute-force sweep (angles x powers x a few striker spots), keep the best simulated result.
    //         `attempt` changes the sweep a little each time, so the bot never repeats the same useless tap.
    {
        std::vector<float> spots; spots.push_back(st.x);
        if (prm.allowSlide) {
            float fw = g.fr - g.fl;
            for (int k = 0; k < 6; k++) {
                float x = g.fl + (0.25f + 0.1f * k) * fw;
                bool occ = false;
                for (int i = 0; i < (int)pieces.size(); i++)
                    if (i != si && std::hypot(pieces[i].x - x, pieces[i].y - st.y) < st.r + pieces[i].r + 2) { occ = true; break; }
                if (!occ) spots.push_back(x);
            }
        }
        float bs = -1e9f, ba = -90, bp = 0.5f, bx = st.x;
        const float pws[3] = {0.55f, 0.8f, 1.0f};
        if (spots.size() > 3) spots.resize(3);
        for (float sx : spots) {
            std::vector<BPiece> P = pieces; P[si].x = sx;
            for (int i = 0; i < (int)pieces.size(); i++) {
                if (pieces[i].type != 1) continue;
                float base = (float)(std::atan2(pieces[i].y - st.y, pieces[i].x - sx) * 180.0 / 3.14159265);
                for (float da = -9.f; da <= 9.f; da += 2.25f) {
                    float a = base + da + (float)(prm.attempt % 3) * 0.7f;
                    for (int k = 0; k < 3; k++) {
                        SimOut o;
                        simulate(g, P, a, pws[k], prm, false, o);
                        float sc = o.score + 0.02f * (float)o.potted.size();
                        if (sc > bs) { bs = sc; ba = a; bp = pws[k]; bx = sx; }
                    }
                }
            }
        }
        best.found = bs > 0;
        best.angle = ba; best.power = bp; best.strikerX = bx; best.score = bs;
        if (bs <= 0) {
            // nothing pots anywhere: shake the pile (hit the nearest black piece with a varying power/angle, never a scratch)
            float nd = 1e18f; int ni = -1;
            for (int i = 0; i < (int)pieces.size(); i++) {
                if (pieces[i].type != 1) continue;
                float d = std::hypot(pieces[i].x - st.x, pieces[i].y - st.y);
                if (d < nd) { nd = d; ni = i; }
            }
            if (ni >= 0) {
                float base = (float)(std::atan2(pieces[ni].y - st.y, pieces[ni].x - st.x) * 180.0 / 3.14159265);
                const float soft[4] = {0.45f, 0.7f, 0.9f, 0.55f};
                bool done = false;
                for (int k = 0; k < 8 && !done; k++) {
                    float ang = base + ((prm.attempt + k) % 5 - 2) * 3.0f;
                    float pw = soft[(prm.attempt + k) % 4];
                    SimOut o;
                    simulate(g, pieces, ang, pw, prm, false, o);
                    if (!o.strikerPotted && o.potOpp == 0 && o.potQueen == 0) {
                        best.angle = ang; best.power = pw; best.strikerX = st.x; best.score = o.score; done = true;
                    }
                }
                if (!done) { best.angle = base; best.power = 0.3f; best.strikerX = st.x; }
            }
        }
    }
    return best;
}

}  // namespace carrom
