#include "brain.h"
#include <algorithm>
#include <cmath>

namespace carrom {
namespace {

struct Weights { float mine, queen, opp, striker, minCos, queenBonus; };
Weights weightsFor(int mode) {
    if (mode == 1) return {10, 10, -4, -20, 0.25f, 2.0f};   // AGGRO: goes for the queen, wider cuts
    if (mode == 2) return {10, 8, -8, -15, 0.35f, 1.0f};    // PRO
    return {10, 5, -10, -20, 0.55f, 0.0f};                  // SAFE: only clean shots
}

float scoreOf(const SimOut& o, const Weights& w) {
    float s = o.potMine * w.mine + o.potQueen * w.queen + o.potOpp * w.opp;
    if (o.strikerPotted) s += w.striker;
    return s;
}

inline float clampf(float v, float lo, float hi) { return std::max(lo, std::min(hi, v)); }

}  // namespace

void simulate(const Geo& g, std::vector<BPiece> P, float angleDeg, float power,
              const Params& prm, bool record, SimOut& out) {
    out = SimOut();
    const int n = (int)P.size();
    int si = -1;
    for (int i = 0; i < n; i++) if (P[i].type == 0) { si = i; break; }
    if (si < 0) return;

    std::vector<float> vx(n, 0), vy(n, 0);
    std::vector<char> gone(n, 0);
    const float v0 = power * prm.rangeL * g.L * (1.0f - prm.friction);
    const float a = angleDeg * 3.14159265f / 180.f;
    vx[si] = std::cos(a) * v0; vy[si] = std::sin(a) * v0;

    std::vector<Traj> tr;
    std::vector<int> trIdx(n, -1);
    std::vector<float> lastX(n), lastY(n), lastDx(n, 0), lastDy(n, 0);
    for (int i = 0; i < n; i++) { lastX[i] = P[i].x; lastY[i] = P[i].y; }
    const std::vector<BPiece> start = P;
    auto touch = [&](int i) -> Traj& {
        if (trIdx[i] < 0) {
            Traj t; t.idx = i; t.type = start[i].type; t.potted = false; t.r = start[i].r;
            t.pts.push_back(start[i].x); t.pts.push_back(start[i].y);
            trIdx[i] = (int)tr.size(); tr.push_back(t);
        }
        return tr[trIdx[i]];
    };

    const float pr2 = (g.pocketR * 0.9f) * (g.pocketR * 0.9f);   // piece must really drop in
    for (int step = 0; step < 1500; step++) {
        float vmax = 0;
        for (int i = 0; i < n; i++) if (!gone[i]) vmax = std::max(vmax, std::hypot(vx[i], vy[i]));
        if (vmax < 0.05f) break;
        int sub = (int)std::min(12.f, std::max(1.f, std::ceil(vmax / 6.f)));
        float fs = std::pow(prm.friction, 1.0f / sub);
        for (int k = 0; k < sub; k++) {
            for (int i = 0; i < n; i++) {
                if (gone[i] || (vx[i] == 0 && vy[i] == 0)) continue;
                P[i].x += vx[i] / sub; P[i].y += vy[i] / sub;
            }
            for (int i = 0; i < n; i++) {
                if (gone[i]) continue;
                BPiece& p = P[i];
                if (p.x - p.r < g.fl) { p.x = g.fl + p.r; vx[i] = std::fabs(vx[i]) * prm.restitution; }
                if (p.x + p.r > g.fr) { p.x = g.fr - p.r; vx[i] = -std::fabs(vx[i]) * prm.restitution; }
                if (p.y - p.r < g.ft) { p.y = g.ft + p.r; vy[i] = std::fabs(vy[i]) * prm.restitution; }
                if (p.y + p.r > g.fb) { p.y = g.fb - p.r; vy[i] = -std::fabs(vy[i]) * prm.restitution; }
            }
            for (int i = 0; i < n; i++) {
                if (gone[i]) continue;
                for (int q = 0; q < 4; q++) {
                    float dx = P[i].x - g.pk[q * 2], dy = P[i].y - g.pk[q * 2 + 1];
                    if (dx * dx + dy * dy < pr2) {
                        gone[i] = 1; vx[i] = vy[i] = 0;
                        if (P[i].type == 0) out.strikerPotted = true;
                        else {
                            out.potted.push_back(i);
                            if (P[i].type == 1) out.potMine++;
                            else if (P[i].type == 2) out.potOpp++;
                            else out.potQueen++;
                        }
                        if (record) {
                            Traj& t = touch(i);
                            t.pts.push_back(g.pk[q * 2]); t.pts.push_back(g.pk[q * 2 + 1]);
                            t.potted = true; t.endX = g.pk[q * 2]; t.endY = g.pk[q * 2 + 1];
                        }
                        break;
                    }
                }
            }
            for (int i = 0; i < n; i++) {
                if (gone[i]) continue;
                bool im = (vx[i] != 0 || vy[i] != 0);
                for (int j = i + 1; j < n; j++) {
                    if (gone[j]) continue;
                    if (!im && vx[j] == 0 && vy[j] == 0) continue;     // both resting
                    float dx = P[j].x - P[i].x, dy = P[j].y - P[i].y;
                    float md = P[i].r + P[j].r, d2 = dx * dx + dy * dy;
                    if (d2 >= md * md || d2 < 1e-8f) continue;
                    float d = std::sqrt(d2), nx = dx / d, ny = dy / d;
                    float vn = (vx[j] - vx[i]) * nx + (vy[j] - vy[i]) * ny;
                    if (vn <= 0) {
                        vx[j] -= vn * nx; vy[j] -= vn * ny; vx[i] += vn * nx; vy[i] += vn * ny;
                    }
                    float ov = md - d;
                    P[i].x -= nx * ov / 2; P[i].y -= ny * ov / 2; P[j].x += nx * ov / 2; P[j].y += ny * ov / 2;
                    im = true;
                }
            }
            if (record) {
                for (int i = 0; i < n; i++) {
                    if (gone[i] || (vx[i] == 0 && vy[i] == 0)) continue;
                    Traj& t = touch(i);
                    if (t.pts.size() > 1200) continue;
                    float dx = P[i].x - lastX[i], dy = P[i].y - lastY[i];
                    float dist = std::hypot(dx, dy);
                    // keep corners (bounces / hits) and one point every ~10 px
                    bool turn = false;
                    float ldl = std::hypot(lastDx[i], lastDy[i]);
                    if (dist > 0.5f && ldl > 0.5f) {
                        float c = (dx * lastDx[i] + dy * lastDy[i]) / (dist * ldl);
                        turn = c < 0.995f;
                    }
                    if (dist >= 10.f || turn) {
                        t.pts.push_back(P[i].x); t.pts.push_back(P[i].y);
                        lastX[i] = P[i].x; lastY[i] = P[i].y; lastDx[i] = dx; lastDy[i] = dy;
                    }
                }
            }
            for (int i = 0; i < n; i++) {
                if (gone[i]) continue;
                vx[i] *= fs; vy[i] *= fs;
                if (std::hypot(vx[i], vy[i]) < 0.04f) { vx[i] = 0; vy[i] = 0; }
            }
        }
    }
    out.score = scoreOf(out, weightsFor(prm.mode));
    if (record) {
        for (Traj& t : tr) {
            if (!t.potted) {
                t.endX = P[t.idx].x; t.endY = P[t.idx].y;
                t.pts.push_back(t.endX); t.pts.push_back(t.endY);
            }
            out.trajs.push_back(t);
        }
    }
}

namespace {

struct Cand { float x, angle, power, geo; int ti; };

bool blockedSeg(const std::vector<BPiece>& P, float ax, float ay, float bx, float by, float mr, int skipA, int skipB) {
    float vx = bx - ax, vy = by - ay, l2 = vx * vx + vy * vy;
    for (int i = 0; i < (int)P.size(); i++) {
        if (i == skipA || i == skipB) continue;
        float u = l2 < 1e-9f ? 0.f : ((P[i].x - ax) * vx + (P[i].y - ay) * vy) / l2;
        u = clampf(u, 0.f, 1.f);
        float cx = ax + u * vx, cy = ay + u * vy;
        if (std::hypot(P[i].x - cx, P[i].y - cy) < (mr + P[i].r) * 0.98f) return true;
    }
    return false;
}

}  // namespace

PlanOut plan(const Geo& g, const std::vector<BPiece>& pieces, const Params& prm) {
    PlanOut best;
    int si = -1;
    for (int i = 0; i < (int)pieces.size(); i++) if (pieces[i].type == 0) { si = i; break; }
    if (si < 0) return best;
    const BPiece st = pieces[si];
    const Weights w = weightsFor(prm.mode);
    const float L = g.L;

    // x positions the striker may use on its baseline
    std::vector<float> xs;
    xs.push_back(st.x);
    if (prm.allowSlide) {
        float fw = g.fr - g.fl, from = g.fl + 0.23f * fw, to = g.fl + 0.77f * fw;
        for (float x = from; x <= to + 0.1f; x += 0.02f * fw) {
            bool occ = false;
            for (int i = 0; i < (int)pieces.size(); i++) {
                if (i == si) continue;
                if (std::hypot(pieces[i].x - x, pieces[i].y - st.y) < st.r + pieces[i].r + 2) { occ = true; break; }
            }
            if (!occ && std::fabs(x - st.x) > 2) xs.push_back(x);
        }
    }

    // ---- 1) geometric candidates: ghost-ball position for every (piece, pocket) ----
    std::vector<Cand> cands;
    for (float sx : xs) {
        for (int ti = 0; ti < (int)pieces.size(); ti++) {
            const BPiece& t = pieces[ti];
            if (t.type != 1 && t.type != 3) continue;           // my pieces + queen
            for (int q = 0; q < 4; q++) {
                float tx = g.pk[q * 2] - t.x, ty = g.pk[q * 2 + 1] - t.y;
                float dTP = std::hypot(tx, ty);
                if (dTP < 1) continue;
                float dx = tx / dTP, dy = ty / dTP;
                float gx = t.x - dx * (st.r + t.r), gy = t.y - dy * (st.r + t.r);
                if (!(gx > g.fl + st.r && gx < g.fr - st.r && gy > g.ft + st.r && gy < g.fb - st.r)) continue;
                float sxv = gx - sx, syv = gy - st.y, dSG = std::hypot(sxv, syv);
                if (dSG < 1) continue;
                float cs = (sxv / dSG) * dx + (syv / dSG) * dy;
                if (cs < w.minCos) continue;
                // striker path must be free (the striker piece itself is at its old x - skip it)
                if (blockedSeg(pieces, sx, st.y, gx, gy, st.r, si, ti)) continue;
                if (blockedSeg(pieces, t.x, t.y, g.pk[q * 2], g.pk[q * 2 + 1], t.r, si, ti)) continue;
                float geo = 10.f * cs - 4.f * (dSG + dTP) / L - 0.8f * std::fabs(sx - st.x) / L;
                if (t.type == 3) geo += w.queenBonus;
                float need = dSG + prm.margin * dTP / std::max(cs, 0.3f) + 0.1f * L;
                float pw = clampf(need / (prm.rangeL * L), 0.25f, 1.0f);
                cands.push_back({sx, (float)(std::atan2(syv, sxv) * 180.0 / 3.14159265), pw, geo, ti});
            }
        }
    }
    best.candidates = (int)cands.size();
    std::sort(cands.begin(), cands.end(), [](const Cand& a, const Cand& b) { return a.geo > b.geo; });
    // every target piece keeps its 2 best geometric candidates, then the best 20 overall go to the simulator
    {
        std::vector<Cand> pick; std::vector<int> cnt(pieces.size(), 0);
        for (const Cand& c : cands) if (cnt[c.ti] < 2) { pick.push_back(c); cnt[c.ti]++; }
        if (pick.size() > 20) pick.resize(20);
        cands.swap(pick);
    }

    // ---- 2) chance of potting: simulate every candidate with small aim / power errors ----
    //      success = my piece (or queen) drops, no scratch, no opponent piece. Pick the highest chance;
    //      with powerPolicy 1 the strongest power that is still safe wins.
    const float angOff[5] = {-0.7f, -0.35f, 0.f, 0.35f, 0.7f};
    const float powMul[2] = {1.0f, 0.93f};
    float bestVal = -1e9f;
    for (const Cand& c : cands) {
        std::vector<BPiece> P = pieces;
        P[si].x = c.x;
        std::vector<float> powers;
        if (prm.powerPolicy == 1) { powers = {1.0f, 0.85f, 0.70f, 0.55f}; }
        else { powers = {c.power, clampf(c.power * 1.15f, 0.2f, 1.0f)}; }
        for (float pw : powers) {
            int succ = 0, runs = 0, mineNominal = 0; float sum = 0, nominal = 0;
            for (float ao : angOff)
                for (float pm : powMul) {
                    SimOut o;
                    simulate(g, P, c.angle + ao, clampf(pw * pm, 0.15f, 1.0f), prm, false, o);
                    runs++; sum += o.score;
                    if ((o.potMine + o.potQueen) > 0 && !o.strikerPotted && o.potOpp == 0) succ++;
                    if (ao == 0.f && pm == 1.0f) { nominal = o.score; mineNominal = o.potMine; }
                }
            float prob = (float)succ / runs;
            float val = prob * 100.f + (sum / runs) * 0.5f + c.geo * 0.2f
                      + (prm.powerPolicy == 1 ? pw * 6.f : -pw * 2.f);
            if (val > bestVal) {
                bestVal = val;
                best.found = prob > 0.f && nominal > 0;
                best.angle = c.angle; best.power = pw; best.strikerX = c.x;
                best.score = nominal; best.predMine = mineNominal; best.prob = prob;
            }
        }
    }
    if (best.found) return best;

    // ---- 3) no clean pot: brute-force sweep from the current spot, keep the best simulated result ----
    {
        std::vector<BPiece> P = pieces;
        float bs = -1e9f, ba = -90, bp = 0.5f;
        const float pws[4] = {0.40f, 0.60f, 0.80f, 1.0f};
        for (int a = -180; a < 180; a += 4)
            for (int k = 0; k < 4; k++) {
                SimOut o;
                simulate(g, P, (float)a, pws[k], prm, false, o);
                float sc = o.score + 0.01f * o.potted.size();
                if (sc > bs) { bs = sc; ba = (float)a; bp = pws[k]; }
            }
        best.found = bs > 0;
        best.angle = ba; best.power = bp; best.strikerX = st.x; best.score = bs;
        if (bs <= 0) {
            // nothing pots: hit the nearest own piece softly - but only if the simulator says it is not a scratch
            float nd = 1e18f; int ni = -1;
            for (int i = 0; i < (int)pieces.size(); i++) {
                if (pieces[i].type != 1 && pieces[i].type != 3) continue;
                float d = std::hypot(pieces[i].x - st.x, pieces[i].y - st.y);
                if (d < nd) { nd = d; ni = i; }
            }
            bool done = false;
            if (ni >= 0) {
                float ang = (float)(std::atan2(pieces[ni].y - st.y, pieces[ni].x - st.x) * 180.0 / 3.14159265);
                const float soft[3] = {0.45f, 0.35f, 0.25f};
                for (int k = 0; k < 3 && !done; k++) {
                    SimOut o;
                    simulate(g, P, ang, soft[k], prm, false, o);
                    if (!o.strikerPotted && o.potOpp == 0) { best.angle = ang; best.power = soft[k]; best.score = o.score; done = true; }
                }
            }
            if (!done) {
                if (bs < 0) { best.power = 0.25f; }   // every sweep result was bad: weakest safe tap
            }
        }
    }
    return best;
}

}  // namespace carrom
