#include "vision.h"
#include <algorithm>
#include <cmath>
#include <cstring>

namespace carrom {
namespace {

inline void rgb2hsv(int r, int g, int b, int& H, int& S, int& V) {
    int mx = std::max(r, std::max(g, b)), mn = std::min(r, std::min(g, b));
    V = mx;
    int d = mx - mn;
    if (mx == 0 || d == 0) { S = 0; H = 0; return; }
    S = d * 255 / mx;
    float h;
    if (mx == r) h = 60.f * (g - b) / d;
    else if (mx == g) h = 120.f + 60.f * (b - r) / d;
    else h = 240.f + 60.f * (r - g) / d;
    if (h < 0) h += 360.f;
    H = (int)(h / 2.f + 0.5f);
    if (H >= 180) H -= 180;
}

typedef std::vector<uint8_t> Mask;

// 3x3 binary erosion / dilation (out-of-image counts as background / foreground-neutral)
Mask dilate3(const Mask& m, int w, int h) {
    Mask o(m.size(), 0);
    for (int y = 0; y < h; y++)
        for (int x = 0; x < w; x++) {
            uint8_t v = 0;
            for (int dy = -1; dy <= 1 && !v; dy++) {
                int yy = y + dy; if (yy < 0 || yy >= h) continue;
                for (int dx = -1; dx <= 1; dx++) {
                    int xx = x + dx; if (xx < 0 || xx >= w) continue;
                    if (m[yy * w + xx]) { v = 1; break; }
                }
            }
            o[y * w + x] = v;
        }
    return o;
}
Mask erode3(const Mask& m, int w, int h) {
    Mask o(m.size(), 0);
    for (int y = 0; y < h; y++)
        for (int x = 0; x < w; x++) {
            uint8_t v = 1;
            for (int dy = -1; dy <= 1 && v; dy++) {
                int yy = y + dy; if (yy < 0 || yy >= h) continue;
                for (int dx = -1; dx <= 1; dx++) {
                    int xx = x + dx; if (xx < 0 || xx >= w) continue;
                    if (!m[yy * w + xx]) { v = 0; break; }
                }
            }
            o[y * w + x] = v;
        }
    return o;
}

// fill holes: background reachable from the border stays background, everything else becomes foreground
void fillHoles(Mask& m, int w, int h) {
    Mask bg(m.size(), 0);
    std::vector<int> q;
    q.reserve(w * 2 + h * 2);
    auto push = [&](int x, int y) {
        int i = y * w + x;
        if (!m[i] && !bg[i]) { bg[i] = 1; q.push_back(i); }
    };
    for (int x = 0; x < w; x++) { push(x, 0); push(x, h - 1); }
    for (int y = 0; y < h; y++) { push(0, y); push(w - 1, y); }
    for (size_t k = 0; k < q.size(); k++) {
        int i = q[k], x = i % w, y = i / w;
        if (x > 0) push(x - 1, y);
        if (x < w - 1) push(x + 1, y);
        if (y > 0) push(x, y - 1);
        if (y < h - 1) push(x, y + 1);
    }
    for (size_t i = 0; i < m.size(); i++) m[i] = bg[i] ? 0 : 1;
}

// 5-7-11 chamfer distance transform: distance (in pixels) to the nearest background pixel
void distanceTransform(const Mask& m, int w, int h, std::vector<float>& out) {
    const int INF = 1 << 28;
    std::vector<int> d(m.size());
    for (size_t i = 0; i < m.size(); i++) d[i] = m[i] ? INF : 0;
    auto at = [&](int x, int y) -> int& { return d[y * w + x]; };
    for (int y = 0; y < h; y++)
        for (int x = 0; x < w; x++) {
            int& v = at(x, y);
            if (v == 0) continue;
            int best = v;
            if (x > 0) best = std::min(best, at(x - 1, y) + 5);
            if (y > 0) {
                best = std::min(best, at(x, y - 1) + 5);
                if (x > 0) best = std::min(best, at(x - 1, y - 1) + 7);
                if (x < w - 1) best = std::min(best, at(x + 1, y - 1) + 7);
                if (x > 1) best = std::min(best, at(x - 2, y - 1) + 11);
                if (x < w - 2) best = std::min(best, at(x + 2, y - 1) + 11);
            }
            if (y > 1) {
                if (x > 0) best = std::min(best, at(x - 1, y - 2) + 11);
                if (x < w - 1) best = std::min(best, at(x + 1, y - 2) + 11);
            }
            v = best;
        }
    for (int y = h - 1; y >= 0; y--)
        for (int x = w - 1; x >= 0; x--) {
            int& v = at(x, y);
            if (v == 0) continue;
            int best = v;
            if (x < w - 1) best = std::min(best, at(x + 1, y) + 5);
            if (y < h - 1) {
                best = std::min(best, at(x, y + 1) + 5);
                if (x < w - 1) best = std::min(best, at(x + 1, y + 1) + 7);
                if (x > 0) best = std::min(best, at(x - 1, y + 1) + 7);
                if (x < w - 2) best = std::min(best, at(x + 2, y + 1) + 11);
                if (x > 1) best = std::min(best, at(x - 2, y + 1) + 11);
            }
            if (y < h - 2) {
                if (x < w - 1) best = std::min(best, at(x + 1, y + 2) + 11);
                if (x > 0) best = std::min(best, at(x - 1, y + 2) + 11);
            }
            v = best;
        }
    out.resize(m.size());
    for (size_t i = 0; i < m.size(); i++) out[i] = d[i] >= INF ? 0.f : d[i] / 5.0f;
}

struct Peak { float x, y, d; };

// distance-transform peaks = disc centres (touching discs are separated).
// Greedy: strongest distance value first, anything closer than `suppress` to an accepted centre is dropped.
std::vector<Peak> findDiscs(Mask& mask, int w, int h, float minDt, float suppress) {
    std::vector<Peak> keep;
    bool any = false;
    for (size_t i = 0; i < mask.size(); i++) if (mask[i]) { any = true; break; }
    if (!any) return keep;
    mask = erode3(mask, w, h);
    mask = dilate3(mask, w, h);          // opening: removes thin lines / noise
    fillHoles(mask, w, h);
    std::vector<float> dt;
    distanceTransform(mask, w, h, dt);
    std::vector<Peak> all;
    for (int y = 0; y < h; y++)
        for (int x = 0; x < w; x++) {
            float v = dt[y * w + x];
            if (v > minDt) all.push_back({(float)x, (float)y, v});
        }
    std::sort(all.begin(), all.end(), [](const Peak& a, const Peak& b) { return a.d > b.d; });
    float s2 = suppress * suppress;
    for (const Peak& p : all) {
        bool ok = true;
        for (const Peak& k : keep) {
            float dx = p.x - k.x, dy = p.y - k.y;
            if (dx * dx + dy * dy < s2) { ok = false; break; }
        }
        if (ok) { keep.push_back(p); if (keep.size() >= 60) break; }
    }
    return keep;
}

inline bool isWood(int H, int S, int V) { return H >= 6 && H <= 22 && S >= 70 && S <= 160 && V >= 100; }

}  // namespace

Result Vision::detect(const uint8_t* p, int w, int h, int stride) {
    Result res;
    if (!p || w < 100 || h < 100) return res;

    // ---------- board + pockets (re-measured every 20 frames) ----------
    if (!hasBoard_ || (frameNo_ % 20) == 0) {
        const int st = 4;
        int gw = w / st, gh = h / st;
        Mask g(gw * gh, 0);
        for (int gy = 0; gy < gh; gy++)
            for (int gx = 0; gx < gw; gx++) {
                const uint8_t* q = p + (size_t)(gy * st + 2) * stride + (gx * st + 2) * 4;
                int H, S, V; rgb2hsv(q[0], q[1], q[2], H, S, V);
                g[gy * gw + gx] = isWood(H, S, V);
            }
        g = erode3(dilate3(g, gw, gh), gw, gh);     // closing
        std::vector<int> comp(g.size(), -1), queue;
        int bestArea = 0, bMinX = 0, bMinY = 0, bMaxX = 0, bMaxY = 0, cid = 0;
        for (int s0 = 0; s0 < gw * gh; s0++) {
            if (!g[s0] || comp[s0] >= 0) continue;
            queue.clear(); queue.push_back(s0); comp[s0] = cid;
            int area = 0, mnx = gw, mny = gh, mxx = 0, mxy = 0;
            for (size_t k = 0; k < queue.size(); k++) {
                int i = queue[k], x = i % gw, y = i / gw;
                area++;
                mnx = std::min(mnx, x); mxx = std::max(mxx, x); mny = std::min(mny, y); mxy = std::max(mxy, y);
                for (int dy = -1; dy <= 1; dy++)
                    for (int dx = -1; dx <= 1; dx++) {
                        int xx = x + dx, yy = y + dy;
                        if (xx < 0 || yy < 0 || xx >= gw || yy >= gh) continue;
                        int j = yy * gw + xx;
                        if (g[j] && comp[j] < 0) { comp[j] = cid; queue.push_back(j); }
                    }
            }
            if (area > bestArea) { bestArea = area; bMinX = mnx; bMaxX = mxx; bMinY = mny; bMaxY = mxy; }
            cid++;
        }
        if (bestArea == 0) { hasBoard_ = false; return res; }
        int bx = bMinX * st, by = bMinY * st;
        int bw = (bMaxX - bMinX + 1) * st, bh = (bMaxY - bMinY + 1) * st;
        double ratio = (double)bw / bh;
        if (bw < w * 0.5 || ratio < 0.85 || ratio > 1.15) { hasBoard_ = false; return res; }
        bx_ = bx; by_ = by; bw_ = bw; bh_ = bh;

        float L = (bw + bh) / 2.f;
        float fb = 0.06f * L;   // fallback pocket offset
        float fallback[8] = {bx + fb, by + fb, bx + bw - fb, by + fb, bx + fb, by + bh - fb, bx + bw - fb, by + bh - fb};
        std::memcpy(pk_, fallback, sizeof(pk_));
        const int sgx[4] = {1, -1, 1, -1}, sgy[4] = {1, 1, -1, -1};
        const float cx[4] = {(float)bx, (float)(bx + bw), (float)bx, (float)(bx + bw)};
        const float cy[4] = {(float)by, (float)by, (float)(by + bh), (float)(by + bh)};
        for (int i = 0; i < 4; i++) {
            float xa = cx[i] - sgx[i] * 0.04f * L, xb = cx[i] + sgx[i] * 0.14f * L;
            float ya = cy[i] - sgy[i] * 0.04f * L, yb = cy[i] + sgy[i] * 0.14f * L;
            int x0 = (int)std::max(0.f, std::min(xa, xb)), x1 = (int)std::min((float)w, std::max(xa, xb));
            int y0 = (int)std::max(0.f, std::min(ya, yb)), y1 = (int)std::min((float)h, std::max(ya, yb));
            int ww = x1 - x0, hh = y1 - y0;
            if (ww < 10 || hh < 10) continue;
            Mask m(ww * hh, 0);
            for (int y = 0; y < hh; y++)
                for (int x = 0; x < ww; x++) {
                    const uint8_t* q = p + (size_t)(y0 + y) * stride + (x0 + x) * 4;
                    int H, S, V; rgb2hsv(q[0], q[1], q[2], H, S, V);
                    m[y * ww + x] = (V < 85 && S < 95) ? 1 : 0;
                }
            std::vector<float> dt; distanceTransform(m, ww, hh, dt);
            float best = 0; int bxi = 0, byi = 0;
            for (int y = 0; y < hh; y++)
                for (int x = 0; x < ww; x++)
                    if (dt[y * ww + x] > best) { best = dt[y * ww + x]; bxi = x; byi = y; }
            if (best >= 0.025f * L && best <= 0.07f * L) { pk_[i * 2] = (float)(x0 + bxi); pk_[i * 2 + 1] = (float)(y0 + byi); }
        }
        // my colour: the small puck icon next to my score (top-left)
        {
            int cxp = (int)(0.111 * w), cyp = (int)(0.146 * h), rr = std::max(4, (int)(0.012 * w));
            long sum = 0; int n = 0;
            for (int y = std::max(0, cyp - rr); y <= std::min(h - 1, cyp + rr); y++)
                for (int x = std::max(0, cxp - rr); x <= std::min(w - 1, cxp + rr); x++) {
                    const uint8_t* q = p + (size_t)y * stride + x * 4;
                    sum += std::max(q[0], std::max(q[1], q[2])); n++;
                }
            mineBlack_ = (n > 0 && sum / n < 130) ? 1 : 0;
        }
        thumbYCache_ = -1;
        hasBoard_ = true;
    }
    frameNo_++;

    const int bx = bx_, by = by_, bw = bw_, bh = bh_;
    const float L = (bw + bh) / 2.f;
    res.board[0] = (float)bx; res.board[1] = (float)by; res.board[2] = (float)bw; res.board[3] = (float)bh;
    std::memcpy(res.pockets, pk_, sizeof(pk_));
    res.mineBlack = mineBlack_;
    float wall = 0.052f * L;
    res.field[0] = std::min(pk_[0], pk_[4]) - wall;
    res.field[2] = std::max(pk_[2], pk_[6]) + wall;
    res.field[1] = std::min(pk_[1], pk_[3]) - wall;
    res.field[3] = std::max(pk_[5], pk_[7]) + wall;

    // ---------- pieces: masks over the board rectangle (half resolution = 4x faster) ----------
    const int sc = 2;
    int rx0 = std::max(0, bx), ry0 = std::max(0, by);
    int rw = (std::min(w, bx + bw) - rx0) / sc, rh = (std::min(h, by + bh) - ry0) / sc;
    if (rw < 50 || rh < 50) return res;
    Mask mW(rw * rh, 0), mB(rw * rh, 0), mR(rw * rh, 0);
    for (int y = 0; y < rh; y++) {
        const uint8_t* row = p + (size_t)(ry0 + y * sc) * stride + rx0 * 4;
        for (int x = 0; x < rw; x++) {
            const uint8_t* q = row + x * sc * 4;
            int r = q[0], g = q[1], b = q[2];
            int mx = std::max(r, std::max(g, b)), mn = std::min(r, std::min(g, b));
            int V = mx, S = mx ? (mx - mn) * 255 / mx : 0;
            int i = y * rw + x;
            if (S < 70 && V > 150) mW[i] = 1;
            else if (V < 90 && S < 60) mB[i] = 1;
            else if (S > 130 && V > 120) {
                int H, S2, V2; rgb2hsv(r, g, b, H, S2, V2);
                if (H < 6 || H > 170) mR[i] = 1;
            }
        }
    }
    const float L2 = L / sc;
    // blank the pockets so they are not seen as black pucks
    float paintR = 0.055f * L2;
    for (int k = 0; k < 4; k++) {
        float pxk = (pk_[k * 2] - rx0) / sc, pyk = (pk_[k * 2 + 1] - ry0) / sc;
        int ya = std::max(0, (int)(pyk - paintR)), yb = std::min(rh - 1, (int)(pyk + paintR));
        int xa = std::max(0, (int)(pxk - paintR)), xb = std::min(rw - 1, (int)(pxk + paintR));
        for (int y = ya; y <= yb; y++)
            for (int x = xa; x <= xb; x++)
                if (std::hypot(x - pxk, y - pyk) <= paintR) { int i = y * rw + x; mW[i] = 0; mB[i] = 0; mR[i] = 0; }
    }
    float minDt = 0.011f * L2, suppress = 0.03f * L2;
    std::vector<Peak> pw = findDiscs(mW, rw, rh, minDt, suppress);
    std::vector<Peak> pb = findDiscs(mB, rw, rh, minDt, suppress);
    std::vector<Peak> pr = findDiscs(mR, rw, rh, minDt, suppress);
    float puckR = 0.025f * L;
    auto X = [&](const Peak& q) { return q.x * sc + rx0 + sc / 2.f; };
    auto Y = [&](const Peak& q) { return q.y * sc + ry0 + sc / 2.f; };
    for (const Peak& q : pw) {
        if (q.d > 0.0285f * L2) res.discs.push_back({0, X(q), Y(q), std::min(q.d * sc, 0.04f * L)});
        else res.discs.push_back({1, X(q), Y(q), puckR});
    }
    for (const Peak& q : pb) res.discs.push_back({2, X(q), Y(q), puckR});
    for (const Peak& q : pr) res.discs.push_back({3, X(q), Y(q), puckR});
    if (res.discs.size() > 48) res.discs.resize(48);

    // ---------- striker slider thumb (below the board, half resolution) ----------
    {
        int y0, y1;
        if (thumbYCache_ < 0) { y0 = (int)(by + bh + 0.03f * L); y1 = (int)std::min((float)h, by + bh + 1.0f * L); }
        else { y0 = (int)(thumbYCache_ - 0.05f * L); y1 = (int)std::min((float)h, thumbYCache_ + 0.05f * L); }
        y0 = std::max(0, y0);
        int tx0 = std::max(0, bx);
        int tw = (std::min(w, bx + bw) - tx0) / sc, th = (y1 - y0) / sc;
        if (tw > 20 && th > 10) {
            Mask m(tw * th, 0);
            for (int y = 0; y < th; y++) {
                const uint8_t* row = p + (size_t)(y0 + y * sc) * stride + tx0 * 4;
                for (int x = 0; x < tw; x++) {
                    const uint8_t* q = row + x * sc * 4;
                    int mx = std::max(q[0], std::max(q[1], q[2])), mn = std::min(q[0], std::min(q[1], q[2]));
                    int S = mx ? (mx - mn) * 255 / mx : 0;
                    m[y * tw + x] = (S < 115 && mx > 125) ? 1 : 0;
                }
            }
            m = erode3(m, tw, th); m = dilate3(m, tw, th);
            fillHoles(m, tw, th);
            std::vector<float> dt; distanceTransform(m, tw, th, dt);
            float best = 0; int bxi = 0, byi = 0;
            for (int y = 0; y < th; y++)
                for (int x = 0; x < tw; x++)
                    if (dt[y * tw + x] > best) { best = dt[y * tw + x]; bxi = x; byi = y; }
            if (best >= 0.02f * L2 && best <= 0.05f * L2) {
                res.thumb[0] = (float)(tx0 + bxi * sc + sc / 2); res.thumb[1] = (float)(y0 + byi * sc + sc / 2);
                thumbYCache_ = res.thumb[1];
            }
        }
    }
    res.ok = true;
    return res;
}


bool detectAim(const uint8_t* p, int w, int h, int stride,
               float sx, float sy, float sr, float L, float R,
               const float field[4], float out[6]) {
    for (int i = 0; i < 6; i++) out[i] = 0;
    if (!p || sr <= 1) return false;
    int x0 = std::max(0, (int)(sx - 0.35f * L)), x1 = std::min(w, (int)(sx + 0.35f * L));
    int y0 = std::max(0, (int)(sy - 0.35f * L)), y1 = std::min(h, (int)(sy + 0.35f * L));
    int ww = x1 - x0, hh = y1 - y0;
    if (ww < 20 || hh < 20) return false;
    Mask m(ww * hh, 0);
    for (int y = 0; y < hh; y++) {
        const uint8_t* row = p + (size_t)(y0 + y) * stride + x0 * 4;
        for (int x = 0; x < ww; x++) {
            int r = row[x * 4], g = row[x * 4 + 1], b = row[x * 4 + 2];
            int mx = std::max(r, std::max(g, b)), mn = std::min(r, std::min(g, b));
            if (mx < 150) continue;
            int S = (mx - mn) * 255 / mx;
            if (S < 225) continue;
            int H, S2, V2; rgb2hsv(r, g, b, H, S2, V2);
            if (H <= 24 || H >= 176) m[y * ww + x] = 1;
        }
    }
    // the 8 orange markers printed on the board (baseline + side circles) have the arrow's colour:
    // blank them. They sit on a fixed grid of the playing field.
    {
        float fw = field[2] - field[0], fh = field[3] - field[1];
        const float fxs[8] = {0.226f, 0.774f, 0.226f, 0.774f, 0.156f, 0.156f, 0.844f, 0.844f};
        const float fys[8] = {0.844f, 0.844f, 0.156f, 0.156f, 0.226f, 0.774f, 0.226f, 0.774f};
        float mr = 0.036f * fw;
        for (int k = 0; k < 8; k++) {
            float mx = field[0] + fxs[k] * fw - x0, my = field[1] + fys[k] * fh - y0;
            int ya = std::max(0, (int)(my - mr)), yb = std::min(hh - 1, (int)(my + mr));
            int xa = std::max(0, (int)(mx - mr)), xb = std::min(ww - 1, (int)(mx + mr));
            for (int y = ya; y <= yb; y++)
                for (int x = xa; x <= xb; x++)
                    if (std::hypot(x - mx, y - my) <= mr) m[y * ww + x] = 0;
        }
    }
    // flood fill from the pixels next to the striker; the arrow is the part that is far from it
    Mask seen(m.size(), 0);
    std::vector<int> q;
    float seedR2 = (2.3f * sr) * (2.3f * sr);
    for (int y = 0; y < hh; y++)
        for (int x = 0; x < ww; x++) {
            if (!m[y * ww + x]) continue;
            float dx = x0 + x - sx, dy = y0 + y - sy;
            if (dx * dx + dy * dy <= seedR2) { seen[y * ww + x] = 1; q.push_back(y * ww + x); }
        }
    double sumx = 0, sumy = 0; int cnt = 0; float maxd = 0, tipx = 0, tipy = 0;
    float ringR = 1.5f * sr;
    for (size_t k = 0; k < q.size(); k++) {
        int i = q[k], x = i % ww, y = i / ww;
        float dx = x0 + x - sx, dy = y0 + y - sy, d = std::sqrt(dx * dx + dy * dy);
        if (d > ringR) {
            sumx += x0 + x; sumy += y0 + y; cnt++;
            if (d > maxd) { maxd = d; tipx = (float)(x0 + x); tipy = (float)(y0 + y); }
        }
        for (int ddy = -1; ddy <= 1; ddy++)
            for (int ddx = -1; ddx <= 1; ddx++) {
                int xx = x + ddx, yy = y + ddy;
                if (xx < 0 || yy < 0 || xx >= ww || yy >= hh) continue;
                int j = yy * ww + xx;
                if (m[j] && !seen[j]) { seen[j] = 1; q.push_back(j); }
            }
    }
    if (cnt < 40 || maxd < 2.0f * sr) return false;      // glow ring only -> not aiming
    float mx = (float)(sumx / cnt), my = (float)(sumy / cnt);
    out[0] = 1;
    out[1] = (float)(std::atan2(my - sy, mx - sx) * 180.0 / 3.14159265);
    out[2] = std::max(0.f, std::min(1.f, maxd / R));
    out[3] = tipx; out[4] = tipy; out[5] = maxd;
    return true;
}

}  // namespace carrom
