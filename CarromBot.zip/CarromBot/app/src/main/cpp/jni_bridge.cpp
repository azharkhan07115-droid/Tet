// JNI glue: Java Bitmap (ARGB_8888) -> carrom::Vision -> float[] result
#include <jni.h>
#include <android/bitmap.h>
#include <android/log.h>
#include "vision.h"

static carrom::Vision gVision;

// float layout: [0..3] board x,y,w,h | [4..7] field l,t,r,b | [8..15] pockets |
//               [16..17] thumb x,y | [18] mineBlack | [19] disc count | [20..] discs (type,x,y,r)
extern "C" JNIEXPORT jint JNICALL
Java_com_carrombot_tool_vision_NativeVision_detect(JNIEnv* env, jclass, jobject bmp, jfloatArray out, jint width, jint height) {
    AndroidBitmapInfo info;
    if (AndroidBitmap_getInfo(env, bmp, &info) != ANDROID_BITMAP_RESULT_SUCCESS) return -1;
    if (info.format != ANDROID_BITMAP_FORMAT_RGBA_8888) return -2;
    void* px = nullptr;
    if (AndroidBitmap_lockPixels(env, bmp, &px) != ANDROID_BITMAP_RESULT_SUCCESS) return -3;
    carrom::Result r = gVision.detect(static_cast<const uint8_t*>(px),
        (width > 0 && width < (jint)info.width) ? width : (int)info.width,
        (height > 0 && height < (jint)info.height) ? height : (int)info.height, (int)info.stride);
    AndroidBitmap_unlockPixels(env, bmp);
    if (!r.ok) return 0;

    jsize cap = env->GetArrayLength(out);
    jfloat buf[20 + 4 * 48] = {0};
    for (int i = 0; i < 4; i++) { buf[i] = r.board[i]; buf[4 + i] = r.field[i]; }
    for (int i = 0; i < 8; i++) buf[8 + i] = r.pockets[i];
    buf[16] = r.thumb[0]; buf[17] = r.thumb[1];
    buf[18] = (jfloat)r.mineBlack;
    int n = (int)r.discs.size(); if (n > 48) n = 48;
    buf[19] = (jfloat)n;
    for (int i = 0; i < n; i++) {
        buf[20 + i * 4] = (jfloat)r.discs[i].type; buf[21 + i * 4] = r.discs[i].x;
        buf[22 + i * 4] = r.discs[i].y;            buf[23 + i * 4] = r.discs[i].r;
    }
    int total = 20 + n * 4;
    if (cap < total) return -4;
    env->SetFloatArrayRegion(out, 0, total, buf);
    return 1;
}

extern "C" JNIEXPORT void JNICALL
Java_com_carrombot_tool_vision_NativeVision_reset(JNIEnv*, jclass) { gVision.reset(); }
