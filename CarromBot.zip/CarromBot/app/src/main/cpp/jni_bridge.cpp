// JNI glue: vision, aim arrow, physics and shot planner - all native, no OpenCV.
#include <jni.h>
#include <android/bitmap.h>
#include <vector>
#include "vision.h"
#include "brain.h"

static carrom::Vision gVision;

// ---------------------------------------------------------------- vision
// float layout: [0..3] board x,y,w,h | [4..7] field l,t,r,b | [8..15] pockets |
//               [16..17] thumb x,y | [18] mineBlack | [19] disc count | [20..] discs (type,x,y,r)
extern "C" JNIEXPORT jint JNICALL
Java_com_carrombot_tool_vision_NativeVision_detect(JNIEnv* env, jclass, jobject bmp, jfloatArray out, jint width, jint height) {
    AndroidBitmapInfo info;
    if (AndroidBitmap_getInfo(env, bmp, &info) != ANDROID_BITMAP_RESULT_SUCCESS) return -1;
    if (info.format != ANDROID_BITMAP_FORMAT_RGBA_8888) return -2;
    void* px = nullptr;
    if (AndroidBitmap_lockPixels(env, bmp, &px) != ANDROID_BITMAP_RESULT_SUCCESS) return -3;
    carrom::Result r = gVision.detect(static_cast<const uint8_t*>(px),
        (width > 0 && width < (jint)info.width) ? width : (int)info.width,
        (height > 0 && height < (jint)info.height) ? height : (int)info.height, (int)info.stride);
    AndroidBitmap_unlockPixels(env, bmp);
    if (!r.ok) return 0;

    jsize cap = env->GetArrayLength(out);
    jfloat buf[20 + 4 * 48] = {0};
    for (int i = 0; i < 4; i++) { buf[i] = r.board[i]; buf[4 + i] = r.field[i]; }
    for (int i = 0; i < 8; i++) buf[8 + i] = r.pockets[i];
    buf[16] = r.thumb[0]; buf[17] = r.thumb[1];
    buf[18] = (jfloat)r.mineBlack;
    int n = (int)r.discs.size(); if (n > 48) n = 48;
    buf[19] = (jfloat)n;
    for (int i = 0; i < n; i++) {
        buf[20 + i * 4] = (jfloat)r.discs[i].type; buf[21 + i * 4] = r.discs[i].x;
        buf[22 + i * 4] = r.discs[i].y;            buf[23 + i * 4] = r.discs[i].r;
    }
    int total = 20 + n * 4;
    if (cap < total) return -4;
    env->SetFloatArrayRegion(out, 0, total, buf);
    return 1;
}

extern "C" JNIEXPORT void JNICALL
Java_com_carrombot_tool_vision_NativeVision_reset(JNIEnv*, jclass) { gVision.reset(); }

// out[6] = present, angleDeg, power, tipX, tipY, lengthPx
extern "C" JNIEXPORT jint JNICALL
Java_com_carrombot_tool_vision_NativeVision_detectAim(JNIEnv* env, jclass, jobject bmp, jint width, jint height,
        jfloat sx, jfloat sy, jfloat sr, jfloat L, jfloat R, jfloatArray fieldArr, jfloatArray out) {
    AndroidBitmapInfo info;
    if (AndroidBitmap_getInfo(env, bmp, &info) != ANDROID_BITMAP_RESULT_SUCCESS) return -1;
    if (info.format != ANDROID_BITMAP_FORMAT_RGBA_8888) return -2;
    void* px = nullptr;
    if (AndroidBitmap_lockPixels(env, bmp, &px) != ANDROID_BITMAP_RESULT_SUCCESS) return -3;
    float o[6];
    float fld[4];
    env->GetFloatArrayRegion(fieldArr, 0, 4, fld);
    bool ok = carrom::detectAim(static_cast<const uint8_t*>(px),
        (width > 0 && width < (jint)info.width) ? width : (int)info.width,
        (height > 0 && height < (jint)info.height) ? height : (int)info.height,
        (int)info.stride, sx, sy, sr, L, R, fld, o);
    AndroidBitmap_unlockPixels(env, bmp);
    env->SetFloatArrayRegion(out, 0, 6, o);
    return ok ? 1 : 0;
}

// out[11] = found, x, y, r, glow, aim, angleDeg, power, tipX, tipY, lengthPx
extern "C" JNIEXPORT jint JNICALL
Java_com_carrombot_tool_vision_NativeVision_track(JNIEnv* env, jclass, jobject bmp, jint width, jint height,
        jfloatArray fieldArr, jfloat baselineY, jfloat L, jfloat R, jfloatArray out) {
    AndroidBitmapInfo info;
    if (AndroidBitmap_getInfo(env, bmp, &info) != ANDROID_BITMAP_RESULT_SUCCESS) return -1;
    if (info.format != ANDROID_BITMAP_FORMAT_RGBA_8888) return -2;
    void* px = nullptr;
    if (AndroidBitmap_lockPixels(env, bmp, &px) != ANDROID_BITMAP_RESULT_SUCCESS) return -3;
    float fld[4];
    env->GetFloatArrayRegion(fieldArr, 0, 4, fld);
    carrom::Track t = carrom::trackStriker(static_cast<const uint8_t*>(px),
        (width > 0 && width < (jint)info.width) ? width : (int)info.width,
        (height > 0 && height < (jint)info.height) ? height : (int)info.height,
        (int)info.stride, fld, baselineY, L, R);
    AndroidBitmap_unlockPixels(env, bmp);
    jfloat o[11] = {t.found ? 1.f : 0.f, t.x, t.y, t.r, t.glow, t.aim ? 1.f : 0.f, t.angle, t.power, t.tipX, t.tipY, t.len};
    env->SetFloatArrayRegion(out, 0, 11, o);
    return t.found ? 1 : 0;
}

// ---------------------------------------------------------------- brain (physics + planner)
// state: [0]=n | [1..4]=field l,t,r,b | [5]=pocketR | [6..13]=pockets | [14]=L | [15..] n x (type,x,y,r)
// prm  : [0]=friction [1]=restitution [2]=rangeL [3]=dragFull [4]=margin [5]=mode [6]=allowSlide [7]=powerPolicy
static void decode(const jfloat* s, const jfloat* pr, carrom::Geo& g, std::vector<carrom::BPiece>& P, carrom::Params& p) {
    int n = (int)s[0]; if (n > 48) n = 48;
    g.fl = s[1]; g.ft = s[2]; g.fr = s[3]; g.fb = s[4]; g.pocketR = s[5];
    for (int i = 0; i < 8; i++) g.pk[i] = s[6 + i];
    g.L = s[14];
    P.clear();
    for (int i = 0; i < n; i++) P.push_back({(int)s[15 + i * 4], s[16 + i * 4], s[17 + i * 4], s[18 + i * 4]});
    p.friction = pr[0]; p.restitution = pr[1]; p.rangeL = pr[2]; p.dragFull = pr[3]; p.margin = pr[4];
    p.mode = (int)pr[5]; p.allowSlide = pr[6] > 0.5f; p.powerPolicy = (int)pr[7];
}

// out: [0]=found [1]=angle [2]=power [3]=strikerX [4]=score [5]=predMine [6]=candidates [7]=prob
extern "C" JNIEXPORT jint JNICALL
Java_com_carrombot_tool_engine_NativeBrain_plan(JNIEnv* env, jclass, jfloatArray state, jfloatArray prm, jfloatArray out) {
    jfloat* s = env->GetFloatArrayElements(state, nullptr);
    jfloat* pr = env->GetFloatArrayElements(prm, nullptr);
    carrom::Geo g; std::vector<carrom::BPiece> P; carrom::Params p;
    decode(s, pr, g, P, p);
    env->ReleaseFloatArrayElements(state, s, JNI_ABORT);
    env->ReleaseFloatArrayElements(prm, pr, JNI_ABORT);
    carrom::PlanOut r = carrom::plan(g, P, p);
    jfloat o[8] = {r.found ? 1.f : 0.f, r.angle, r.power, r.strikerX, r.score, (jfloat)r.predMine, (jfloat)r.candidates, r.prob};
    env->SetFloatArrayRegion(out, 0, 8, o);
    return r.found ? 1 : 0;
}

// out: [0]=potMine [1]=potOpp [2]=potQueen [3]=strikerPotted [4]=score [5]=nPotted [6]=nTraj
//      then nPotted indices, then per trajectory: idx,type,potted,endX,endY,r,nPts, x0,y0,x1,y1 ...
extern "C" JNIEXPORT jint JNICALL
Java_com_carrombot_tool_engine_NativeBrain_simulate(JNIEnv* env, jclass, jfloatArray state, jfloat angle, jfloat power,
        jfloatArray prm, jint record, jfloatArray out) {
    jfloat* s = env->GetFloatArrayElements(state, nullptr);
    jfloat* pr = env->GetFloatArrayElements(prm, nullptr);
    carrom::Geo g; std::vector<carrom::BPiece> P; carrom::Params p;
    decode(s, pr, g, P, p);
    env->ReleaseFloatArrayElements(state, s, JNI_ABORT);
    env->ReleaseFloatArrayElements(prm, pr, JNI_ABORT);
    carrom::SimOut o;
    carrom::simulate(g, P, angle, power, p, record != 0, o);

    std::vector<jfloat> buf;
    buf.reserve(2048);
    buf.push_back((jfloat)o.potMine); buf.push_back((jfloat)o.potOpp); buf.push_back((jfloat)o.potQueen);
    buf.push_back(o.strikerPotted ? 1.f : 0.f); buf.push_back(o.score);
    buf.push_back((jfloat)o.potted.size()); buf.push_back((jfloat)o.trajs.size());
    for (int idx : o.potted) buf.push_back((jfloat)idx);
    jsize cap = env->GetArrayLength(out);
    size_t nTraj = 0;
    for (const carrom::Traj& t : o.trajs) {
        size_t need = 7 + t.pts.size();
        if (buf.size() + need > (size_t)cap) break;
        buf.push_back((jfloat)t.idx); buf.push_back((jfloat)t.type); buf.push_back(t.potted ? 1.f : 0.f);
        buf.push_back(t.endX); buf.push_back(t.endY); buf.push_back(t.r);
        buf.push_back((jfloat)(t.pts.size() / 2));
        for (float v : t.pts) buf.push_back(v);
        nTraj++;
    }
    buf[6] = (jfloat)nTraj;
    if ((jsize)buf.size() > cap) return -1;
    env->SetFloatArrayRegion(out, 0, (jsize)buf.size(), buf.data());
    return (jint)buf.size();
}
