#include "auth.h"
#include "SecureLogin.h"
#include <ctime>
#include <mutex>

namespace carrom_auth {
namespace {
std::mutex g_mu;
bool g_unlocked = false;
SecureAuth::SessionState g_session;
}  // namespace

bool unlocked() { std::lock_guard<std::mutex> l(g_mu); return g_unlocked; }

void lock() {
    std::lock_guard<std::mutex> l(g_mu);
    g_unlocked = false;
    SecureAuth::SecureWipe(g_session.token);
    g_session = SecureAuth::SessionState();
}

bool hasSecret() { return SecureAuth::HasRealSecret(); }

std::string serial(const std::string& userKey, const std::string& androidId,
                   const std::string& model, const std::string& brand) {
    return SecureAuth::ComputeSerial(userKey, androidId, model, brand);
}

bool sign(const std::string& endpoint, const std::string& body, long long& ts, std::string& sigHex) {
    if (!SecureAuth::HasRealSecret()) return false;
    SecureAuth::SignedRequest r = SecureAuth::SignRequest(endpoint, body);
    ts = (long long)r.timestamp; sigHex = r.signature;
    return !sigHex.empty();
}

int complete(const std::string& token, const std::string& hwid, long long remainingSeconds) {
    if (token.size() < 16 || hwid.size() < 16) return -1;
    if (remainingSeconds <= 0) return -5;                                    // license already over
    std::lock_guard<std::mutex> l(g_mu);
    g_session.token = token;
    g_session.hwid = hwid;
    g_session.loginTimestamp = (int64_t)std::time(nullptr);
    // the session ends with the license, or after 12 h at the latest (the app re-verifies every 10 minutes)
    g_session.expirySeconds = remainingSeconds < 43200 ? remainingSeconds : 43200;
    g_unlocked = true;
    return 1;
}

bool healthy(const std::string& freshHwid) {
    bool ok;
    { std::lock_guard<std::mutex> l(g_mu); ok = g_unlocked && SecureAuth::IsSessionHealthy(g_session, freshHwid); }
    if (!ok) lock();
    return ok;
}

}  // namespace carrom_auth
