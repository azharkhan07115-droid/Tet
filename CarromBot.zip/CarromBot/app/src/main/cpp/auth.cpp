#include "auth.h"
#include "SecureLogin.h"
#include "AuthBlobs.h"
#include "Md5.h"
#include <ctime>
#include <mutex>
#include <cctype>

namespace carrom_auth {
namespace {
std::mutex g_mu;
bool g_unlocked = false;
SecureAuth::SessionState g_session;

// cipher[i] = plain[i] XOR HMAC_SHA256(key, "blk" + i/32)[i%32]   (see tools/gen_blobs.py)
std::string unblob(const uint8_t* c, size_t n) {
    std::string key;
    key.append(reinterpret_cast<const char*>(kK1), sizeof(kK1));
    key.append(reinterpret_cast<const char*>(kK2), sizeof(kK2));
    key.append(reinterpret_cast<const char*>(kK3), sizeof(kK3));
    std::string out(n, '\0');
    for (size_t i = 0; i < n; i += 32) {
        auto ks = SecureAuth::HmacSha256Raw(key, "blk" + std::to_string(i / 32));
        for (size_t j = 0; j < 32 && i + j < n; j++) out[i + j] = (char)(c[i + j] ^ ks[j]);
    }
    SecureAuth::SecureWipe(key);
    return out;
}
}  // namespace

std::string url() { return unblob(kUrlBlob, kUrlLen); }

bool unlocked() { std::lock_guard<std::mutex> l(g_mu); return g_unlocked; }

void lock() {
    std::lock_guard<std::mutex> l(g_mu);
    g_unlocked = false;
    SecureAuth::SecureWipe(g_session.token);
    g_session = SecureAuth::SessionState();
}

bool hasSecret() { return SecureAuth::HasRealSecret(); }

std::string serial(const std::string& userKey, const std::string& androidId,
                   const std::string& model, const std::string& brand) {
    return SecureAuth::ComputeSerial(userKey, androidId, model, brand);
}

bool sign(const std::string& endpoint, const std::string& body, long long& ts, std::string& sigHex) {
    if (!SecureAuth::HasRealSecret()) return false;
    SecureAuth::SignedRequest r = SecureAuth::SignRequest(endpoint, body);
    ts = (long long)r.timestamp; sigHex = r.signature;
    return !sigHex.empty();
}

int complete(const std::string& userKey, const std::string& game, const std::string& token,
             const std::string& serial, long long rng, long long remainingSeconds) {
    if (token.size() < 16 || serial.size() < 16 || userKey.empty()) return -1;
    if (remainingSeconds <= 0) return -5;                                    // license already over

    // 1) the answer must come from the real server: token == MD5("PUBG-" + userKey + "-" + serial + "-" + SECRET)
    //    NOTE: the server (index.ts, handleConnect) ALWAYS uses the literal "PUBG" here, whatever "game" the app sends.
    std::string secret = unblob(kSecBlob, kSecLen);
    std::string plain = std::string("PUBG") + "-" + userKey + "-" + serial + "-" + secret;
    std::string expect = carrom_md5::hex(plain);
    SecureAuth::SecureWipe(secret); SecureAuth::SecureWipe(plain);
    std::string got = token;
    for (auto& ch : got) ch = (char)std::tolower((unsigned char)ch);
    bool same = SecureAuth::ConstantTimeEquals(expect, got);
    SecureAuth::SecureWipe(expect);
    if (!same) return -2;

    // 2) the answer must be fresh (blocks replaying an old captured "OK" answer)
    if (rng + 30 <= (long long)std::time(nullptr)) return -3;

    std::lock_guard<std::mutex> l(g_mu);
    g_session.token = token;
    g_session.hwid = serial;
    g_session.loginTimestamp = (int64_t)std::time(nullptr);
    // the session ends with the license, or after 12 h at the latest (the app re-verifies every 10 minutes)
    g_session.expirySeconds = remainingSeconds < 43200 ? remainingSeconds : 43200;
    g_unlocked = true;
    return 1;
}

bool healthy(const std::string& freshHwid) {
    bool ok;
    { std::lock_guard<std::mutex> l(g_mu); ok = g_unlocked && SecureAuth::IsSessionHealthy(g_session, freshHwid); }
    if (!ok) lock();
    return ok;
}

}  // namespace carrom_auth
