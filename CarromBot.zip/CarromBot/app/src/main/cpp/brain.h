// Physics + shot planner in C++ (no OpenCV, no Java).  All coordinates are screen pixels (y down).
#pragma once
#include <vector>

namespace carrom {

struct BPiece { int type; float x, y, r; };   // 0 striker, 1 mine, 2 opponent, 3 queen

struct Geo {
    float fl = 0, ft = 0, fr = 0, fb = 0;     // playing field (walls)
    float pk[8] = {0};                        // 4 pockets
    float pocketR = 30;
    float L = 700;                            // board size
};

struct Params {
    float friction = 0.985f, restitution = 0.80f, rangeL = 3.0f, dragFull = 0.222f, margin = 1.25f;
    int mode = 0;                             // 0 SAFE, 1 AGGRO, 2 PRO
    bool allowSlide = true;
    int powerPolicy = 1;                      // 0 = just enough power, 1 = full power preferred (checked by physics)
};

struct Traj { int idx, type; bool potted; float endX, endY, r; std::vector<float> pts; };

struct SimOut {
    int potMine = 0, potOpp = 0, potQueen = 0;
    bool strikerPotted = false;
    float score = 0;
    std::vector<int> potted;                  // indices of potted pieces
    std::vector<Traj> trajs;                  // only filled when record == true
};

struct PlanOut {
    bool found = false;
    float angle = 0, power = 0, strikerX = 0, score = 0;
    float prob = 0;                           // estimated chance (0..1) that the shot pots
    int predMine = 0, candidates = 0;
};

// one shot: striker (first type-0 piece) leaves with the given angle / power
void simulate(const Geo& g, std::vector<BPiece> pieces, float angleDeg, float power,
              const Params& p, bool record, SimOut& out);

// best shot (and best striker x on the baseline when p.allowSlide)
PlanOut plan(const Geo& g, const std::vector<BPiece>& pieces, const Params& p);

}  // namespace carrom
