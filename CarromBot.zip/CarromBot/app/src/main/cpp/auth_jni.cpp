// JNI for com.carrombot.tool.auth.NativeAuth
#include <jni.h>
#include <string>
#include "auth.h"

namespace {
std::string str(JNIEnv* env, jstring s) {
    if (!s) return std::string();
    const char* c = env->GetStringUTFChars(s, nullptr);
    std::string r(c ? c : "");
    if (c) env->ReleaseStringUTFChars(s, c);
    return r;
}
}  // namespace

extern "C" {

JNIEXPORT jstring JNICALL
Java_com_carrombot_tool_auth_NativeAuth_serial(JNIEnv* env, jclass, jstring userKey, jstring androidId, jstring model, jstring brand) {
    return env->NewStringUTF(carrom_auth::serial(str(env, userKey), str(env, androidId), str(env, model), str(env, brand)).c_str());
}

JNIEXPORT jboolean JNICALL
Java_com_carrombot_tool_auth_NativeAuth_hasSecret(JNIEnv*, jclass) { return carrom_auth::hasSecret() ? JNI_TRUE : JNI_FALSE; }

// returns {timestamp, signature} or null when there is no real secret yet
JNIEXPORT jobjectArray JNICALL
Java_com_carrombot_tool_auth_NativeAuth_sign(JNIEnv* env, jclass, jstring endpoint, jstring body) {
    long long ts = 0; std::string sig;
    if (!carrom_auth::sign(str(env, endpoint), str(env, body), ts, sig)) return nullptr;
    jclass sc = env->FindClass("java/lang/String");
    jobjectArray arr = env->NewObjectArray(2, sc, nullptr);
    env->SetObjectArrayElement(arr, 0, env->NewStringUTF(std::to_string(ts).c_str()));
    env->SetObjectArrayElement(arr, 1, env->NewStringUTF(sig.c_str()));
    return arr;
}

JNIEXPORT jint JNICALL
Java_com_carrombot_tool_auth_NativeAuth_complete(JNIEnv* env, jclass, jstring token, jstring hwid, jlong remainingSeconds) {
    return carrom_auth::complete(str(env, token), str(env, hwid), (long long)remainingSeconds);
}

JNIEXPORT jboolean JNICALL
Java_com_carrombot_tool_auth_NativeAuth_healthy(JNIEnv* env, jclass, jstring hwid) {
    return carrom_auth::healthy(str(env, hwid)) ? JNI_TRUE : JNI_FALSE;
}

JNIEXPORT jboolean JNICALL
Java_com_carrombot_tool_auth_NativeAuth_isUnlocked(JNIEnv*, jclass) { return carrom_auth::unlocked() ? JNI_TRUE : JNI_FALSE; }

JNIEXPORT void JNICALL
Java_com_carrombot_tool_auth_NativeAuth_lock(JNIEnv*, jclass) { carrom_auth::lock(); }

}  // extern "C"
