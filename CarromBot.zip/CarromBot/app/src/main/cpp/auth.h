// License session (native). Vision / physics / planner only work while a REAL server answer was accepted here.
#pragma once
#include <string>

namespace carrom_auth {

bool unlocked();
void lock();
bool hasSecret();                                   // false while BuildSecret() is still the placeholder

std::string serial(const std::string& userKey, const std::string& androidId,
                   const std::string& model, const std::string& brand);

// V2 request signature: HMAC-SHA256(secret, "{ts}:{endpoint}:{sha256(body)}"). false = no real secret yet.
bool sign(const std::string& endpoint, const std::string& body, long long& ts, std::string& sigHex);

// Accepts the data of a successful /connect answer: 1 = unlocked, <0 = rejected.
int complete(const std::string& token, const std::string& hwid, long long remainingSeconds);

// token / device id / time window / debugger / instrumentation checks. false => locked again.
bool healthy(const std::string& freshHwid);

}  // namespace carrom_auth
