// License session (native). Vision / physics / planner only work while a REAL server answer was accepted here.
#pragma once
#include <string>

namespace carrom_auth {

bool unlocked();
void lock();
bool hasSecret();                                   // false while BuildSecret() is still the placeholder

std::string serial(const std::string& userKey, const std::string& androidId,
                   const std::string& model, const std::string& brand);

// V2 request signature: HMAC-SHA256(secret, "{ts}:{endpoint}:{sha256(body)}"). false = no real secret yet.
bool sign(const std::string& endpoint, const std::string& body, long long& ts, std::string& sigHex);

// License server URL, decrypted only for the moment of the request (never stored as a plain constant).
std::string url();

// Accepts the data of a successful /connect answer. The server token must equal
// MD5(game-userKey-serial-SECRET) (secret lives encrypted in native code) and "rng" (server time) must be fresh,
// so a fake / redirected server cannot unlock anything.
// 1 = unlocked, -1 malformed, -2 token mismatch (fake server), -3 stale answer (clock / replay), -5 expired.
int complete(const std::string& userKey, const std::string& game, const std::string& token,
             const std::string& serial, long long rng, long long remainingSeconds);

// token / device id / time window / debugger / instrumentation checks. false => locked again.
bool healthy(const std::string& freshHwid);

}  // namespace carrom_auth
