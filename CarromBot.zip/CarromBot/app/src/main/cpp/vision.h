// Carrom board vision - plain C++17, no OpenCV. Works on a raw RGBA frame.
#pragma once
#include <cstdint>
#include <vector>

namespace carrom {

struct Disc { int type; float x, y, r; };   // type: 0 striker, 1 white, 2 black, 3 queen

struct Result {
    bool ok = false;
    float board[4] = {0, 0, 0, 0};      // wooden board rect: x, y, w, h
    float field[4] = {0, 0, 0, 0};      // inner playing field: l, t, r, b (walls)
    float pockets[8] = {0};             // 4 x (x, y)
    float thumb[2] = {0, 0};            // striker slider thumb (0,0 = not visible)
    int mineBlack = 1;                  // 1 = my pucks are black
    std::vector<Disc> discs;
};

class Vision {
public:
    Result detect(const uint8_t* rgba, int w, int h, int strideBytes);
    void reset() { hasBoard_ = false; frameNo_ = 0; thumbYCache_ = -1; }

private:
    bool hasBoard_ = false;
    int bx_ = 0, by_ = 0, bw_ = 0, bh_ = 0;
    float pk_[8] = {0};
    int mineBlack_ = 1;
    int frameNo_ = 0;
    float thumbYCache_ = -1;
};

/**
 * Reads the game's own aim arrow (deep orange, starts at the striker) while the player drags.
 * out = {present, angleDeg, power, tipX, tipY, lengthPx};  power = length / R  (R = full-pull radius in px)
 */
bool detectAim(const uint8_t* rgba, int w, int h, int strideBytes,
               float sx, float sy, float sr, float L, float R,
               const float field[4], float out[6]);

}  // namespace carrom
