// Carrom board vision - plain C++17, no OpenCV. Works on a raw RGBA frame.
#pragma once
#include <cstdint>
#include <vector>

namespace carrom {

struct Disc { int type; float x, y, r; };   // type: 0 striker, 1 white, 2 black, 3 queen

struct Result {
    bool ok = false;
    float board[4] = {0, 0, 0, 0};      // wooden board rect: x, y, w, h
    float field[4] = {0, 0, 0, 0};      // inner playing field: l, t, r, b (walls)
    float pockets[8] = {0};             // 4 x (x, y)
    float thumb[2] = {0, 0};            // striker slider thumb (0,0 = not visible)
    int mineBlack = 1;                  // 1 = my pucks are black
    std::vector<Disc> discs;
};

class Vision {
public:
    Result detect(const uint8_t* rgba, int w, int h, int strideBytes);
    void reset() { hasBoard_ = false; frameNo_ = 0; thumbYCache_ = -1; }

private:
    bool hasBoard_ = false;
    int bx_ = 0, by_ = 0, bw_ = 0, bh_ = 0;
    float pk_[8] = {0};
    int mineBlack_ = 1;
    int frameNo_ = 0;
    float thumbYCache_ = -1;
};

/**
 * Reads the game's own aim arrow (deep orange, starts at the striker) while the player drags.
 * out = {present, angleDeg, power, tipX, tipY, lengthPx};  power = length / R  (R = full-pull radius in px)
 */
bool detectAim(const uint8_t* rgba, int w, int h, int strideBytes,
               float sx, float sy, float sr, float L, float R,
               const float field[4], float out[6]);

/**
 * Per-frame tracker (about 1-2 ms): finds MY striker on its baseline, tells whether it glows
 * (= the game says "your turn"), and reads the aim arrow while the player drags.
 */
struct Track {
    bool found = false;               // striker visible on my baseline
    float x = 0, y = 0, r = 0;        // striker centre / radius
    float glow = 0;                   // 0..1 orange "your turn" ring fraction
    bool aim = false;                 // player is dragging (aim arrow visible)
    float angle = 0, power = 0, tipX = 0, tipY = 0, len = 0;
};
Track trackStriker(const uint8_t* rgba, int w, int h, int strideBytes,
                   const float field[4], float baselineY, float L, float R);

}  // namespace carrom
