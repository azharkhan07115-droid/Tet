package com.carrombot.tool.data;
public enum PieceType { STRIKER, MINE, OPP, QUEEN, UNKNOWN }
