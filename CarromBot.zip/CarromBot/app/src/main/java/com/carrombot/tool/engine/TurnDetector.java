package com.carrombot.tool.engine;

import com.carrombot.tool.data.GameConfig;
import com.carrombot.tool.data.GameState;
import com.carrombot.tool.data.Piece;

public class TurnDetector {
    private GameConfig cfg;
    public TurnDetector(GameConfig c) { this.cfg = c; }

    public boolean isMyTurn(GameState s) {
        if (s == null) return false;
        int votes = 0;
        Piece striker = s.striker();
        if (striker != null) {
            if (striker.confidence > 0.7f) votes++;
            if (striker.y > (s.screenHApprox() * 0.55)) votes++;
            if (striker.speed() < 5) votes++;
        }
        if (s.allStopped(5.0)) votes++;
        return votes >= cfg.votesRequired;
    }
}
