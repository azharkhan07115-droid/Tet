package com.carrombot.tool.engine;

import com.carrombot.tool.data.GameConfig;
import com.carrombot.tool.data.GameState;
import com.carrombot.tool.data.Piece;

public class TurnDetector {
    private GameConfig cfg;
    private int stableFrames = 0;

    public TurnDetector(GameConfig c) { this.cfg = c; }

    /**
     * My turn = striker sits on MY baseline (lower part of the board) and nothing
     * on the board is moving for 2 frames in a row.
     */
    public boolean isMyTurn(GameState s) {
        if (s == null) { stableFrames = 0; return false; }
        Piece striker = s.striker();
        if (striker == null) { stableFrames = 0; return false; }

        boolean myHalf;
        double still;
        if (s.boardH > 0) {
            myHalf = striker.y > s.boardY + s.boardH * 0.6;
            still = 0.006 * s.boardW;
        } else {
            myHalf = striker.y > (cfg.screenH * 0.55);
            still = 4.0;
        }
        if (!myHalf || s.maxMotion() > still) { stableFrames = 0; return false; }
        stableFrames++;
        return stableFrames >= 2;
    }
}
