package com.carrombot.tool.remote;

/** Simple quality tiers for uploaded shots. */
public class DataQualityFilter {
    public static final String GOLD = "GOLD", SILVER = "SILVER", BRONZE = "BRONZE", DISCARD = "DISCARD";

    /**
     * @param conf         detection confidence 0..1
     * @param predMine     own pieces the simulation expected to pot
     * @param actualMine   own pieces really potted (counted from the board)
     */
    public static String tier(double conf, int predMine, int actualMine) {
        if (conf < 0.85) return DISCARD;
        if (Math.abs(predMine - actualMine) > 1) return DISCARD;
        if (conf > 0.95 && predMine == actualMine) return GOLD;
        if (conf > 0.90) return SILVER;
        return BRONZE;
    }
}
