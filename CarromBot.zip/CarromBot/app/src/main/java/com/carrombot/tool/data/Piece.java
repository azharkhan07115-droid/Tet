package com.carrombot.tool.data;

public class Piece {
    public String id;
    public PieceType type;
    public double x, y, r, vx, vy;
    public boolean potted;
    public float confidence = 1f;

    public Piece() {}
    public Piece(String id, PieceType t, double x, double y, double r) {
        this.id = id; this.type = t; this.x = x; this.y = y; this.r = r;
    }
    public Piece copy() {
        Piece p = new Piece(id, type, x, y, r);
        p.vx = vx; p.vy = vy; p.potted = potted; p.confidence = confidence;
        return p;
    }
    public double speed() { return Math.hypot(vx, vy); }
}
