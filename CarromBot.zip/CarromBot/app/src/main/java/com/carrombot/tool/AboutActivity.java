package com.carrombot.tool;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;

/** About & Team page kept local: no telemetry and no external links. */
public class AboutActivity extends Activity {
    @Override protected void onCreate(Bundle state) {
        super.onCreate(state);
        setContentView(R.layout.activity_about);
        View back = findViewById(R.id.btn_about_back);
        if (back != null) back.setOnClickListener(v -> finish());
    }
}
