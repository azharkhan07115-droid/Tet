package com.carrombot.tool.ui;

import android.animation.ValueAnimator;
import android.content.Context;
import android.graphics.*;
import android.util.AttributeSet;
import android.view.View;
import android.view.animation.DecelerateInterpolator;

import java.util.Locale;
import java.util.Random;

/** Glowing green storage ring with the percentage in red in the middle (one 0.9 s sweep when it first appears). */
public class StorageRingView extends View {
    private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint text = new Paint(Paint.ANTI_ALIAS_FLAG);
    private int percent = 0;
    private float usedGb = 0, totalGb = 0;
    private float shown = 0f;   // 0..1 animation progress
    private final float[][] dots = new float[46][3];

    public StorageRingView(Context c) { super(c); init(); }
    public StorageRingView(Context c, AttributeSet a) { super(c, a); init(); }

    private void init() {
        Random rnd = new Random(7);
        for (float[] d : dots) { d[0] = rnd.nextFloat() * 360f; d[1] = 1.02f + rnd.nextFloat() * 0.38f; d[2] = 0.6f + rnd.nextFloat() * 1.6f; }
        text.setTextAlign(Paint.Align.CENTER);
    }

    public void setData(int pct, float used, float total) {
        percent = Math.max(0, Math.min(100, pct)); usedGb = used; totalGb = total;
        ValueAnimator va = ValueAnimator.ofFloat(0f, 1f);
        va.setDuration(900); va.setInterpolator(new DecelerateInterpolator());
        va.addUpdateListener(a -> { shown = (float) a.getAnimatedValue(); invalidate(); });
        va.start();
    }

    @Override protected void onDraw(Canvas c) {
        float d = getResources().getDisplayMetrics().density;
        float w = getWidth(), h = getHeight(), cx = w / 2f, cy = h / 2f;
        float R = Math.min(w, h) / 2f * 0.66f;                          // ring radius (leaves room for the sparks)
        // soft red halo behind the ring
        p.setStyle(Paint.Style.FILL);
        p.setShader(new RadialGradient(cx, cy, R * 1.25f, new int[]{0x00000000, 0x00E5484D, 0x40E5484D, 0x00E5484D},
            new float[]{0f, 0.72f, 0.9f, 1f}, Shader.TileMode.CLAMP));
        c.drawCircle(cx, cy, R * 1.25f, p);
        p.setShader(null);
        // green sparks
        p.setColor(0xFF2BD67B);
        for (float[] s : dots) {
            double a = Math.toRadians(s[0]);
            p.setAlpha((int) (40 + 90 * (s[2] / 2.2f)));
            c.drawCircle(cx + (float) Math.cos(a) * R * s[1], cy + (float) Math.sin(a) * R * s[1], s[2] * d, p);
        }
        p.setAlpha(255);
        // track
        RectF oval = new RectF(cx - R, cy - R, cx + R, cy + R);
        p.setStyle(Paint.Style.STROKE); p.setStrokeCap(Paint.Cap.ROUND);
        p.setStrokeWidth(12 * d); p.setColor(0xFF1B2B23);
        c.drawCircle(cx, cy, R, p);
        // glowing progress arc (starts near the top, clockwise)
        float sweep = 360f * percent / 100f * shown;
        float start = -85f;
        int[] widths = {30, 22, 15, 9};
        int[] alphas = {0x14, 0x26, 0x55, 0xFF};
        for (int i = 0; i < 4; i++) {
            p.setStrokeWidth(widths[i] * d);
            p.setColor(i == 3 ? 0xFF2BD67B : 0x002BD67B | (alphas[i] << 24));
            c.drawArc(oval, start, sweep, false, p);
        }
        p.setStrokeWidth(3 * d); p.setColor(0xFFB9FFD8);
        c.drawArc(oval, start, sweep, false, p);
        // texts
        text.setTypeface(Typeface.create("sans-serif-light", Typeface.NORMAL));
        text.setColor(0xFFE5484D); text.setTextSize(R * 0.52f);
        c.drawText(Math.round(percent * shown) + "%", cx, cy + R * 0.12f, text);
        text.setTypeface(Typeface.create("sans-serif-medium", Typeface.NORMAL));
        text.setTextSize(R * 0.17f); text.setLetterSpacing(0.06f);
        c.drawText("STORAGE", cx, cy + R * 0.38f, text);
        text.setLetterSpacing(0f); text.setColor(0xFF2F8A5B); text.setTextSize(R * 0.17f);
        c.drawText(String.format(Locale.US, "%.1f / %.1f GB", usedGb, totalGb), cx, cy + R * 0.6f, text);
    }
}
