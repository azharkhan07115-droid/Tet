package com.carrombot.tool.data;

public class Shot {
    public double angleDeg, power;
    public long durationMs;
    public double startX, startY, endX, endY;
    public double expectedScore;
    public Piece striker;
    public Shot() {}
    public Shot(Piece s, double a, double p, double ex, double ey) {
        this.striker = s; this.angleDeg = a; this.power = p;
        this.startX = s.x; this.startY = s.y; this.endX = ex; this.endY = ey;
    }
}
