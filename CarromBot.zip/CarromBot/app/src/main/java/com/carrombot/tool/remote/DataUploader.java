package com.carrombot.tool.remote;

import android.content.Context;
import com.carrombot.tool.util.Constants;
import com.carrombot.tool.util.Log;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.*;

public class DataUploader {
    private final Context ctx;
    private int pending = 0;

    public DataUploader(Context c) { this.ctx = c; }

    public synchronized void enqueue(String matchJson) {
        try {
            File dir = new File(ctx.getExternalFilesDir(null), "pending");
            if (!dir.exists()) dir.mkdirs();
            File f = new File(dir, "m_" + System.currentTimeMillis() + ".json");
            try (FileWriter fw = new FileWriter(f)) { fw.write(matchJson); }
            pending++;
            if (pending >= 5) uploadAll();
        } catch (Throwable t) { Log.e("enqueue err", t); }
    }

    public synchronized void uploadAll() {
        new Thread(() -> {
            try {
                File dir = new File(ctx.getExternalFilesDir(null), "pending");
                if (!dir.exists()) return;
                File[] files = dir.listFiles();
                if (files == null || files.length == 0) { pending = 0; return; }
                JSONArray matches = new JSONArray();
                for (File f : files) {
                    StringBuilder sb = new StringBuilder();
                    try (BufferedReader br = new BufferedReader(new FileReader(f))) {
                        String l; while ((l = br.readLine()) != null) sb.append(l);
                    }
                    try { matches.put(new JSONObject(sb.toString())); } catch (Throwable ignored) {}
                }
                String body = "{\"matches\":" + matches.toString() + "}";
                if (ApiClient.post(Constants.API_UPLOAD, body) != null) {
                    for (File f : files) f.delete();
                    pending = 0;
                }
            } catch (Throwable t) { Log.e("upload err", t); }
        }).start();
    }
}
