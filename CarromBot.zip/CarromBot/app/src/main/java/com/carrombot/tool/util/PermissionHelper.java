package com.carrombot.tool.util;

import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.provider.Settings;

public class PermissionHelper {

    public static boolean hasOverlay(Context c) {
        return Build.VERSION.SDK_INT < 23 || Settings.canDrawOverlays(c);
    }

    public static Intent overlayIntent(Context c) {
        return new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
            Uri.parse("package:" + c.getPackageName()));
    }

    public static boolean isAccessibilityEnabled(Context c) {
        try {
            String enabled = Settings.Secure.getString(c.getContentResolver(),
                Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES);
            if (enabled == null) return false;
            return enabled.contains(c.getPackageName() + "/") &&
                   enabled.contains("AutoAccessibilityService");
        } catch (Exception e) { return false; }
    }

    public static Intent accessibilityIntent() {
        return new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS);
    }

    public static boolean isGameInstalled(Context c) {
        try {
            c.getPackageManager().getPackageInfo(Constants.TARGET_PACKAGE, 0);
            return true;
        } catch (Exception e) { return false; }
    }

    public static Intent launchGame(Context c) {
        Intent i = c.getPackageManager().getLaunchIntentForPackage(Constants.TARGET_PACKAGE);
        if (i != null) { i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK); return i; }
        return new Intent(Intent.ACTION_VIEW, Uri.parse(Constants.PLAYSTORE_URL));
    }
}
