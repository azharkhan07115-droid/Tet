package com.carrombot.tool.engine;

import com.carrombot.tool.data.*;
import java.util.ArrayList;
import java.util.List;

public class PhysicsSimulator {
    private GameConfig cfg;
    public PhysicsSimulator(GameConfig c) { this.cfg = c; }
    public void updateConfig(GameConfig c) { this.cfg = c; }

    public Shot findBestShot(GameState state, String mode) {
        Piece striker = state.striker();
        if (striker == null) return null;
        Shot best = null;
        double bestScore = -Double.MAX_VALUE;
        int powerSteps = "PRO".equals(mode) ? 100 : 60;
        double bias = "AGGRESSIVE".equals(mode) ? 1.3 : 1.0;
        int stepInc = "PRO".equals(mode) ? 1 : 2;

        for (int a = 0; a < 360; a += stepInc) {
            double angle = a * Math.PI / 180.0;
            for (int p = 1; p <= powerSteps; p++) {
                double power = p / (double) powerSteps;
                GameState clone = state.clone();
                Piece s = clone.striker();
                s.vx = Math.cos(angle) * power * cfg.maxSpeed;
                s.vy = Math.sin(angle) * power * cfg.maxSpeed;
                SimResult r = simulate(clone, false);
                double score = scoreResult(r) * bias;
                if (score > bestScore) {
                    bestScore = score;
                    Shot shot = new Shot(s, angle * 180 / Math.PI, power,
                        s.x, s.y - power * 300);
                    shot.expectedScore = score;
                    best = shot;
                }
            }
        }
        return best;
    }

    public GameConfig cfg() { return cfg; }

    /**
     * Physics: sub-stepped movement (no tunnelling), wall bounce, elastic collisions,
     * rolling friction, pockets. With record=true every moving piece gets its own
     * trajectory polyline (including wall bounces) for the line preview.
     */
    public SimResult simulate(GameState state, boolean record) {
        SimResult res = new SimResult();
        java.util.Map<String, Trajectory> tm = new java.util.LinkedHashMap<>();
        java.util.Map<String, double[]> init = new java.util.HashMap<>();
        for (Piece p : state.pieces) init.put(p.id, new double[]{p.x, p.y});

        double wl, wr, wt, wb;
        if (state.hasField()) { wl = state.fieldL; wr = state.fieldR; wt = state.fieldT; wb = state.fieldB; }
        else if (state.boardW > 0) {
            wl = state.boardX + 0.03 * state.boardW; wr = state.boardX + state.boardW - 0.03 * state.boardW;
            wt = state.boardY + 0.03 * state.boardH; wb = state.boardY + state.boardH - 0.03 * state.boardH;
        } else { wl = -1e9; wr = 1e9; wt = -1e9; wb = 1e9; }

        for (int step = 0; step < 1500; step++) {
            double vmax = 0;
            for (Piece p : state.pieces) if (!p.potted) vmax = Math.max(vmax, p.speed());
            if (vmax < 0.05) break;
            int sub = (int) Math.min(12, Math.max(1, Math.ceil(vmax / 6.0)));
            double fs = Math.pow(cfg.friction, 1.0 / sub);

            for (int k = 0; k < sub; k++) {
                for (Piece p : state.pieces) {
                    if (p.potted) continue;
                    p.x += p.vx / sub; p.y += p.vy / sub;
                }
                for (Piece p : state.pieces) {
                    if (p.potted) continue;
                    if (p.x - p.r < wl) { p.x = wl + p.r; p.vx = Math.abs(p.vx) * cfg.restitution; }
                    if (p.x + p.r > wr) { p.x = wr - p.r; p.vx = -Math.abs(p.vx) * cfg.restitution; }
                    if (p.y - p.r < wt) { p.y = wt + p.r; p.vy = Math.abs(p.vy) * cfg.restitution; }
                    if (p.y + p.r > wb) { p.y = wb - p.r; p.vy = -Math.abs(p.vy) * cfg.restitution; }
                }
                for (Piece p : state.pieces) {
                    if (p.potted) continue;
                    if (state.inPocket(p)) {
                        p.potted = true; p.vx = p.vy = 0;
                        if (p.type == PieceType.STRIKER) res.strikerPotted = true;
                        else {
                            res.pottedIds.add(p.id);
                            if (p.type == PieceType.QUEEN) res.queenPotted = true;
                        }
                        if (record) {
                            Trajectory t = trajOf(tm, init, p);
                            double[] pk = nearestPocket(state, p);
                            t.points.add(new double[]{pk[0], pk[1]});
                            t.potted = true; t.potX = pk[0]; t.potY = pk[1];
                        }
                    }
                }
                List<Piece> list = state.pieces;
                for (int i = 0; i < list.size(); i++)
                    for (int j = i + 1; j < list.size(); j++) {
                        Piece a = list.get(i), b = list.get(j);
                        if (a.potted || b.potted) continue;
                        collide(a, b);
                    }
                if (record) {
                    for (Piece p : state.pieces) {
                        if (p.potted || p.speed() < 0.05) continue;
                        Trajectory t = trajOf(tm, init, p);
                        if (t.points.size() < 6000) t.points.add(new double[]{p.x, p.y});
                    }
                }
                for (Piece p : state.pieces) {
                    if (p.potted) continue;
                    p.vx *= fs; p.vy *= fs;
                    if (p.speed() < 0.04) { p.vx = 0; p.vy = 0; }
                }
            }
        }
        Piece st = state.striker();
        if (st != null) { res.strikerEndX = st.x; res.strikerEndY = st.y; }
        if (record) {
            for (Piece p : state.pieces) {
                Trajectory t = tm.get(p.id);
                if (t == null) continue;
                if (t.potted) { t.endX = t.potX; t.endY = t.potY; }
                else { t.endX = p.x; t.endY = p.y; }
                res.trajectories.add(t);
            }
        }
        res.score = scoreResult(res);
        return res;
    }

    private double[] nearestPocket(GameState s, Piece p) {
        double best = 1e18; double[] bp = s.pockets[0];
        for (double[] pk : s.pockets) {
            double d = Math.hypot(p.x - pk[0], p.y - pk[1]);
            if (d < best) { best = d; bp = pk; }
        }
        return bp;
    }

    private Trajectory trajOf(java.util.Map<String, Trajectory> tm, java.util.Map<String, double[]> init, Piece p) {
        Trajectory t = tm.get(p.id);
        if (t != null) return t;
        t = new Trajectory();
        t.id = p.id; t.r = p.r;
        if (p.type == PieceType.STRIKER) t.type = Trajectory.Type.STRIKER;
        else if (p.type == PieceType.QUEEN) t.type = Trajectory.Type.QUEEN;
        else if (p.type == PieceType.OPP) t.type = Trajectory.Type.OPP_PUCK;
        else t.type = Trajectory.Type.PUCK;
        double[] i0 = init.get(p.id);
        if (i0 != null) t.points.add(new double[]{i0[0], i0[1]});
        tm.put(p.id, t);
        return t;
    }

    private void collide(Piece a, Piece b) {
        double dx = b.x - a.x, dy = b.y - a.y;
        double dist = Math.hypot(dx, dy);
        double minD = a.r + b.r;
        if (dist >= minD || dist < 1e-6) return;
        double nx = dx / dist, ny = dy / dist;
        double dvx = b.vx - a.vx, dvy = b.vy - a.vy;
        double vn = dvx * nx + dvy * ny;
        if (vn > 0) return;
        b.vx -= vn * nx; b.vy -= vn * ny;
        a.vx += vn * nx; a.vy += vn * ny;
        double overlap = minD - dist;
        a.x -= nx * overlap / 2; a.y -= ny * overlap / 2;
        b.x += nx * overlap / 2; b.y += ny * overlap / 2;
    }

    private double scoreResult(SimResult r) {
        double s = r.pottedIds.size() * 10;
        if (r.queenPotted) s += 20;
        if (r.strikerPotted) s -= 15;
        return s;
    }
}
