package com.carrombot.tool.engine;

import com.carrombot.tool.data.*;
import java.util.ArrayList;
import java.util.List;

public class PhysicsSimulator {
    private GameConfig cfg;
    public PhysicsSimulator(GameConfig c) { this.cfg = c; }
    public void updateConfig(GameConfig c) { this.cfg = c; }

    public Shot findBestShot(GameState state, String mode) {
        Piece striker = state.striker();
        if (striker == null) return null;
        Shot best = null;
        double bestScore = -Double.MAX_VALUE;
        int powerSteps = "PRO".equals(mode) ? 100 : 60;
        double bias = "AGGRESSIVE".equals(mode) ? 1.3 : 1.0;
        int stepInc = "PRO".equals(mode) ? 1 : 2;

        for (int a = 0; a < 360; a += stepInc) {
            double angle = a * Math.PI / 180.0;
            for (int p = 1; p <= powerSteps; p++) {
                double power = p / (double) powerSteps;
                GameState clone = state.clone();
                Piece s = clone.striker();
                s.vx = Math.cos(angle) * power * cfg.maxSpeed;
                s.vy = Math.sin(angle) * power * cfg.maxSpeed;
                SimResult r = simulate(clone, false);
                double score = scoreResult(r) * bias;
                if (score > bestScore) {
                    bestScore = score;
                    Shot shot = new Shot(s, angle * 180 / Math.PI, power,
                        s.x, s.y - power * 300);
                    shot.expectedScore = score;
                    best = shot;
                }
            }
        }
        return best;
    }

    public SimResult simulate(GameState state, boolean record) {
        SimResult res = new SimResult();
        for (int step = 0; step < 800; step++) {
            for (Piece p : state.pieces) {
                if (p.potted) continue;
                p.x += p.vx; p.y += p.vy;
            }
            if (record && step % 3 == 0) {
                for (Piece p : state.pieces) {
                    if (p.potted) continue;
                    Trajectory t = getT(res.trajectories, p.type);
                    t.points.add(new double[]{p.x, p.y});
                }
            }
            if (state.boardW > 0) {
                double wl = state.boardX + 0.03 * state.boardW;
                double wr = state.boardX + state.boardW - 0.03 * state.boardW;
                double wt = state.boardY + 0.03 * state.boardH;
                double wb = state.boardY + state.boardH - 0.03 * state.boardH;
                for (Piece p : state.pieces) {
                    if (p.potted) continue;
                    if (p.x - p.r < wl) { p.x = wl + p.r; p.vx = Math.abs(p.vx) * 0.8; }
                    if (p.x + p.r > wr) { p.x = wr - p.r; p.vx = -Math.abs(p.vx) * 0.8; }
                    if (p.y - p.r < wt) { p.y = wt + p.r; p.vy = Math.abs(p.vy) * 0.8; }
                    if (p.y + p.r > wb) { p.y = wb - p.r; p.vy = -Math.abs(p.vy) * 0.8; }
                }
            }
            for (Piece p : state.pieces) {
                if (p.potted) continue;
                if (state.inPocket(p)) {
                    p.potted = true; p.vx = p.vy = 0;
                    if (p.type == PieceType.STRIKER) res.strikerPotted = true;
                    else {
                        res.pottedIds.add(p.id);
                        if (p.type == PieceType.QUEEN) res.queenPotted = true;
                    }
                    if (record) {
                        Trajectory t = getT(res.trajectories, p.type);
                        t.potted = true; t.potX = p.x; t.potY = p.y;
                    }
                }
            }
            List<Piece> list = state.pieces;
            for (int i = 0; i < list.size(); i++)
                for (int j = i + 1; j < list.size(); j++) {
                    Piece a = list.get(i), b = list.get(j);
                    if (a.potted || b.potted) continue;
                    collide(a, b);
                }
            for (Piece p : state.pieces) {
                if (p.potted) continue;
                p.vx *= cfg.friction; p.vy *= cfg.friction;
                if (Math.abs(p.vx) < 0.05) p.vx = 0;
                if (Math.abs(p.vy) < 0.05) p.vy = 0;
            }
            if (state.allStopped(0.1)) break;
        }
        Piece st = state.striker();
        if (st != null) { res.strikerEndX = st.x; res.strikerEndY = st.y; }
        res.score = scoreResult(res);
        return res;
    }

    private Trajectory getT(List<Trajectory> list, PieceType pt) {
        Trajectory.Type t = Trajectory.Type.PUCK;
        if (pt == PieceType.STRIKER) t = Trajectory.Type.STRIKER;
        else if (pt == PieceType.QUEEN) t = Trajectory.Type.QUEEN;
        else if (pt == PieceType.OPP) t = Trajectory.Type.OPP_PUCK;
        for (Trajectory tr : list) if (tr.type == t) return tr;
        Trajectory tr = new Trajectory(); tr.type = t; list.add(tr);
        return tr;
    }

    private void collide(Piece a, Piece b) {
        double dx = b.x - a.x, dy = b.y - a.y;
        double dist = Math.hypot(dx, dy);
        double minD = a.r + b.r;
        if (dist >= minD || dist < 1e-6) return;
        double nx = dx / dist, ny = dy / dist;
        double dvx = b.vx - a.vx, dvy = b.vy - a.vy;
        double vn = dvx * nx + dvy * ny;
        if (vn > 0) return;
        b.vx -= vn * nx; b.vy -= vn * ny;
        a.vx += vn * nx; a.vy += vn * ny;
        double overlap = minD - dist;
        a.x -= nx * overlap / 2; a.y -= ny * overlap / 2;
        b.x += nx * overlap / 2; b.y += ny * overlap / 2;
    }

    private double scoreResult(SimResult r) {
        double s = r.pottedIds.size() * 10;
        if (r.queenPotted) s += 20;
        if (r.strikerPotted) s -= 15;
        return s;
    }
}
