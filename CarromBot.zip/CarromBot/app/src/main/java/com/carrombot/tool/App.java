package com.carrombot.tool;

import android.app.ActivityManager;
import android.app.Application;
import android.app.ApplicationExitInfo;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Build;
import com.carrombot.tool.util.Constants;
import com.carrombot.tool.util.Log;
import com.carrombot.tool.util.Prefs;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.InputStream;
import java.util.List;

public class App extends Application {

    @Override
    public void onCreate() {
        super.onCreate();
        // Crash screen apne alag process (:crash) me chalti hai, wahan kuch init nahi karna.
        if (processName().endsWith(":crash")) return;

        installCrashReporter();
        checkNativeCrash();
        try { Prefs.init(this); } catch (Throwable t) { Log.e("Prefs init", t); }
        // NOTE: OpenCV ab yahan load nahi hota (startup crash se bachne ke liye).
        // Wo AutoPlayEngine start hone par load hota hai.
    }

    private String processName() {
        if (Build.VERSION.SDK_INT >= 28) return Application.getProcessName();
        try (BufferedReader r = new BufferedReader(new FileReader("/proc/self/cmdline"))) {
            String s = r.readLine();
            return s == null ? "" : s.trim();
        } catch (Throwable t) { return ""; }
    }

    private String deviceInfo() {
        String abi = "?";
        try { abi = Build.SUPPORTED_ABIS[0]; } catch (Throwable ignored) {}
        return "Device: " + Build.MANUFACTURER + " " + Build.MODEL
            + " | Android " + Build.VERSION.RELEASE + " (SDK " + Build.VERSION.SDK_INT + ")"
            + " | ABI " + abi;
    }

    private void showCrashScreen(String text) {
        try {
            Intent i = new Intent(this, CrashActivity.class);
            i.putExtra("trace", text);
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
            startActivity(i);
        } catch (Throwable ignored) {}
    }

    /** Java crash pakadta hai: alag crash screen dikhata hai + agli baar bhi dialog me dikhega. */
    private void installCrashReporter() {
        Thread.setDefaultUncaughtExceptionHandler((t, e) -> {
            String text = deviceInfo() + "\nThread: " + t.getName() + "\n\n"
                + android.util.Log.getStackTraceString(e);
            if (text.length() > 20000) text = text.substring(0, 20000);
            try {
                getSharedPreferences(Constants.PREFS, MODE_PRIVATE)
                    .edit().putString("last_crash", text).commit();
            } catch (Throwable ignored) {}
            showCrashScreen(text);
            try { Thread.sleep(800); } catch (InterruptedException ignored) {}
            android.os.Process.killProcess(android.os.Process.myPid());
            System.exit(10);
        });
    }

    /** Native crash (SIGSEGV etc.) Java handler se nahi pakda jata; Android 11+ par exit info se padhte hain. */
    private void checkNativeCrash() {
        if (Build.VERSION.SDK_INT < 30) return;
        try {
            ActivityManager am = (ActivityManager) getSystemService(ACTIVITY_SERVICE);
            List<ApplicationExitInfo> list = am.getHistoricalProcessExitReasons(null, 0, 6);
            if (list == null) return;
            for (ApplicationExitInfo info : list) {
                if (!getPackageName().equals(info.getProcessName())) continue;
                SharedPreferences sp = getSharedPreferences(Constants.PREFS, MODE_PRIVATE);
                if (info.getTimestamp() <= sp.getLong("exit_ts", 0)) return;
                sp.edit().putLong("exit_ts", info.getTimestamp()).commit();
                if (info.getReason() != ApplicationExitInfo.REASON_CRASH_NATIVE) return;
                StringBuilder sb = new StringBuilder(deviceInfo())
                    .append("\nNATIVE CRASH\n").append(info.getDescription()).append("\n");
                try (InputStream in = info.getTraceInputStream()) {
                    if (in != null) {
                        byte[] buf = new byte[3000];
                        int n = in.read(buf);
                        if (n > 0) sb.append(new String(buf, 0, n));
                    }
                } catch (Throwable ignored) {}
                showCrashScreen(sb.toString());
                return;
            }
        } catch (Throwable ignored) {}
    }
}
