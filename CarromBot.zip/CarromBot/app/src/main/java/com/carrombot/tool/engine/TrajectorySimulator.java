package com.carrombot.tool.engine;

import com.carrombot.tool.data.*;
import java.util.ArrayList;
import java.util.List;

public class TrajectorySimulator {
    private final PhysicsSimulator physics;
    public TrajectorySimulator(PhysicsSimulator p) { this.physics = p; }

    /** Simulate one shot. A full-power striker rolls cfg.rangeL board-lengths. */
    public SimResult run(GameState state, double angleDeg, double power, boolean record) {
        GameState clone = state.clone();
        Piece s = clone.striker();
        if (s == null) return null;
        GameConfig cfg = physics.cfg();
        double L = clone.boardW > 0 ? (clone.boardW + clone.boardH) / 2.0 : 1000.0;
        double v0 = power * cfg.rangeL * L * (1.0 - cfg.friction);
        double a = Math.toRadians(angleDeg);
        s.vx = Math.cos(a) * v0;
        s.vy = Math.sin(a) * v0;
        return physics.simulate(clone, record);
    }

    public List<Trajectory> simulateLines(GameState state, Shot shot) {
        SimResult r = run(state, shot.angleDeg, shot.power, true);
        return r == null ? new ArrayList<Trajectory>() : r.trajectories;
    }

    public List<double[]> getPotMarkers(List<Trajectory> trajs) {
        List<double[]> out = new ArrayList<>();
        for (Trajectory t : trajs) if (t.potted) out.add(new double[]{t.potX, t.potY});
        return out;
    }
}
