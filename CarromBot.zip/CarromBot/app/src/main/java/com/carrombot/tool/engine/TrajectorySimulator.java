package com.carrombot.tool.engine;

import com.carrombot.tool.data.*;
import java.util.ArrayList;
import java.util.List;

public class TrajectorySimulator {
    private final PhysicsSimulator physics;
    public TrajectorySimulator(PhysicsSimulator p) { this.physics = p; }

    public List<Trajectory> simulateLines(GameState state, Shot shot) {
        GameState clone = state.clone();
        Piece s = clone.striker();
        if (s == null) return new ArrayList<>();
        double angleRad = shot.angleDeg * Math.PI / 180.0;
        s.vx = Math.cos(angleRad) * shot.power * 80;
        s.vy = Math.sin(angleRad) * shot.power * 80;
        SimResult r = physics.simulate(clone, true);
        return r.trajectories;
    }

    public List<double[]> getPotMarkers(List<Trajectory> trajs) {
        List<double[]> out = new ArrayList<>();
        for (Trajectory t : trajs) if (t.potted) out.add(new double[]{t.potX, t.potY});
        return out;
    }
}
