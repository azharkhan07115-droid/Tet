package com.carrombot.tool.util;

public class Log {
    private static final String TAG = "CarromBot";
    public static void d(String m) { android.util.Log.d(TAG, m); }
    public static void i(String m) { android.util.Log.i(TAG, m); }
    public static void w(String m) { android.util.Log.w(TAG, m); }
    public static void e(String m) { android.util.Log.e(TAG, m); }
    public static void e(String m, Throwable t) { android.util.Log.e(TAG, m, t); }
}
