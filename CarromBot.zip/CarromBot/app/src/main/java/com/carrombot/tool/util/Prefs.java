package com.carrombot.tool.util;

import android.content.Context;
import android.content.SharedPreferences;

public class Prefs {
    private static SharedPreferences sp;

    public static void init(Context c) {
        if (sp == null) sp = c.getApplicationContext()
            .getSharedPreferences(Constants.PREFS, Context.MODE_PRIVATE);
    }
    public static void putString(String k, String v) { sp.edit().putString(k, v).apply(); }
    public static String getString(String k, String d) { return sp.getString(k, d); }
    public static void putInt(String k, int v) { sp.edit().putInt(k, v).apply(); }
    public static int getInt(String k, int d) { return sp.getInt(k, d); }
    public static void putBool(String k, boolean v) { sp.edit().putBoolean(k, v).apply(); }
    public static boolean getBool(String k, boolean d) { return sp.getBoolean(k, d); }
    public static void putLong(String k, long v) { sp.edit().putLong(k, v).apply(); }
    public static long getLong(String k, long d) { return sp.getLong(k, d); }
}
