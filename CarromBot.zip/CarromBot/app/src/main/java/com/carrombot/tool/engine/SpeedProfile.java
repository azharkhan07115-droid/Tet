package com.carrombot.tool.engine;

/** How fast the bot plays. FULL = computer speed, MEDIUM = human, LOW = slow human. */
public class SpeedProfile {
    public final String name;
    public final int reactMin, reactMax;     // ms the bot "thinks" when its turn starts
    public final int dragMin, dragMax;       // ms the aim drag takes
    public final int slideMs;                // ms one slider drag takes
    public final int previewMs;              // ms the shot lines stay before the shot
    public final int afterShotMs;            // ms to wait after the shot before looking again
    public final int pollMs;                 // sleep between checks while waiting
    public final double angleJitter;         // +- degrees of human aiming error
    public final double powerJitter;         // +- fraction of power error

    private SpeedProfile(String n, int rMin, int rMax, int dMin, int dMax, int slide, int prev,
                         int after, int poll, double aj, double pj) {
        name = n; reactMin = rMin; reactMax = rMax; dragMin = dMin; dragMax = dMax; slideMs = slide;
        previewMs = prev; afterShotMs = after; pollMs = poll; angleJitter = aj; powerJitter = pj;
    }

    public static final SpeedProfile FULL   = new SpeedProfile("FULL",      0,   20,  90, 130, 110,   30, 250, 8, 0.0, 0.0);
    public static final SpeedProfile MEDIUM = new SpeedProfile("MEDIUM",  600, 1300, 300, 450, 450,  350, 500, 25, 0.12, 0.02);
    public static final SpeedProfile LOW    = new SpeedProfile("LOW",    1800, 3600, 550, 900, 900,  900, 900, 40, 0.25, 0.04);

    public static SpeedProfile of(String s) {
        if ("LOW".equals(s)) return LOW;
        if ("MEDIUM".equals(s)) return MEDIUM;
        return FULL;
    }
}
