package com.carrombot.tool.ui;

import android.content.Context;
import android.graphics.PixelFormat;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.view.WindowManager;
import com.carrombot.tool.data.Trajectory;
import com.carrombot.tool.util.Log;

import java.util.List;

/** All window operations are posted to the main thread (adding views from the bot thread silently failed). */
public class LineOverlayManager {
    private final Handler ui = new Handler(Looper.getMainLooper());
    private WindowManager wm;
    private TrajectoryOverlay ov;
    private WindowManager.LayoutParams lp;
    private boolean visible = false;

    public void init(final Context c) {
        ui.post(() -> {
            try {
                wm = (WindowManager) c.getSystemService(Context.WINDOW_SERVICE);
                ov = new TrajectoryOverlay(c);
                int type = Build.VERSION.SDK_INT >= 26
                    ? WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
                    : WindowManager.LayoutParams.TYPE_PHONE;
                lp = new WindowManager.LayoutParams(
                    WindowManager.LayoutParams.MATCH_PARENT,
                    WindowManager.LayoutParams.MATCH_PARENT,
                    type,
                    WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                        | WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
                        | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
                    PixelFormat.TRANSLUCENT);
                lp.gravity = Gravity.TOP | Gravity.START;
            } catch (Throwable t) { Log.e("line mgr", t); }
        });
    }

    public void show(final List<Trajectory> t, final List<double[]> p) {
        ui.post(() -> {
            if (wm == null || ov == null) return;
            try {
                if (!visible) { wm.addView(ov, lp); visible = true; }
                ov.set(t, p);
            } catch (Throwable t2) { Log.e("line show", t2); }
        });
    }

    public void hide() {
        ui.post(() -> {
            if (wm == null || ov == null) return;
            try {
                if (visible) { ov.clear(); wm.removeView(ov); visible = false; }
            } catch (Throwable ignored) {}
        });
    }
}
