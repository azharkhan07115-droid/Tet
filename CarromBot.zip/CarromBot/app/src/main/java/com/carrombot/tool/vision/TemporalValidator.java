package com.carrombot.tool.vision;

import java.util.HashMap;
import java.util.LinkedList;
import java.util.Map;
import java.util.Queue;

public class TemporalValidator {
    private static final int WINDOW = 5;
    private final Map<String, Queue<double[]>> history = new HashMap<>();

    public void push(String id, double x, double y) {
        Queue<double[]> q = history.get(id);
        if (q == null) { q = new LinkedList<>(); history.put(id, q); }
        q.add(new double[]{x, y});
        if (q.size() > WINDOW) q.poll();
    }
    public void clear() { history.clear(); }
}
