package com.carrombot.tool.auth;

import android.content.Context;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import com.carrombot.tool.util.Constants;
import com.carrombot.tool.util.Log;
import com.carrombot.tool.util.Prefs;

import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.cert.CertificateException;
import java.security.cert.X509Certificate;
import javax.net.ssl.HttpsURLConnection;
import javax.net.ssl.SSLContext;
import javax.net.ssl.TrustManager;
import javax.net.ssl.TrustManagerFactory;
import javax.net.ssl.X509TrustManager;

/**
 * Login against the Sarkar API (POST /connect). V2 = HMAC-SHA256 signed request (needs the real client secret
 * in SecureLogin.h), otherwise the V1 static signature. The session itself lives in C++ (NativeAuth).
 */
public class LicenseManager {

    public interface Callback { void onResult(boolean ok, String message); }

    private static volatile String hwid = "";
    private static volatile int daysLeft = 0;
    private static volatile String modName = "";
    private static final Handler ui = new Handler(Looper.getMainLooper());

    public static boolean isUnlocked() { return NativeAuth.isUnlocked(); }
    public static int daysLeft() { return daysLeft; }
    public static String modName() { return modName; }
    public static String hwid() { return hwid; }
    public static String savedKey() { try { return Prefs.getString(Constants.PREF_LICENSE_KEY, ""); } catch (Throwable t) { return ""; } }

    public static void logout() { NativeAuth.lock(); Prefs.putString(Constants.PREF_LICENSE_KEY, ""); }

    /** Verifies the key on the server (background thread). The callback runs on the main thread. */
    public static void verify(final Context ctx, final String keyIn, final Callback cb) {
        final String key = keyIn == null ? "" : keyIn.trim();
        new Thread(() -> {
            final String[] r = doVerify(ctx.getApplicationContext(), key);
            final boolean ok = "ok".equals(r[0]);
            if (ok) Prefs.putString(Constants.PREF_LICENSE_KEY, key);
            ui.post(() -> { if (cb != null) cb.onResult(ok, r[1]); });
        }, "license-verify").start();
    }

    /** Silent re-check while the bot runs. @return 0 = still valid, 1 = server said NO (locked now), 2 = could not reach server */
    public static int revalidate(Context ctx) {
        String key = savedKey();
        if (key.isEmpty()) { NativeAuth.lock(); return 1; }
        String[] r = doVerify(ctx.getApplicationContext(), key);
        if ("ok".equals(r[0])) return 0;
        if ("net".equals(r[0])) return 2;
        NativeAuth.lock();
        return 1;
    }

    // ----------------------------------------------------------------------------------------
    /** @return {code, message}   code: "ok" | "net" | "denied" */
    private static String[] doVerify(Context ctx, String key) {
        if (key.length() < 4) return new String[]{"denied", "Enter your license key."};
        try {
            String androidId = Settings.Secure.getString(ctx.getContentResolver(), Settings.Secure.ANDROID_ID);
            if (androidId == null) androidId = "";
            String model = Build.MODEL == null ? "" : Build.MODEL;
            String brand = Build.BRAND == null ? "" : Build.BRAND;
            String serial = NativeAuth.serial(key, androidId, model, brand);

            JSONObject dev = new JSONObject();
            dev.put("model", model); dev.put("brand", brand); dev.put("android_id", androidId);
            JSONObject payload = new JSONObject();
            payload.put("game", Constants.LICENSE_GAME);
            payload.put("user_key", key);
            payload.put("serial", serial);
            payload.put("device_info", dev);
            String body = payload.toString();                       // exactly this string is signed AND sent

            HttpURLConnection c = (HttpURLConnection) new URL(NativeAuth.url()).openConnection();
            if (c instanceof HttpsURLConnection && Constants.PIN_ENFORCE) {
                ((HttpsURLConnection) c).setSSLSocketFactory(pinnedContext().getSocketFactory());
            }
            c.setRequestMethod("POST");
            c.setConnectTimeout(12000); c.setReadTimeout(15000);
            c.setDoOutput(true);
            c.setRequestProperty("Content-Type", "application/json");
            String[] sig = NativeAuth.hasSecret() ? NativeAuth.sign("connect", body) : null;
            if (sig != null) {                                       // V2 HMAC-SHA256
                c.setRequestProperty("X-Time", sig[0]);
                c.setRequestProperty("X-Signature", sig[1]);
                c.setRequestProperty("X-Client-Version", "V2");
            } else {                                                 // V1 static (legacy)
                c.setRequestProperty("X-Client-Signature", "SARKAR-CPP-V1");
            }
            try (OutputStream o = c.getOutputStream()) { o.write(body.getBytes(StandardCharsets.UTF_8)); }

            int code = c.getResponseCode();
            InputStream in = code >= 400 ? c.getErrorStream() : c.getInputStream();
            String text = readAll(in);
            JSONObject json;
            try { json = new JSONObject(text); }
            catch (Throwable t) { return new String[]{"net", "Bad answer from server (HTTP " + code + "): " + snippet(text)}; }

            boolean accepted = isOk(json.opt("status")) || (!json.has("status") && isTrue(json.opt("success")));
            if (!accepted) {
                String reason = jstr(json, "reason");
                if (reason.isEmpty()) reason = jstr(json, "error");
                String message = jstr(json, "message");
                if (message.isEmpty()) message = jstr(json, "msg");
                if (message.isEmpty()) message = jstr(json, "detail");
                Log.w("license denied HTTP " + code + ": " + text);
                return new String[]{"denied", explain(reason, message, code, text)};
            }

            JSONObject data = json.optJSONObject("data");
            if (data == null && json.has("token")) data = json;      // some servers answer flat
            if (data == null) return new String[]{"denied", "Server answer has no license data (HTTP " + code + "): " + snippet(text)};
            String token = jstr(data, "token");
            long rng = data.optLong("rng", 0);
            long remaining = data.optLong("remaining_seconds", 0);
            int days = data.optInt("days_remaining", 0);
            if (remaining <= 0 && days > 0) remaining = days * 86400L;
            int rc = NativeAuth.complete(key, Constants.LICENSE_GAME, token, serial, rng, remaining);
            if (rc != 1) {
                NativeAuth.lock();
                String why = rc == -5 ? "License expired."
                           : rc == -2 ? "Server answer is not authentic (token mismatch)."
                           : rc == -3 ? "Server answer too old - set automatic date & time and retry."
                           : "License answer rejected (" + rc + ").";
                return new String[]{"denied", why};
            }
            hwid = serial; daysLeft = days; modName = jstr(data, "mod_name");
            return new String[]{"ok", days > 0 ? "Active - " + days + " day" + (days == 1 ? "" : "s") + " left" : "Active"};
        } catch (java.net.UnknownHostException | java.net.SocketTimeoutException | java.net.ConnectException e) {
            return new String[]{"net", "No internet or server not reachable."};
        } catch (javax.net.ssl.SSLException e) {
            Log.w("TLS: " + e);
            return new String[]{"net", "Secure connection failed (" + e.getClass().getSimpleName() + ")."};
        } catch (Throwable t) {
            Log.e("license", t);
            return new String[]{"net", "Login error: " + t.getClass().getSimpleName()};
        }
    }

    private static String explain(String reason, String message, int httpCode, String raw) {
        switch (reason) {
            case "ACCESS_DENIED":      return "Access denied: the server did not accept this app's signature.";
            case "TIMESTAMP_EXPIRED":  return "Your phone clock is wrong. Turn on automatic date & time.";
            case "INVALID_SIGNATURE":  return "Server rejected the app signature (client secret does not match).";
            case "RATE_LIMITED":       return "Too many tries. Wait a minute and try again.";
            case "BLOCKED":            return "This connection is blocked by the server.";
            default:
                if (reason.isEmpty() && message.isEmpty())          // nothing readable -> show what the server really said
                    return "License error (HTTP " + httpCode + "): " + snippet(raw);
                return "License error: " + (reason.isEmpty() ? "DENIED" : reason) + (message.isEmpty() ? "" : " - " + message);
        }
    }

    /** JSON string that treats a missing key AND an explicit JSON null as "" (org.json would give the text "null"). */
    private static String jstr(JSONObject o, String k) {
        if (o == null || o.isNull(k)) return "";
        String v = o.optString(k, "");
        return v == null ? "" : v.trim();
    }

    /** success = true / "true" / "success" / the old protocol's numeric 69 */
    private static boolean isOk(Object v) {
        if (v instanceof Number && ((Number) v).intValue() == 69) return true;
        return isTrue(v);
    }

    private static boolean isTrue(Object v) {
        if (v instanceof Boolean) return (Boolean) v;
        if (v instanceof String) { String t = ((String) v).trim().toLowerCase(); return t.equals("true") || t.equals("success") || t.equals("ok"); }
        return false;
    }

    private static String snippet(String t) {
        if (t == null) return "(empty)";
        t = t.replaceAll("\\s+", " ").trim();
        return t.isEmpty() ? "(empty)" : (t.length() > 160 ? t.substring(0, 160) + "..." : t);
    }

    private static String readAll(InputStream in) throws Exception {
        if (in == null) return "";
        ByteArrayOutputStream bo = new ByteArrayOutputStream();
        byte[] buf = new byte[4096]; int n;
        while ((n = in.read(buf)) > 0) bo.write(buf, 0, n);
        return bo.toString("UTF-8");
    }

    // ---------- optional public-key pinning (Constants.PIN_ENFORCE) ----------
    private static SSLContext pinnedContext() throws Exception {
        TrustManagerFactory tmf = TrustManagerFactory.getInstance(TrustManagerFactory.getDefaultAlgorithm());
        tmf.init((java.security.KeyStore) null);
        X509TrustManager def = null;
        for (TrustManager tm : tmf.getTrustManagers()) if (tm instanceof X509TrustManager) { def = (X509TrustManager) tm; break; }
        final X509TrustManager base = def;
        X509TrustManager pin = new X509TrustManager() {
            @Override public void checkClientTrusted(X509Certificate[] chain, String t) throws CertificateException { base.checkClientTrusted(chain, t); }
            @Override public void checkServerTrusted(X509Certificate[] chain, String t) throws CertificateException {
                base.checkServerTrusted(chain, t);                       // normal validation first
                try {
                    MessageDigest md = MessageDigest.getInstance("SHA-256");
                    for (X509Certificate cert : chain) {                 // leaf OR intermediate may match the pin
                        String h = android.util.Base64.encodeToString(md.digest(cert.getPublicKey().getEncoded()), android.util.Base64.NO_WRAP);
                        if (h.equals(Constants.PIN_SHA256_B64)) return;
                    }
                } catch (Exception e) { throw new CertificateException(e); }
                throw new CertificateException("certificate pin mismatch");
            }
            @Override public X509Certificate[] getAcceptedIssuers() { return base.getAcceptedIssuers(); }
        };
        SSLContext ctx = SSLContext.getInstance("TLS");
        ctx.init(null, new TrustManager[]{pin}, null);
        return ctx;
    }
}
