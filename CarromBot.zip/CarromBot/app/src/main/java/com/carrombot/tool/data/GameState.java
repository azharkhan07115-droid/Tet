package com.carrombot.tool.data;

import java.util.ArrayList;
import java.util.List;

public class GameState {
    public List<Piece> pieces = new ArrayList<>();
    public double[][] pockets = new double[4][2];
    public double pocketRadius = 40;
    public boolean isMyTurn = false;
    public float detectionConfidence = 1f;
    public long timestamp;
    public double boardX, boardY, boardW, boardH;   // wooden board rect in screen pixels (0 = unknown)
    public double fieldL, fieldT, fieldR, fieldB;   // inner playing field (walls), derived from pockets
    public double thumbX, thumbY;                   // striker slider thumb (0 = not visible)

    public Piece striker() {
        for (Piece p : pieces) if (p.type == PieceType.STRIKER) return p;
        return null;
    }
    public List<Piece> pucks() {
        List<Piece> out = new ArrayList<>();
        for (Piece p : pieces) if (p.type != PieceType.STRIKER) out.add(p);
        return out;
    }
    public boolean inPocket(Piece p) {
        for (double[] pk : pockets)
            if (Math.hypot(p.x - pk[0], p.y - pk[1]) < pocketRadius) return true;
        return false;
    }
    public boolean allStopped(double t) {
        for (Piece p : pieces) if (!p.potted && p.speed() > t) return false;
        return true;
    }
    public double maxMotion() {
        double m = 0;
        for (Piece p : pieces) if (!p.potted && p.motion > m) m = p.motion;
        return m;
    }
    public boolean hasField() { return fieldR > fieldL && fieldB > fieldT; }
    public double fieldW() { return hasField() ? fieldR - fieldL : boardW; }
    /** board coordinate 0..1 across the playing field */
    public double nx(double x) { return hasField() ? (x - fieldL) / (fieldR - fieldL) : (x - boardX) / boardW; }
    public double ny(double y) { return hasField() ? (y - fieldT) / (fieldB - fieldT) : (y - boardY) / boardH; }
    public GameState clone() {
        GameState g = new GameState();
        g.pockets = pockets; g.pocketRadius = pocketRadius;
        g.isMyTurn = isMyTurn; g.detectionConfidence = detectionConfidence;
        g.timestamp = timestamp;
        g.boardX = boardX; g.boardY = boardY; g.boardW = boardW; g.boardH = boardH;
        g.fieldL = fieldL; g.fieldT = fieldT; g.fieldR = fieldR; g.fieldB = fieldB;
        g.thumbX = thumbX; g.thumbY = thumbY;
        for (Piece p : pieces) g.pieces.add(p.copy());
        return g;
    }
}
