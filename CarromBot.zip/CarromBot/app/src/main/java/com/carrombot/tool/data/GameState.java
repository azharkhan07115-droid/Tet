package com.carrombot.tool.data;

import java.util.ArrayList;
import java.util.List;

public class GameState {
    public List<Piece> pieces = new ArrayList<>();
    public double[][] pockets = new double[4][2];
    public double pocketRadius = 40;
    public boolean isMyTurn = false;
    public float detectionConfidence = 1f;
    public long timestamp;

    public Piece striker() {
        for (Piece p : pieces) if (p.type == PieceType.STRIKER) return p;
        return null;
    }
    public List<Piece> pucks() {
        List<Piece> out = new ArrayList<>();
        for (Piece p : pieces) if (p.type != PieceType.STRIKER) out.add(p);
        return out;
    }
    public boolean inPocket(Piece p) {
        for (double[] pk : pockets)
            if (Math.hypot(p.x - pk[0], p.y - pk[1]) < pocketRadius) return true;
        return false;
    }
    public boolean allStopped(double t) {
        for (Piece p : pieces) if (!p.potted && p.speed() > t) return false;
        return true;
    }
    public GameState clone() {
        GameState g = new GameState();
        g.pockets = pockets; g.pocketRadius = pocketRadius;
        g.isMyTurn = isMyTurn; g.detectionConfidence = detectionConfidence;
        g.timestamp = timestamp;
        for (Piece p : pieces) g.pieces.add(p.copy());
        return g;
    }
}
