package com.carrombot.tool.engine;

import com.carrombot.tool.vision.NativeVision;

/** C++ physics + shot planner (libcarromvision.so). See cpp/brain.cpp. */
public class NativeBrain {
    static { NativeVision.isLoaded(); }   // makes sure the library is loaded

    public static native int plan(float[] state, float[] prm, float[] out);
    public static native int simulate(float[] state, float angle, float power, float[] prm, int record, float[] out);
}
