package com.carrombot.tool.data;

import java.util.ArrayList;
import java.util.List;

public class Trajectory {
    public enum Type { STRIKER, PUCK, QUEEN, OPP_PUCK }
    public Type type = Type.PUCK;
    public String id = "";
    public double r = 0;                 // piece radius (px)
    public List<double[]> points = new ArrayList<>();
    public boolean potted = false;
    public double potX, potY;
    public double endX, endY;            // where the piece finally rests (or the pocket)
}
