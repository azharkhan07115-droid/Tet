package com.carrombot.tool.vision;

import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.PixelFormat;
import android.hardware.display.DisplayManager;
import android.hardware.display.VirtualDisplay;
import android.media.Image;
import android.media.ImageReader;
import android.media.projection.MediaProjection;
import android.media.projection.MediaProjectionManager;
import android.os.Handler;
import android.os.Looper;
import android.util.DisplayMetrics;
import android.view.WindowManager;
import com.carrombot.tool.util.Log;

import java.nio.ByteBuffer;

public class ScreenCapture {
    private static MediaProjection projection;
    private static VirtualDisplay virtualDisplay;
    private static ImageReader imageReader;
    private static int screenW, screenH, dpi;

    public static boolean init(Context ctx, int resultCode, Intent data) {
        try {
            MediaProjectionManager mpm = (MediaProjectionManager)
                ctx.getSystemService(Context.MEDIA_PROJECTION_SERVICE);
            projection = mpm.getMediaProjection(resultCode, data);
            if (projection == null) return false;
            projection.registerCallback(new MediaProjection.Callback() {
                @Override public void onStop() { release(); }
            }, new Handler(Looper.getMainLooper()));

            DisplayMetrics dm = new DisplayMetrics();
            WindowManager wm = (WindowManager) ctx.getSystemService(Context.WINDOW_SERVICE);
            if (android.os.Build.VERSION.SDK_INT >= 30) {
                android.graphics.Rect b = wm.getMaximumWindowMetrics().getBounds();
                screenW = b.width(); screenH = b.height();
                dpi = ctx.getResources().getConfiguration().densityDpi;
            } else {
                wm.getDefaultDisplay().getRealMetrics(dm);
                screenW = dm.widthPixels; screenH = dm.heightPixels; dpi = dm.densityDpi;
            }

            imageReader = ImageReader.newInstance(screenW, screenH, PixelFormat.RGBA_8888, 3);
            virtualDisplay = projection.createVirtualDisplay("CarromBotCapture",
                screenW, screenH, dpi, DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
                imageReader.getSurface(), null, new Handler(Looper.getMainLooper()));
            Log.i("ScreenCapture: " + screenW + "x" + screenH);
            return true;
        } catch (Throwable t) {
            Log.e("SC init fail", t);
            try {
                ctx.getSharedPreferences(com.carrombot.tool.util.Constants.PREFS, Context.MODE_PRIVATE)
                    .edit().putString("last_crash", "ScreenCapture init failed:\n"
                    + android.util.Log.getStackTraceString(t)).commit();
            } catch (Throwable ignored) {}
            return false;
        }
    }

    private static Bitmap frameBmp;   // reused every frame (no 10 MB allocation per frame)

    /** Latest frame (same Bitmap instance every time - do NOT recycle it). */
    public static Bitmap grab() {
        if (imageReader == null) return null;
        Image img = null;
        try {
            img = imageReader.acquireLatestImage();
            if (img == null) return null;
            Image.Plane p = img.getPlanes()[0];
            ByteBuffer buf = p.getBuffer();
            int pixelStride = p.getPixelStride();
            int rowStride = p.getRowStride();
            int w = rowStride / pixelStride;      // includes row padding; native uses the real width
            if (frameBmp == null || frameBmp.getWidth() != w || frameBmp.getHeight() != screenH) {
                if (frameBmp != null) frameBmp.recycle();
                frameBmp = Bitmap.createBitmap(w, screenH, Bitmap.Config.ARGB_8888);
            }
            frameBmp.copyPixelsFromBuffer(buf);
            return frameBmp;
        } catch (Throwable t) { return null; }
        finally { if (img != null) img.close(); }
    }

    public static int getWidth() { return screenW; }
    public static int getHeight() { return screenH; }
    public static int getDpi() { return dpi; }

    public static boolean isReady() {
        return imageReader != null && projection != null;
    }

    public static void release() {
        try {
            if (virtualDisplay != null) virtualDisplay.release();
            if (imageReader != null) imageReader.close();
            if (projection != null) projection.stop();
        } catch (Throwable ignored) {}
        virtualDisplay = null; imageReader = null; projection = null;
    }
}
