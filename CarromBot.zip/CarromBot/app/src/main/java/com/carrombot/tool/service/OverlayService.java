package com.carrombot.tool.service;

import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.os.IBinder;
import androidx.annotation.Nullable;
import com.carrombot.tool.R;
import com.carrombot.tool.engine.AutoPlayEngine;
import com.carrombot.tool.ui.FloatingLogo;
import com.carrombot.tool.ui.MenuPopup;
import com.carrombot.tool.util.Constants;
import com.carrombot.tool.util.Log;
import com.carrombot.tool.util.NotificationHelper;
import com.carrombot.tool.util.PermissionHelper;
import com.carrombot.tool.util.Prefs;
import com.carrombot.tool.vision.ScreenCapture;

public class OverlayService extends Service
    implements MenuPopup.CB, AutoPlayEngine.Listener {

    private FloatingLogo logo;
    private MenuPopup menu;
    private AutoPlayEngine engine;

    @Override public void onCreate() {
        super.onCreate();
        NotificationHelper.ensureChannel(this);
        try {
            if (Build.VERSION.SDK_INT >= 29) {
                androidx.core.app.ServiceCompat.startForeground(this, Constants.NOTIF_ID,
                    NotificationHelper.build(this),
                    android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION);
            } else {
                startForeground(Constants.NOTIF_ID, NotificationHelper.build(this));
            }
        } catch (Throwable t) {
            Log.e("startForeground fail", t);
            getSharedPreferences(Constants.PREFS, MODE_PRIVATE).edit().putString("last_crash",
                "OverlayService startForeground failed:\n"
                + android.util.Log.getStackTraceString(t)).commit();
            stopSelf();
            return;
        }
        engine = new AutoPlayEngine(this);
        engine.setListener(this);
        logo = new FloatingLogo(this, this::toggleMenu);
        logo.show();
    }

    @Override public int onStartCommand(Intent i, int f, int s) {
        if (engine == null) return START_NOT_STICKY;
        if (i != null && i.hasExtra("data")) {
            int rc = i.getIntExtra("resultCode", 0);
            Intent data = i.getParcelableExtra("data");
            boolean ok = ScreenCapture.init(this, rc, data);
            Log.i("SC init: " + ok);
        }
        return START_STICKY;
    }

    private void toggleMenu() {
        if (menu != null && menu.isShowing()) { menu.hide(); return; }
        menu = new MenuPopup(this, this);
        menu.showAt(logo.getX(), logo.getY());
    }

    // ─── MenuPopup.CB ───
    @Override public void onAutoPlay(boolean on) {
        Prefs.putBool(Constants.PREF_AUTOPLAY, on);
        refreshEngine();
    }
    @Override public void onLines(boolean on) {
        Prefs.putBool(Constants.PREF_LINES, on);
        refreshEngine();
    }

    /** Auto Play ON -> bot plays. Auto Play OFF + Shot Preview ON -> aim assistant (lines only). Both OFF -> stopped. */
    private void refreshEngine() {
        boolean auto = Prefs.getBool(Constants.PREF_AUTOPLAY, false);
        boolean lines = Prefs.getBool(Constants.PREF_LINES, true);
        if (auto || lines) {
            if (!ScreenCapture.isReady()) {
                Log.w("SC not ready");
                if (menu != null) menu.setStatus("Capture not ready");
                return;
            }
            engine.start(auto);
            if (logo != null) logo.setDot(auto ? R.drawable.status_dot_on : R.drawable.status_dot_wait);
        } else {
            engine.stop();
            if (logo != null) logo.setDot(R.drawable.status_dot_off);
        }
    }
    @Override public void onMode(String m) { Prefs.putString(Constants.PREF_MODE, m); }
    @Override public void onClose() { if (menu != null) menu.hide(); }
    @Override public void onLaunchGame() {
        try {
            Intent launch = PermissionHelper.launchGame(this);
            launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(launch);
            if (menu != null) menu.hide();
        } catch (Throwable t) { Log.e("launch fail", t); }
    }

    // ─── Engine Listener ───
    @Override public void onShot(int total, int acc) {
        if (menu != null) menu.updateStats(total, acc);
    }
    @Override public void onState(String s) { Log.i("state: " + s); }
    @Override public void onStatus(String s) {
        if (menu != null) menu.setStatus(s);
        // Status dot: green running, gold waiting, off stopped
        if (logo != null) {
            if (!engine.isRunning()) logo.setDot(R.drawable.status_dot_off);
            else if (s != null && (s.contains("waiting") || s.contains("Game not")))
                logo.setDot(R.drawable.status_dot_wait);
            else logo.setDot(R.drawable.status_dot_on);
        }
    }

    @Override public void onDestroy() {
        if (engine != null) engine.stop();
        if (logo != null) logo.hide();
        if (menu != null) menu.hide();
        ScreenCapture.release();
        super.onDestroy();
    }
    @Nullable @Override public IBinder onBind(Intent i) { return null; }
}
