package com.carrombot.tool.service;

import com.carrombot.tool.auth.LicenseManager;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.os.IBinder;
import androidx.annotation.Nullable;
import com.carrombot.tool.R;
import com.carrombot.tool.engine.AutoPlayEngine;
import com.carrombot.tool.ui.FloatingLogo;
import com.carrombot.tool.ui.MenuPopup;
import com.carrombot.tool.util.Constants;
import com.carrombot.tool.util.Log;
import com.carrombot.tool.util.NotificationHelper;
import com.carrombot.tool.util.PermissionHelper;
import com.carrombot.tool.util.Prefs;
import com.carrombot.tool.vision.ScreenCapture;

public class OverlayService extends Service
    implements MenuPopup.CB, AutoPlayEngine.Listener {

    private FloatingLogo logo;
    private MenuPopup menu;
    private AutoPlayEngine engine;

    @Override public void onCreate() {
        super.onCreate();
        NotificationHelper.ensureChannel(this);
        try {
            if (Build.VERSION.SDK_INT >= 29) {
                androidx.core.app.ServiceCompat.startForeground(this, Constants.NOTIF_ID,
                    NotificationHelper.build(this),
                    android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION);
            } else {
                startForeground(Constants.NOTIF_ID, NotificationHelper.build(this));
            }
        } catch (Throwable t) {
            Log.e("startForeground fail", t);
            getSharedPreferences(Constants.PREFS, MODE_PRIVATE).edit().putString("last_crash",
                "OverlayService startForeground failed:\n"
                + android.util.Log.getStackTraceString(t)).commit();
            stopSelf();
            return;
        }
        // no valid license -> nothing starts (the service can only be started by the app after the key was verified)
        if (!LicenseManager.isUnlocked()) { stopSelf(); return; }
        engine = new AutoPlayEngine(this);
        engine.setListener(this);
        logo = new FloatingLogo(this, this::toggleMenu);
        logo.show();
        scheduleRevalidate();
    }

    // ---- license re-check every 10 minutes (blocked / expired keys are cut off) ----
    private final android.os.Handler recheck = new android.os.Handler(android.os.Looper.getMainLooper());
    private final Runnable recheckTask = new Runnable() {
        @Override public void run() {
            new Thread(() -> {
                int r = LicenseManager.revalidate(OverlayService.this);
                if (r == 1) recheck.post(OverlayService.this::stopSelf);          // server said NO
            }, "license-recheck").start();
            recheck.postDelayed(this, 10 * 60 * 1000L);
        }
    };
    private void scheduleRevalidate() { recheck.postDelayed(recheckTask, 10 * 60 * 1000L); }

    /** The app was swiped away from recents: close the floating menu and everything else. */
    @Override public void onTaskRemoved(Intent rootIntent) {
        stopForeground(true);
        stopSelf();
        super.onTaskRemoved(rootIntent);
    }

    @Override public int onStartCommand(Intent i, int f, int s) {
        if (engine == null) return START_NOT_STICKY;
        if (i != null && i.hasExtra("data")) {
            int rc = i.getIntExtra("resultCode", 0);
            Intent data = i.getParcelableExtra("data");
            boolean ok = ScreenCapture.init(this, rc, data);
            Log.i("SC init: " + ok);
        }
        return START_STICKY;
    }

    private void toggleMenu() {
        if (menu != null && menu.isShowing()) { menu.hide(); return; }
        menu = new MenuPopup(this, this);
        menu.showAt(logo.getX(), logo.getY());
    }

    // ─── MenuPopup.CB ───
    @Override public void onAutoPlay(boolean on) {
        Prefs.putBool(Constants.PREF_AUTOPLAY, on);
        refreshEngine();
    }
    @Override public void onLines(boolean on) {
        Prefs.putBool(Constants.PREF_LINES, on);
        refreshEngine();
    }

    /** Auto Play ON -> bot plays. Auto Play OFF + Shot Preview ON -> aim assistant (lines only). Both OFF -> stopped. */
    private void refreshEngine() {
        boolean auto = Prefs.getBool(Constants.PREF_AUTOPLAY, false);
        boolean lines = Prefs.getBool(Constants.PREF_LINES, true);
        if (auto || lines) {
            if (!ScreenCapture.isReady()) {
                Log.w("SC not ready");
                if (menu != null) menu.setStatus("Capture not ready");
                return;
            }
            engine.start(auto);
            if (logo != null) logo.setDot(auto ? R.drawable.status_dot_on : R.drawable.status_dot_wait);
        } else {
            engine.stop();
            if (logo != null) logo.setDot(R.drawable.status_dot_off);
        }
    }
    @Override public void onMode(String m) { Prefs.putString(Constants.PREF_MODE, m); }
    @Override public void onSpeed(String sp) { Prefs.putString(Constants.PREF_SPEED, sp); }
    @Override public void onLineStyle(String st) { Prefs.putString(Constants.PREF_LINE_STYLE, st); }
    @Override public void onLineLook(String lk) { Prefs.putString(Constants.PREF_LINE_SUB, lk); }
    @Override public void onGameMode(String gm) { Prefs.putString(Constants.PREF_GAME_MODE, gm); }
    @Override public void onQueue(boolean on) { com.carrombot.tool.queue.AutoQueue.get().setEnabled(on); }
    @Override public void onQueueMode(String m) { Prefs.putString(com.carrombot.tool.queue.AutoQueue.K_MODE, m); }

    private com.carrombot.tool.queue.TeachOverlay teach;
    /** "Teach": the menu closes, a transparent layer asks you to tap the buttons once (see queue/AutoQueue). */
    @Override public void onTeach(String kind) {
        if (!com.carrombot.tool.input.InputInjector.isReady()) {
            android.widget.Toast.makeText(this, "Turn ON the VORZEX ENGINE accessibility service first", android.widget.Toast.LENGTH_LONG).show();
            return;
        }
        if (menu != null) menu.hide();
        if (teach != null) teach.abort();
        teach = new com.carrombot.tool.queue.TeachOverlay(this);
        teach.start(kind);
    }
    @Override public void onClose() { if (menu != null) menu.hide(); }
    @Override public void onLaunchGame() {
        try {
            Intent launch = PermissionHelper.launchGame(this);
            launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(launch);
            if (menu != null) menu.hide();
        } catch (Throwable t) { Log.e("launch fail", t); }
    }

    // ─── Engine Listener ───
    @Override public void onShot(final int total, final int acc) {
        recheck.post(() -> { if (menu != null) menu.updateStats(total, acc); });     // views only on the main thread
    }
    @Override public void onState(String s) { Log.i("state: " + s); }
    @Override public void onStatus(final String s) {
        if (s != null && s.startsWith("License")) { recheck.post(this::stopSelf); return; }
        recheck.post(() -> {
            if (menu != null) menu.setStatus(s);
            // status dot: green running, gold waiting, off stopped
            if (logo != null && engine != null) {
                if (!engine.isRunning()) logo.setDot(R.drawable.status_dot_off);
                else if (s != null && (s.contains("waiting") || s.contains("Game not")))
                    logo.setDot(R.drawable.status_dot_wait);
                else logo.setDot(R.drawable.status_dot_on);
            }
        });
    }

    @Override public void onDestroy() {
        recheck.removeCallbacksAndMessages(null);
        if (teach != null) teach.abort();
        if (engine != null) engine.stop();
        if (logo != null) logo.hide();
        if (menu != null) menu.hide();
        ScreenCapture.release();
        super.onDestroy();
    }
    @Nullable @Override public IBinder onBind(Intent i) { return null; }
}
