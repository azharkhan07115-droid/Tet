package com.carrombot.tool.queue;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.TextView;
import android.widget.Toast;
import com.carrombot.tool.input.InputInjector;
import com.carrombot.tool.util.Log;
import com.carrombot.tool.vision.ScreenCapture;

import java.util.ArrayList;
import java.util.List;

/**
 * "Teach" screen: a transparent layer over the game. Tap the buttons you would tap (Play, then the table...).
 * Every tap is remembered AND passed on to the game, so the game moves on and you can teach the next step.
 */
public class TeachOverlay {
    private final Handler ui = new Handler(Looper.getMainLooper());
    private final Context ctx;
    private WindowManager wm;
    private FrameLayout root;
    private WindowManager.LayoutParams lp;
    private TextView count;
    private final List<float[]> taps = new ArrayList<>();
    private long lastTap = 0;
    private byte[] firstSig;
    private String kind;

    public TeachOverlay(Context c) { ctx = c.getApplicationContext(); }

    /** @param kind "queue" (lobby -> table) or "result" (result screen -> lobby) */
    public void start(final String kind) {
        this.kind = kind;
        taps.clear(); lastTap = 0;
        // fingerprint of the screen BEFORE our layer is drawn on top of it
        Bitmap f = ScreenCapture.grab();
        firstSig = f != null ? ScreenSig.of(f, ScreenCapture.getWidth(), ScreenCapture.getHeight()) : null;
        ui.post(this::show);
    }

    private void show() {
        try {
            wm = (WindowManager) ctx.getSystemService(Context.WINDOW_SERVICE);
            root = new FrameLayout(ctx);
            root.setBackgroundColor(0x22000000);
            float d = ctx.getResources().getDisplayMetrics().density;

            TextView banner = new TextView(ctx);
            banner.setText("queue".equals(kind)
                ? "TEACH QUEUE\nTap the buttons in order: Play, then the table you want. Then press DONE."
                : "TEACH AFTER-MATCH\nTap the buttons you press on the result screen. Then press DONE.");
            banner.setTextColor(Color.WHITE); banner.setTextSize(13);
            banner.setBackgroundColor(0xCC0B120F); banner.setPadding((int) (12 * d), (int) (10 * d), (int) (12 * d), (int) (10 * d));
            FrameLayout.LayoutParams bl = new FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.WRAP_CONTENT, Gravity.TOP);
            bl.topMargin = (int) (36 * d);
            root.addView(banner, bl);

            count = new TextView(ctx);
            count.setText("Taps: 0"); count.setTextColor(0xFF2BD67B); count.setTextSize(14);
            FrameLayout.LayoutParams cl = new FrameLayout.LayoutParams(FrameLayout.LayoutParams.WRAP_CONTENT, FrameLayout.LayoutParams.WRAP_CONTENT, Gravity.TOP | Gravity.END);
            cl.topMargin = (int) (130 * d); cl.rightMargin = (int) (16 * d);
            root.addView(count, cl);

            Button done = new Button(ctx); done.setText("DONE"); done.setAllCaps(false);
            done.setTextColor(0xFF06140D); done.setBackgroundColor(0xFF2BD67B);
            FrameLayout.LayoutParams dl = new FrameLayout.LayoutParams((int) (130 * d), (int) (48 * d), Gravity.BOTTOM | Gravity.END);
            dl.bottomMargin = (int) (60 * d); dl.rightMargin = (int) (16 * d);
            root.addView(done, dl);
            done.setOnClickListener(v -> finish(true));

            Button cancel = new Button(ctx); cancel.setText("CANCEL"); cancel.setAllCaps(false);
            cancel.setTextColor(Color.WHITE); cancel.setBackgroundColor(0xFF8C3B3F);
            FrameLayout.LayoutParams cal = new FrameLayout.LayoutParams((int) (130 * d), (int) (48 * d), Gravity.BOTTOM | Gravity.START);
            cal.bottomMargin = (int) (60 * d); cal.leftMargin = (int) (16 * d);
            root.addView(cancel, cal);
            cancel.setOnClickListener(v -> finish(false));

            root.setOnTouchListener((v, e) -> {
                if (e.getAction() == MotionEvent.ACTION_UP) onTap(e.getRawX(), e.getRawY());
                return true;
            });

            int type = Build.VERSION.SDK_INT >= 26 ? WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
                : WindowManager.LayoutParams.TYPE_PHONE;
            lp = new WindowManager.LayoutParams(WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.MATCH_PARENT,
                type, WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN
                | WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS, PixelFormat.TRANSLUCENT);
            wm.addView(root, lp);
            Toast.makeText(ctx, "Teaching started - tap like you normally play", Toast.LENGTH_SHORT).show();
        } catch (Throwable t) { Log.e("teach overlay", t); }
    }

    private void onTap(final float rx, final float ry) {
        long now = System.currentTimeMillis();
        int w = ScreenCapture.getWidth(), h = ScreenCapture.getHeight();
        if (w <= 0 || h <= 0) return;
        if (!taps.isEmpty()) taps.get(taps.size() - 1)[2] = Math.max(600, Math.min(8000, now - lastTap));   // wait after the previous tap
        taps.add(new float[]{rx / w, ry / h, 1500});
        lastTap = now;
        if (count != null) count.setText("Taps: " + taps.size());
        // pass the tap on to the game: let the touch through for a moment and inject it
        try {
            lp.flags |= WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE;
            wm.updateViewLayout(root, lp);
        } catch (Throwable ignored) { }
        new Thread(() -> {
            InputInjector.get().tap(rx, ry);
            ui.postDelayed(() -> {
                try { lp.flags &= ~WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE; wm.updateViewLayout(root, lp); }
                catch (Throwable ignored) { }
            }, 350);
        }, "teach-tap").start();
    }

    private void finish(boolean save) {
        try { if (wm != null && root != null) wm.removeView(root); } catch (Throwable ignored) { }
        root = null;
        if (save && !taps.isEmpty()) {
            AutoQueue.get().saveTeaching(kind, new ArrayList<>(taps), firstSig);
            Toast.makeText(ctx, "Saved " + taps.size() + " taps", Toast.LENGTH_SHORT).show();
        } else if (save) {
            Toast.makeText(ctx, "No taps recorded", Toast.LENGTH_SHORT).show();
        }
    }

    public void abort() { ui.post(() -> finish(false)); }
}
