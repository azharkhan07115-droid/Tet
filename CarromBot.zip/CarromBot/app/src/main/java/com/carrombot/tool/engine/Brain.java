package com.carrombot.tool.engine;

import com.carrombot.tool.data.*;
import com.carrombot.tool.vision.NativeVision;

import java.util.ArrayList;
import java.util.List;

/** Java side of the native planner: GameState -> float[] -> C++ -> Shot / SimResult. */
public class Brain {
    public static class Plan {
        public boolean found;
        public double angle, power, strikerX, score;
        public int predMine, candidates;
        public double prob;     // estimated chance that this shot pots (0..1)
    }

    private final GameConfig cfg;
    private final float[] st = new float[15 + 4 * 48];
    private final float[] prm = new float[8];
    private final float[] planOut = new float[8];
    private final float[] simOut = new float[20000];
    private final List<Piece> order = new ArrayList<>();

    public Brain(GameConfig cfg) { this.cfg = cfg; }

    public static int modeOf(String mode) {
        if (mode == null) return 2;
        if (mode.startsWith("AGGR")) return 1;
        if (mode.startsWith("PRO")) return 2;
        return 0;
    }

    private void encode(GameState s, String mode, boolean slide) {
        order.clear();
        for (Piece p : s.pieces) if (!p.potted && order.size() < 48) order.add(p);
        double L = (s.boardW + s.boardH) / 2.0;
        st[0] = order.size();
        if (s.hasField()) { st[1] = (float) s.fieldL; st[2] = (float) s.fieldT; st[3] = (float) s.fieldR; st[4] = (float) s.fieldB; }
        else { st[1] = (float) s.boardX; st[2] = (float) s.boardY; st[3] = (float) (s.boardX + s.boardW); st[4] = (float) (s.boardY + s.boardH); }
        st[5] = (float) s.pocketRadius;
        for (int i = 0; i < 4; i++) { st[6 + i * 2] = (float) s.pockets[i][0]; st[7 + i * 2] = (float) s.pockets[i][1]; }
        st[14] = (float) L;
        for (int i = 0; i < order.size(); i++) {
            Piece p = order.get(i);
            int t = p.type == PieceType.STRIKER ? 0 : p.type == PieceType.MINE ? 1 : p.type == PieceType.OPP ? 2 : 3;
            st[15 + i * 4] = t; st[16 + i * 4] = (float) p.x; st[17 + i * 4] = (float) p.y; st[18 + i * 4] = (float) p.r;
        }
        prm[0] = (float) cfg.friction; prm[1] = (float) cfg.restitution; prm[2] = (float) cfg.rangeL;
        prm[3] = (float) cfg.dragFull; prm[4] = (float) cfg.shotMargin; prm[5] = modeOf(mode); prm[6] = slide ? 1f : 0f;
        prm[7] = modeOf(mode) == 0 ? 0f : 1f;   // SAFE: just enough power, AGGRO/PRO: full power (checked by physics)
    }

    /** Best shot. allowSlide=true also searches the best striker position on the baseline. */
    public Plan plan(GameState s, String mode, boolean allowSlide) {
        if (!NativeVision.isLoaded() || s.striker() == null) return null;
        encode(s, mode, allowSlide);
        NativeBrain.plan(st, prm, planOut);
        Plan p = new Plan();
        p.found = planOut[0] > 0.5f;
        p.angle = planOut[1]; p.power = planOut[2]; p.strikerX = planOut[3]; p.score = planOut[4];
        p.predMine = (int) planOut[5]; p.candidates = (int) planOut[6]; p.prob = planOut[7];
        return p;
    }

    /** Physics: where do all pieces go for this angle / power? record=true also returns the lines. */
    public SimResult simulate(GameState s, double angle, double power, boolean record, String mode) {
        if (!NativeVision.isLoaded() || s.striker() == null) return null;
        encode(s, mode, false);
        int n = NativeBrain.simulate(st, (float) angle, (float) power, prm, record ? 1 : 0, simOut);
        if (n < 7) return null;
        SimResult r = new SimResult();
        r.score = simOut[4];
        r.strikerPotted = simOut[3] > 0.5f;
        r.queenPotted = simOut[2] > 0.5f;
        int nPot = (int) simOut[5], nTraj = (int) simOut[6];
        int k = 7;
        for (int i = 0; i < nPot; i++) {
            int idx = (int) simOut[k++];
            if (idx >= 0 && idx < order.size()) r.pottedIds.add(order.get(idx).id);
        }
        for (int t = 0; t < nTraj; t++) {
            if (k + 7 > n) break;
            Trajectory tr = new Trajectory();
            int idx = (int) simOut[k], type = (int) simOut[k + 1];
            tr.potted = simOut[k + 2] > 0.5f;
            tr.endX = simOut[k + 3]; tr.endY = simOut[k + 4]; tr.r = simOut[k + 5];
            int np = (int) simOut[k + 6];
            k += 7;
            tr.id = idx >= 0 && idx < order.size() ? order.get(idx).id : "";
            tr.type = type == 0 ? Trajectory.Type.STRIKER : type == 1 ? Trajectory.Type.PUCK
                : type == 2 ? Trajectory.Type.OPP_PUCK : Trajectory.Type.QUEEN;
            for (int i = 0; i < np && k + 1 < n; i++, k += 2) tr.points.add(new double[]{simOut[k], simOut[k + 1]});
            if (tr.potted) { tr.potX = tr.endX; tr.potY = tr.endY; }
            if (tr.type == Trajectory.Type.STRIKER) { r.strikerEndX = tr.endX; r.strikerEndY = tr.endY; }
            r.trajectories.add(tr);
        }
        return r;
    }

    public static List<double[]> potMarkers(List<Trajectory> trajs) {
        List<double[]> out = new ArrayList<>();
        for (Trajectory t : trajs) if (t.potted) out.add(new double[]{t.potX, t.potY});
        return out;
    }
}
