package com.carrombot.tool.queue;

import android.graphics.Bitmap;
import android.util.Base64;

/** Tiny fingerprint of a whole screen (18 x 32 colour samples) used to recognise the lobby / the result screen. */
public final class ScreenSig {
    private static final int GW = 18, GH = 32;
    private ScreenSig() { }

    public static byte[] of(Bitmap f, int w, int h) {
        byte[] out = new byte[GW * GH * 3];
        int k = 0;
        for (int y = 0; y < GH; y++) {
            int py = Math.min(f.getHeight() - 1, (int) ((y + 0.5) * h / GH));
            for (int x = 0; x < GW; x++) {
                int px = Math.min(f.getWidth() - 1, (int) ((x + 0.5) * w / GW));
                int c = f.getPixel(px, py);
                out[k++] = (byte) ((c >> 16) & 0xFF);
                out[k++] = (byte) ((c >> 8) & 0xFF);
                out[k++] = (byte) (c & 0xFF);
            }
        }
        return out;
    }

    /** 0 = identical, 1 = completely different */
    public static double dist(byte[] a, byte[] b) {
        if (a == null || b == null || a.length != b.length) return 1.0;
        long sum = 0;
        for (int i = 0; i < a.length; i++) sum += Math.abs((a[i] & 0xFF) - (b[i] & 0xFF));
        return sum / (255.0 * a.length);
    }

    public static String encode(byte[] s) { return Base64.encodeToString(s, Base64.NO_WRAP); }
    public static byte[] decode(String s) {
        try { return Base64.decode(s, Base64.NO_WRAP); } catch (Throwable t) { return null; }
    }
}
