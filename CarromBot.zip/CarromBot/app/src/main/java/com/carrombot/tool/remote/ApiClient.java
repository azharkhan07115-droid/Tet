package com.carrombot.tool.remote;

import com.carrombot.tool.util.Log;
import java.io.*;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;

public class ApiClient {
    public static String get(String url) {
        if (!com.carrombot.tool.util.Constants.ONLINE) return null;
        try {
            HttpURLConnection c = (HttpURLConnection) new URL(url).openConnection();
            c.setRequestMethod("GET");
            c.setConnectTimeout(8000); c.setReadTimeout(8000);
            c.setRequestProperty("Accept", "application/json");
            if (c.getResponseCode() != 200) return null;
            StringBuilder sb = new StringBuilder();
            try (BufferedReader br = new BufferedReader(
                    new InputStreamReader(c.getInputStream(), StandardCharsets.UTF_8))) {
                String l; while ((l = br.readLine()) != null) sb.append(l);
            }
            return sb.toString();
        } catch (Throwable t) { Log.e("GET err", t); return null; }
    }

    public static String post(String url, String json) {
        if (!com.carrombot.tool.util.Constants.ONLINE) return null;
        try {
            HttpURLConnection c = (HttpURLConnection) new URL(url).openConnection();
            c.setRequestMethod("POST");
            c.setConnectTimeout(8000); c.setReadTimeout(8000);
            c.setDoOutput(true);
            c.setRequestProperty("Content-Type", "application/json");
            try (OutputStream o = c.getOutputStream()) {
                o.write(json.getBytes(StandardCharsets.UTF_8));
            }
            if (c.getResponseCode() != 200) return null;
            return "ok";
        } catch (Throwable t) { Log.e("POST err", t); return null; }
    }
}
