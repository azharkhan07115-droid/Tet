package com.carrombot.tool.remote;

import com.carrombot.tool.util.Constants;
import com.carrombot.tool.util.Log;

import java.io.*;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import javax.crypto.Mac;
import javax.crypto.spec.SecretKeySpec;

/** Tiny HTTP client. Every request carries the API key; POST bodies are HMAC-SHA256 signed. */
public class ApiClient {

    public static String get(String url) {
        if (!Constants.ONLINE) return null;
        try {
            HttpURLConnection c = (HttpURLConnection) new URL(url).openConnection();
            c.setRequestMethod("GET");
            c.setConnectTimeout(6000); c.setReadTimeout(8000);
            c.setRequestProperty("Accept", "application/json");
            c.setRequestProperty("X-Api-Key", Constants.API_KEY);
            if (c.getResponseCode() != 200) return null;
            StringBuilder sb = new StringBuilder();
            try (BufferedReader br = new BufferedReader(
                    new InputStreamReader(c.getInputStream(), StandardCharsets.UTF_8))) {
                String l; while ((l = br.readLine()) != null) sb.append(l);
            }
            return sb.toString();
        } catch (Throwable t) { Log.w("GET failed (offline mode continues): " + t.getMessage()); return null; }
    }

    public static String post(String url, String json) {
        if (!Constants.ONLINE) return null;
        try {
            HttpURLConnection c = (HttpURLConnection) new URL(url).openConnection();
            c.setRequestMethod("POST");
            c.setConnectTimeout(6000); c.setReadTimeout(10000);
            c.setDoOutput(true);
            c.setRequestProperty("Content-Type", "application/json");
            c.setRequestProperty("X-Api-Key", Constants.API_KEY);
            c.setRequestProperty("X-Signature", hmac(json));
            try (OutputStream o = c.getOutputStream()) {
                o.write(json.getBytes(StandardCharsets.UTF_8));
            }
            if (c.getResponseCode() != 200) return null;
            return "ok";
        } catch (Throwable t) { Log.w("POST failed (will retry later): " + t.getMessage()); return null; }
    }

    static String hmac(String body) throws Exception {
        Mac mac = Mac.getInstance("HmacSHA256");
        mac.init(new SecretKeySpec(Constants.API_SECRET.getBytes(StandardCharsets.UTF_8), "HmacSHA256"));
        byte[] h = mac.doFinal(body.getBytes(StandardCharsets.UTF_8));
        StringBuilder sb = new StringBuilder();
        for (byte b : h) sb.append(String.format("%02x", b));
        return sb.toString();
    }
}
