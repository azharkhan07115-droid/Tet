package com.carrombot.tool.ui;

import android.content.Context;
import android.graphics.PixelFormat;
import android.os.Build;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.WindowManager;
import com.carrombot.tool.R;
import com.carrombot.tool.util.Log;

public class FloatingLogo {
    public interface OnClick { void onClick(); }
    private final Context ctx;
    private final WindowManager wm;
    private final OnClick cb;
    private View view;
    private WindowManager.LayoutParams lp;

    public FloatingLogo(Context c, OnClick cb) {
        this.ctx = c;
        this.wm = (WindowManager) c.getSystemService(Context.WINDOW_SERVICE);
        this.cb = cb;
    }

    public void show() {
        if (view != null) return;
        try {
            view = LayoutInflater.from(ctx).inflate(R.layout.floating_logo, null);
            int type = Build.VERSION.SDK_INT >= 26
                ? WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
                : WindowManager.LayoutParams.TYPE_PHONE;
            lp = new WindowManager.LayoutParams(
                WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.WRAP_CONTENT,
                type,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                    | WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                PixelFormat.TRANSLUCENT);
            lp.gravity = Gravity.TOP | Gravity.START;
            lp.x = 60; lp.y = 300;
            view.setOnClickListener(v -> { if (cb != null) cb.onClick(); });
            view.setOnTouchListener(new DragTouchListener(wm, view, lp));
            wm.addView(view, lp);
            Log.i("Logo shown");
        } catch (Throwable t) { Log.e("logo show", t); }
    }

    public void setDot(int resId) {
        if (view == null) return;
        try {
            View dot = view.findViewById(R.id.status_dot);
            if (dot != null) dot.setBackgroundResource(resId);
        } catch (Throwable ignored) {}
    }

    public int getX() { return lp != null ? lp.x : 60; }
    public int getY() { return lp != null ? lp.y : 300; }

    public void hide() {
        if (view == null) return;
        try { wm.removeView(view); } catch (Throwable ignored) {}
        view = null;
    }
}
