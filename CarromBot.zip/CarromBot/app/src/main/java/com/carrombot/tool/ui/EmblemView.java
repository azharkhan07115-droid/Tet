package com.carrombot.tool.ui;

import android.content.Context;
import android.graphics.*;
import android.util.AttributeSet;
import android.view.View;

/** Round emblem: dark disc, green vine ring, glowing red core and a crossed "X". Drawn in code (no image files). */
public class EmblemView extends View {
    private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Path path = new Path();

    public EmblemView(Context c) { super(c); }
    public EmblemView(Context c, AttributeSet a) { super(c, a); }

    @Override protected void onDraw(Canvas c) {
        float w = getWidth(), h = getHeight(), cx = w / 2f, cy = h / 2f, r = Math.min(w, h) / 2f - 2f;
        // dark disc
        p.setStyle(Paint.Style.FILL);
        p.setShader(new RadialGradient(cx, cy, r, 0xFF16241D, 0xFF0A100D, Shader.TileMode.CLAMP));
        c.drawCircle(cx, cy, r, p);
        p.setShader(null);
        // green outer ring + vine arcs
        p.setStyle(Paint.Style.STROKE);
        p.setStrokeCap(Paint.Cap.ROUND);
        p.setStrokeWidth(r * 0.07f);
        p.setColor(0xFF1F6B46);
        c.drawCircle(cx, cy, r * 0.94f, p);
        p.setColor(0xFF2BD67B);
        p.setStrokeWidth(r * 0.05f);
        RectF oval = new RectF(cx - r * 0.86f, cy - r * 0.86f, cx + r * 0.86f, cy + r * 0.86f);
        for (int i = 0; i < 6; i++) c.drawArc(oval, i * 60f + 8f, 34f, false, p);
        // red glowing core
        p.setStyle(Paint.Style.FILL);
        p.setShader(new RadialGradient(cx, cy, r * 0.62f, 0xFFFF5A5F, 0x00E5484D, Shader.TileMode.CLAMP));
        c.drawCircle(cx, cy, r * 0.62f, p);
        p.setShader(null);
        // hexagon
        path.reset();
        for (int i = 0; i < 6; i++) {
            double a = Math.toRadians(60 * i - 90);
            float x = cx + (float) Math.cos(a) * r * 0.5f, y = cy + (float) Math.sin(a) * r * 0.5f;
            if (i == 0) path.moveTo(x, y); else path.lineTo(x, y);
        }
        path.close();
        p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(r * 0.06f); p.setColor(0xFFE5484D);
        c.drawPath(path, p);
        // crossed X
        p.setStrokeWidth(r * 0.2f); p.setColor(0xFF2A3A33);
        c.drawLine(cx - r * 0.34f, cy - r * 0.34f, cx + r * 0.34f, cy + r * 0.34f, p);
        c.drawLine(cx + r * 0.34f, cy - r * 0.34f, cx - r * 0.34f, cy + r * 0.34f, p);
        p.setStrokeWidth(r * 0.07f); p.setColor(0xFF6E8A7C);
        c.drawLine(cx - r * 0.34f, cy - r * 0.34f, cx + r * 0.34f, cy + r * 0.34f, p);
        c.drawLine(cx + r * 0.34f, cy - r * 0.34f, cx - r * 0.34f, cy + r * 0.34f, p);
    }
}
