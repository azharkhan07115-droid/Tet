package com.carrombot.tool.input;

import com.carrombot.tool.data.GameConfig;
import com.carrombot.tool.data.Shot;
import com.carrombot.tool.engine.SpeedProfile;

import java.util.Random;

public class Humanizer {
    private final GameConfig cfg;
    private final Random rnd = new Random();

    public Humanizer(GameConfig c) { this.cfg = c; }

    /** returns {startX, startY, endX, endY, durationMs} for the finger drag at the given speed. */
    public double[] humanize(Shot shot, SpeedProfile sp, double maxDragLen) {
        double aj = sp.angleJitter > 0 ? (rnd.nextDouble() - 0.5) * 2 * sp.angleJitter : 0;
        double pj = sp.powerJitter > 0 ? 1.0 + (rnd.nextDouble() - 0.5) * 2 * sp.powerJitter : 1.0;
        double a = (shot.angleDeg + aj) * Math.PI / 180.0;
        double len = shot.dragLen > 0 ? shot.dragLen : shot.power * maxDragLen;
        len = Math.min(len * pj, maxDragLen);
        double dir = cfg.aimPullBack ? -1.0 : 1.0;
        double endX = shot.startX + dir * Math.cos(a) * len;
        double endY = shot.startY + dir * Math.sin(a) * len;
        long dur = sp.dragMin + rnd.nextInt(Math.max(1, sp.dragMax - sp.dragMin));
        return new double[]{shot.startX, shot.startY, endX, endY, dur};
    }

    public int reactionDelay(SpeedProfile sp) {
        return sp.reactMin + rnd.nextInt(Math.max(1, sp.reactMax - sp.reactMin));
    }
}
