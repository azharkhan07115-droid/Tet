package com.carrombot.tool.input;

import com.carrombot.tool.data.GameConfig;
import com.carrombot.tool.data.Shot;

import java.util.Random;

public class Humanizer {
    private final GameConfig cfg;
    private final Random rnd = new Random();

    public Humanizer(GameConfig c) { this.cfg = c; }

    /** returns {startX, startY, endX, endY, durationMs} for the finger drag. */
    public double[] humanize(Shot shot) {
        double jitter = (rnd.nextDouble() - 0.5) * 2 * cfg.angleJitterDeg;
        double a = (shot.angleDeg + jitter) * Math.PI / 180.0;
        double len = shot.dragLen > 0 ? shot.dragLen : shot.power * 0.222 * cfg.screenW * 0.9;
        double dir = cfg.aimPullBack ? -1.0 : 1.0;
        double endX = shot.startX + dir * Math.cos(a) * len;
        double endY = shot.startY + dir * Math.sin(a) * len;
        long dur = cfg.durationJitterMin + rnd.nextInt(
            Math.max(1, cfg.durationJitterMax - cfg.durationJitterMin));
        int delay = cfg.reactionDelayMin + rnd.nextInt(
            Math.max(1, cfg.reactionDelayMax - cfg.reactionDelayMin));
        try { Thread.sleep(delay); } catch (InterruptedException ignored) {}
        return new double[]{shot.startX, shot.startY, endX, endY, dur};
    }
}
