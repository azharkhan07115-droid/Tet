package com.carrombot.tool.input;

import com.carrombot.tool.data.GameConfig;
import com.carrombot.tool.data.Shot;

import java.util.Random;

public class Humanizer {
    private final GameConfig cfg;
    private final Random rnd = new Random();

    public Humanizer(GameConfig c) { this.cfg = c; }

    public double[] humanize(Shot shot) {
        double jitter = (rnd.nextDouble() - 0.5) * 2 * cfg.angleJitterDeg;
        double angleRad = (shot.angleDeg + jitter) * Math.PI / 180.0;
        double len = shot.power * 400;
        double endX = shot.startX + Math.cos(angleRad) * len;
        double endY = shot.startY + Math.sin(angleRad) * len;
        long dur = cfg.durationJitterMin + rnd.nextInt(
            Math.max(1, cfg.durationJitterMax - cfg.durationJitterMin));
        int delay = cfg.reactionDelayMin + rnd.nextInt(
            Math.max(1, cfg.reactionDelayMax - cfg.reactionDelayMin));
        try { Thread.sleep(delay); } catch (InterruptedException ignored) {}
        return new double[]{shot.startX, shot.startY, endX, endY, dur};
    }
}
