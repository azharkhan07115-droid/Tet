package com.carrombot.tool.remote;

import android.content.Context;
import com.carrombot.tool.data.GameConfig;
import com.carrombot.tool.util.Constants;
import com.carrombot.tool.util.Log;
import com.carrombot.tool.util.Prefs;
import com.carrombot.tool.vision.ScreenCapture;

import org.json.JSONObject;

/**
 * Loads tuning values + shot database from your site (cached, refreshed every 6 h in the background).
 * If the site is unreachable the built-in defaults are used - the bot never depends on the server.
 */
public class RemoteConfig {
    private static final long TTL_MS = 6L * 3600 * 1000;
    private final Context ctx;
    public RemoteConfig(Context c) { this.ctx = c; }

    private boolean stale() {
        long last = 0;
        try { last = Long.parseLong(Prefs.getString(Constants.PREF_LAST_FETCH, "0")); } catch (Throwable ignored) {}
        return System.currentTimeMillis() - last > TTL_MS;
    }

    private void refreshAsync() {
        if (!Constants.ONLINE || !stale()) return;
        new Thread(() -> {
            try {
                String cfg = ApiClient.get(Constants.API_CONFIG);
                if (cfg != null) Prefs.putString(Constants.PREF_CONFIG, cfg);
                String db = ApiClient.get(Constants.API_DATABASE);
                if (db != null) Prefs.putString(Constants.PREF_SHOT_DB, db);
                if (cfg != null || db != null)
                    Prefs.putString(Constants.PREF_LAST_FETCH, String.valueOf(System.currentTimeMillis()));
            } catch (Throwable ignored) {}
        }, "remote-refresh").start();
    }

    public GameConfig fetchLatest() {
        refreshAsync();
        GameConfig c = new GameConfig();
        c.screenW = ScreenCapture.getWidth() > 0 ? ScreenCapture.getWidth() : 1080;
        c.screenH = ScreenCapture.getHeight() > 0 ? ScreenCapture.getHeight() : 2340;
        c.dpi = ScreenCapture.getDpi() > 0 ? ScreenCapture.getDpi() : 420;
        String cached = Prefs.getString(Constants.PREF_CONFIG, null);
        if (cached != null) apply(cached, c);
        return c;
    }

    public ShotDatabase fetchShotDatabase() {
        refreshAsync();
        String cached = Prefs.getString(Constants.PREF_SHOT_DB, null);
        if (cached != null) {
            ShotDatabase db = ShotDatabase.parse(cached);
            if (db != null) return db;
        }
        return new ShotDatabase();
    }

    private void apply(String json, GameConfig c) {
        try {
            JSONObject o = new JSONObject(json);
            c.configVersion = o.optInt("config_version", c.configVersion);
            c.gameVersion = o.optString("game_version", c.gameVersion);
            JSONObject ph = o.optJSONObject("physics");
            if (ph != null) {
                c.friction = ph.optDouble("friction", c.friction);
                c.restitution = ph.optDouble("collision_elasticity", c.restitution);
                c.rangeL = ph.optDouble("range_l", c.rangeL);
                c.dragFull = ph.optDouble("drag_full", c.dragFull);
                c.shotMargin = ph.optDouble("shot_margin", c.shotMargin);
                c.aimPullBack = ph.optBoolean("aim_pull_back", c.aimPullBack);
            }
            JSONObject hu = o.optJSONObject("humanize");
            if (hu != null) {
                int dj = hu.optInt("duration_jitter_ms", 0);
                if (dj > 0) { c.durationJitterMin = Math.max(60, dj - 30); c.durationJitterMax = dj + 30; }
                c.angleJitterDeg = hu.optDouble("angle_jitter_deg", c.angleJitterDeg);
                int rd = hu.optInt("reaction_delay_ms", -1);
                if (rd >= 0) { c.reactionDelayMin = rd; c.reactionDelayMax = rd + 30; }
            }
            JSONObject lp = o.optJSONObject("line_prediction");
            if (lp != null) {
                c.linesEnabled = lp.optBoolean("enabled", c.linesEnabled);
                c.maxBounces = lp.optInt("max_bounces", c.maxBounces);
            }
            JSONObject td = o.optJSONObject("turn_detection");
            if (td != null) c.votesRequired = td.optInt("votes_required", c.votesRequired);
        } catch (Throwable t) { Log.e("config parse", t); }
    }
}
