package com.carrombot.tool.remote;

import android.content.Context;
import com.carrombot.tool.data.GameConfig;
import com.carrombot.tool.util.Constants;
import com.carrombot.tool.util.Log;
import com.carrombot.tool.util.Prefs;
import com.carrombot.tool.vision.ScreenCapture;

public class RemoteConfig {
    private final Context ctx;
    public RemoteConfig(Context c) { this.ctx = c; }

    public GameConfig fetchLatest() {
        String cached = Prefs.getString(Constants.PREF_CONFIG, null);
        if (cached != null) {
            GameConfig c = parse(cached);
            if (c != null) return c;
        }
        new Thread(() -> {
            try {
                String json = ApiClient.get(Constants.API_CONFIG);
                if (json != null) Prefs.putString(Constants.PREF_CONFIG, json);
            } catch (Throwable ignored) {}
        }).start();
        GameConfig c = new GameConfig();
        c.screenW = ScreenCapture.getWidth() > 0 ? ScreenCapture.getWidth() : 1080;
        c.screenH = ScreenCapture.getHeight() > 0 ? ScreenCapture.getHeight() : 2340;
        c.dpi = ScreenCapture.getDpi() > 0 ? ScreenCapture.getDpi() : 420;
        return c;
    }

    public ShotDatabase fetchShotDatabase() {
        String cached = Prefs.getString(Constants.PREF_SHOT_DB, null);
        if (cached != null) {
            ShotDatabase db = ShotDatabase.parse(cached);
            if (db != null) return db;
        }
        new Thread(() -> {
            try {
                String json = ApiClient.get(Constants.API_DATABASE);
                if (json != null) Prefs.putString(Constants.PREF_SHOT_DB, json);
            } catch (Throwable ignored) {}
        }).start();
        return new ShotDatabase();
    }

    private GameConfig parse(String json) {
        try {
            org.json.JSONObject o = new org.json.JSONObject(json);
            GameConfig c = new GameConfig();
            c.screenW = ScreenCapture.getWidth() > 0 ? ScreenCapture.getWidth() : 1080;
            c.screenH = ScreenCapture.getHeight() > 0 ? ScreenCapture.getHeight() : 2340;
            c.dpi = ScreenCapture.getDpi() > 0 ? ScreenCapture.getDpi() : 420;
            c.gameVersion = o.optString("game_version", "1.4.2");
            org.json.JSONObject ph = o.optJSONObject("physics");
            if (ph != null) {
                c.friction = ph.optDouble("friction", c.friction);
                c.maxSpeed = ph.optDouble("max_speed", c.maxSpeed);
            }
            return c;
        } catch (Throwable t) { return null; }
    }
}
