package com.carrombot.tool.vision;

import android.graphics.Bitmap;
import com.carrombot.tool.util.Log;

/** C++ board vision (libcarromvision.so). No OpenCV - tiny and fast. */
public class NativeVision {
    private static boolean loaded = false;
    static {
        try { System.loadLibrary("carromvision"); loaded = true; }
        catch (Throwable t) { Log.e("native vision load failed", t); }
    }
    public static boolean isLoaded() { return loaded; }

    /** @return 1 ok, 0 board not found, <0 error. out layout: see jni_bridge.cpp */
    public static native int detect(Bitmap bmp, float[] out, int width, int height);
    public static native void reset();

    /**
     * Reads the game's own aim arrow while the player drags. out = {present, angleDeg, power, tipX, tipY, lengthPx}.
     * @param field {fieldL, fieldT, fieldR, fieldB}
     */
    public static native int detectAim(Bitmap bmp, int width, int height, float sx, float sy, float sr,
                                       float L, float R, float[] field, float[] out);
}
