package com.carrombot.tool.input;

import android.accessibilityservice.AccessibilityService;
import android.accessibilityservice.GestureDescription;
import android.graphics.Path;
import android.os.Build;
import com.carrombot.tool.util.Log;

import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;

/**
 * Finger gestures through the accessibility service.
 * drag() = press, pull slowly, (optional correction), HOLD, release - like a real finger (the game reads the
 * final power after the hold; a quick flick often gave a weak shot).
 */
public class InputInjector {
    private static InputInjector instance;
    private static volatile AccessibilityService service;

    // The finger must NEVER stay down (a stuck touch freezes the game screen). Every chain below ends in lift().
    private static volatile boolean fingerDown = false;
    private static volatile float downX, downY;
    private static volatile GestureDescription.StrokeDescription downStroke;

    /** Called after the pull and before the release. Return a corrected finger position {x, y} or null (= fine). */
    public interface Adjuster { float[] adjust(); }

    public static synchronized InputInjector get() {
        if (instance == null) instance = new InputInjector();
        return instance;
    }
    public static void setService(AccessibilityService s) {
        service = s;
        Log.i("InputInjector " + (s != null ? "ready" : "cleared"));
    }
    public static boolean isReady() { return service != null; }

    /** Lifts a finger that was left down (a continued stroke that never got its last part). */
    public static synchronized void panicLift() {
        final AccessibilityService svc = service;
        if (!fingerDown || svc == null || Build.VERSION.SDK_INT < 26 || downStroke == null) { fingerDown = false; return; }
        try {
            Path p = new Path(); p.moveTo(downX, downY);
            GestureDescription.StrokeDescription end = downStroke.continueStroke(p, 0, 1, false);
            run(svc, one(end), 700);
        } catch (Throwable t) { Log.e("panicLift", t); }
        fingerDown = false; downStroke = null;
    }

    /** A plain tap. */
    public boolean tap(float x, float y) {
        final AccessibilityService svc = service;
        if (svc == null || Build.VERSION.SDK_INT < 24) return false;
        try {
            Path p = new Path(); p.moveTo(x, y);
            return run(svc, new GestureDescription.Builder().addStroke(
                new GestureDescription.StrokeDescription(p, 0, 60)).build(), 900);
        } catch (Throwable t) { Log.e("tap", t); return false; }
    }

    /** Simple one-stroke swipe (kept for compatibility). */
    public void swipe(float x1, float y1, float x2, float y2, long dur) {
        drag(x1, y1, x2, y2, 1, Math.max(60, dur), 1, null);
    }

    /**
     * @return true when the whole gesture was executed (not cancelled by the system)
     */
    public boolean drag(float x1, float y1, float x2, float y2, long preMs, long pullMs, long holdMs, Adjuster adj) {
        final AccessibilityService svc = service;
        if (svc == null) { Log.w("No A11y"); return false; }
        if (Build.VERSION.SDK_INT < 24) { Log.w("dispatchGesture needs Android 7+"); return false; }
        panicLift();                                                                  // never start with a finger still down
        boolean finished = false;
        try {
            if (Build.VERSION.SDK_INT < 26) {
                // no continued strokes on Android 7: one stroke (pull + hold time)
                Path p = new Path(); p.moveTo(x1, y1); p.lineTo(x2, y2);
                return run(svc, new GestureDescription.Builder().addStroke(
                    new GestureDescription.StrokeDescription(p, 0, Math.max(60, pullMs + holdMs))).build(), pullMs + holdMs + 800);
            }
            Path p0 = new Path(); p0.moveTo(x1, y1);
            GestureDescription.StrokeDescription s0 = new GestureDescription.StrokeDescription(p0, 0, Math.max(1, preMs), true);
            mark(s0, x1, y1);
            if (!run(svc, one(s0), preMs + 800)) return false;                       // 1) finger down
            Path p1 = new Path(); p1.moveTo(x1, y1); p1.lineTo(x2, y2);
            GestureDescription.StrokeDescription s1 = s0.continueStroke(p1, 0, Math.max(30, pullMs), true);
            mark(s1, x2, y2);
            if (!run(svc, one(s1), pullMs + 800)) return false;                      // 2) pull
            float cx = x2, cy = y2;
            GestureDescription.StrokeDescription last = s1;
            for (int i = 0; i < 2 && adj != null; i++) {                             // 3) closed-loop correction
                float[] t = null;
                try { t = adj.adjust(); } catch (Throwable e) { Log.e("adjust", e); }
                if (t == null) break;
                Path pc = new Path(); pc.moveTo(cx, cy); pc.lineTo(t[0], t[1]);
                GestureDescription.StrokeDescription sc = last.continueStroke(pc, 0, 120, true);
                mark(sc, t[0], t[1]);
                if (!run(svc, one(sc), 900)) return false;
                cx = t[0]; cy = t[1]; last = sc;
            }
            Path p2 = new Path(); p2.moveTo(cx, cy);
            GestureDescription.StrokeDescription s2 = last.continueStroke(p2, 0, Math.max(1, holdMs), false);
            boolean ok = run(svc, one(s2), holdMs + 800);                           // 4) hold, then release
            if (ok) { fingerDown = false; downStroke = null; finished = true; }
            return ok;
        } catch (Throwable t) { Log.e("drag err", t); return false; }
        finally {
            if (!finished && fingerDown) panicLift();                               // any failure: lift the finger
        }
    }

    private static void mark(GestureDescription.StrokeDescription s, float x, float y) {
        downStroke = s; downX = x; downY = y; fingerDown = true;
    }

    private static GestureDescription one(GestureDescription.StrokeDescription s) {
        return new GestureDescription.Builder().addStroke(s).build();
    }

    private static boolean run(AccessibilityService svc, GestureDescription gd, long timeoutMs) {
        final CountDownLatch latch = new CountDownLatch(1);
        final boolean[] ok = {false};
        AccessibilityService.GestureResultCallback cb = new AccessibilityService.GestureResultCallback() {
            @Override public void onCompleted(GestureDescription g) { ok[0] = true; latch.countDown(); }
            @Override public void onCancelled(GestureDescription g) { latch.countDown(); }
        };
        if (!svc.dispatchGesture(gd, cb, null)) return false;
        try { latch.await(timeoutMs, TimeUnit.MILLISECONDS); }
        catch (InterruptedException e) { Thread.currentThread().interrupt(); return false; }
        return ok[0];
    }
}
