package com.carrombot.tool.input;

import android.accessibilityservice.AccessibilityService;
import android.accessibilityservice.GestureDescription;
import android.graphics.Path;
import com.carrombot.tool.util.Log;

public class InputInjector {
    private static InputInjector instance;
    private static volatile AccessibilityService service;

    public static synchronized InputInjector get() {
        if (instance == null) instance = new InputInjector();
        return instance;
    }
    public static void setService(AccessibilityService s) {
        service = s;
        Log.i("InputInjector " + (s != null ? "ready" : "cleared"));
    }
    public static boolean isReady() { return service != null; }

    public void swipe(float x1, float y1, float x2, float y2, long dur) {
        if (service == null) { Log.w("No A11y"); return; }
        try {
            Path path = new Path();
            path.moveTo(x1, y1);
            path.lineTo(x2, y2);
            GestureDescription.StrokeDescription stroke =
                new GestureDescription.StrokeDescription(path, 0, Math.max(60, dur));
            GestureDescription gd = new GestureDescription.Builder().addStroke(stroke).build();
            service.dispatchGesture(gd, null, null);
        } catch (Throwable t) { Log.e("swipe err", t); }
    }
}
