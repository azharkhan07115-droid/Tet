package com.carrombot.tool.ui;

import android.content.Context;
import android.content.Intent;
import android.graphics.PixelFormat;
import android.os.Build;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.WindowManager;
import android.util.DisplayMetrics;
import android.widget.Button;
import android.widget.RadioGroup;
import android.widget.Switch;
import android.widget.TextView;
import com.carrombot.tool.R;
import com.carrombot.tool.util.Constants;
import com.carrombot.tool.util.Log;
import com.carrombot.tool.util.PermissionHelper;
import com.carrombot.tool.util.Prefs;

public class MenuPopup {
    public interface CB {
        void onAutoPlay(boolean on);
        void onLines(boolean on);
        void onHighlightPockets(boolean on);
        void onPreviewMode(String mode);
        void onIconMenu(boolean on);
        void onThreeFingerMenu(boolean on);
        void onMode(String mode);
        void onSpeed(String speed);
        void onLineStyle(String style);
        void onLineLook(String look);
        void onGameMode(String mode);
        void onClose();
        void onLaunchGame();
    }
    private final Context ctx;
    private final WindowManager wm;
    private final CB cb;
    private View view;
    private WindowManager.LayoutParams lp;
    private Switch swAuto, swLines, swHighlight, swIconMenu, swThreeFinger;
    private TextView tvStatusHeader, tvAutoStatus, tvShots, tvAccuracy, tvWins;
    private RadioGroup rgMode, rgSpeed, rgGame, rgPreview;
    private TextView tvLicense;

    public MenuPopup(Context c, CB cb) {
        this.ctx = c;
        this.wm = (WindowManager) c.getSystemService(Context.WINDOW_SERVICE);
        this.cb = cb;
    }

    public boolean isShowing() { return view != null; }

    public void showAt(int x, int y) {
        if (view != null) return;
        try {
            view = LayoutInflater.from(ctx).inflate(R.layout.menu_layout, null);
            int type = Build.VERSION.SDK_INT >= 26
                ? WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
                : WindowManager.LayoutParams.TYPE_PHONE;
            DisplayMetrics dm = new DisplayMetrics();
            wm.getDefaultDisplay().getMetrics(dm);
            int panelWidth = Math.min(dp(336), dm.widthPixels - dp(24));
            lp = new WindowManager.LayoutParams(
                panelWidth,
                WindowManager.LayoutParams.WRAP_CONTENT,
                type, WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
                PixelFormat.TRANSLUCENT);
            lp.gravity = Gravity.TOP | Gravity.START;
            lp.x = Math.max(dp(12), Math.min(x - panelWidth / 3,
                dm.widthPixels - panelWidth - dp(12)));
            lp.y = Math.max(dp(12), Math.min(y + dp(64), dm.heightPixels - dp(260)));
            lp.height = Math.max(dp(240), dm.heightPixels - lp.y - dp(18));
            if (Build.VERSION.SDK_INT >= 31) {
                lp.flags |= WindowManager.LayoutParams.FLAG_BLUR_BEHIND;
                lp.setBlurBehindRadius(dp(28));
            }
            bind();
            wire();
            view.setElevation(dp(18));
            wm.addView(view, lp);
            refresh();
        } catch (Throwable t) { Log.e("menu show", t); }
    }

    private int dp(int value) {
        return Math.round(value * ctx.getResources().getDisplayMetrics().density);
    }

    private void bind() {
        swAuto = view.findViewById(R.id.sw_autoplay);
        swLines = view.findViewById(R.id.sw_lines);
        swHighlight = view.findViewById(R.id.sw_highlight_pockets);
        swIconMenu = view.findViewById(R.id.sw_icon_menu);
        swThreeFinger = view.findViewById(R.id.sw_three_finger);
        tvStatusHeader = view.findViewById(R.id.tv_status_header);
        tvAutoStatus = view.findViewById(R.id.tv_autoplay_status);
        tvShots = view.findViewById(R.id.tv_shots);
        tvAccuracy = view.findViewById(R.id.tv_accuracy);
        tvWins = view.findViewById(R.id.tv_wins);
        rgMode = view.findViewById(R.id.rg_mode);
        rgSpeed = view.findViewById(R.id.rg_speed);
        rgGame = view.findViewById(R.id.rg_game);
        rgPreview = view.findViewById(R.id.rg_preview_mode);
        tvLicense = view.findViewById(R.id.tv_license_menu);
        View close = view.findViewById(R.id.btn_close);
        if (close != null) close.setOnClickListener(v -> {
            if (cb != null) cb.onClose();
            hide();
        });
        Button launch = view.findViewById(R.id.btn_launch_game);
        if (launch != null) launch.setOnClickListener(v -> {
            if (cb != null) cb.onLaunchGame();
        });
    }

    private void wire() {
        if (swAuto != null) swAuto.setOnCheckedChangeListener((b, c) -> {
            if (cb != null) cb.onAutoPlay(c);
        });
        if (swLines != null) swLines.setOnCheckedChangeListener((b, c) -> {
            if (cb != null) cb.onLines(c);
        });
        if (swHighlight != null) swHighlight.setOnCheckedChangeListener((b, c) -> {
            if (cb != null) cb.onHighlightPockets(c);
        });
        if (swIconMenu != null) swIconMenu.setOnCheckedChangeListener((b, c) -> {
            if (cb != null) cb.onIconMenu(c);
        });
        if (swThreeFinger != null) swThreeFinger.setOnCheckedChangeListener((b, c) -> {
            if (cb != null) cb.onThreeFingerMenu(c);
        });
        if (rgPreview != null) rgPreview.setOnCheckedChangeListener((g, id) -> {
            String value = "FOLLOW";
            if (id == R.id.rb_preview_off) value = "OFF";
            else if (id == R.id.rb_preview_freeze) value = "FREEZE";
            if (cb != null) cb.onPreviewMode(value);
        });
        if (rgMode != null) rgMode.setOnCheckedChangeListener((g, id) -> {
            String m = "SAFE";
            if (id == R.id.rb_aggro) m = "AGGRESSIVE";
            else if (id == R.id.rb_pro) m = "PRO";
            if (cb != null) cb.onMode(m);
        });
        if (rgGame != null) rgGame.setOnCheckedChangeListener((g, id) -> {
            String gm = "DISC";
            if (id == R.id.rb_gm_carrom) gm = "CARROM";
            else if (id == R.id.rb_gm_free) gm = "FREESTYLE";
            if (cb != null) cb.onGameMode(gm);
        });
        if (rgSpeed != null) rgSpeed.setOnCheckedChangeListener((g, id) -> {
            String sp = "FULL";
            if (id == R.id.rb_speed_low) sp = "LOW";
            else if (id == R.id.rb_speed_med) sp = "MEDIUM";
            if (cb != null) cb.onSpeed(sp);
        });
    }

    public void refresh() {
        if (view == null) return;
        try {
            if (swAuto != null) swAuto.setChecked(Prefs.getBool(Constants.PREF_AUTOPLAY, false));
            if (swLines != null) swLines.setChecked(Prefs.getBool(Constants.PREF_SHOW_PREDICTION,
                Prefs.getBool(Constants.PREF_LINES, true)));
            if (swHighlight != null) swHighlight.setChecked(Prefs.getBool(Constants.PREF_HIGHLIGHT_POCKETS, true));
            if (swIconMenu != null) swIconMenu.setChecked(Prefs.getBool(Constants.PREF_ICON_MENU, true));
            if (swThreeFinger != null) swThreeFinger.setChecked(Prefs.getBool(Constants.PREF_THREE_FINGER_MENU, false));
            String preview = Prefs.getString(Constants.PREF_PREVIEW_MODE, "FOLLOW");
            if (rgPreview != null) {
                if ("OFF".equals(preview)) rgPreview.check(R.id.rb_preview_off);
                else if ("FREEZE".equals(preview)) rgPreview.check(R.id.rb_preview_freeze);
                else rgPreview.check(R.id.rb_preview_follow);
            }
            String mode = Prefs.getString(Constants.PREF_MODE, "PRO");
            if (rgMode != null) {
                if ("AGGRESSIVE".equals(mode)) rgMode.check(R.id.rb_aggro);
                else if ("PRO".equals(mode)) rgMode.check(R.id.rb_pro);
                else rgMode.check(R.id.rb_safe);
            }
            String speed = Prefs.getString(Constants.PREF_SPEED, "FULL");
            if (rgSpeed != null) {
                if ("LOW".equals(speed)) rgSpeed.check(R.id.rb_speed_low);
                else if ("MEDIUM".equals(speed)) rgSpeed.check(R.id.rb_speed_med);
                else rgSpeed.check(R.id.rb_speed_full);
            }
            String gmode = Prefs.getString(Constants.PREF_GAME_MODE, "DISC");
            if (rgGame != null) {
                if ("CARROM".equals(gmode)) rgGame.check(R.id.rb_gm_carrom);
                else if ("FREESTYLE".equals(gmode)) rgGame.check(R.id.rb_gm_free);
                else rgGame.check(R.id.rb_gm_disc);
            }
            if (tvLicense != null) {
                int d = com.carrombot.tool.auth.LicenseManager.daysLeft();
                tvLicense.setText(com.carrombot.tool.auth.LicenseManager.isUnlocked()
                    ? (d > 0 ? "License active - " + d + " days left" : "License active") : "License needed");
            }
            if (tvShots != null) tvShots.setText("" + Prefs.getInt(Constants.PREF_SHOTS_PLAYED, 0));
            if (tvAccuracy != null) tvAccuracy.setText(Prefs.getInt(Constants.PREF_ACCURACY, 0) + "%");
            if (tvWins != null) tvWins.setText("" + Prefs.getInt(Constants.PREF_WINS, 0));
        } catch (Throwable ignored) {}
    }

    public void setStatus(String s) {
        if (view == null) return;
        try {
            if (tvStatusHeader != null) tvStatusHeader.setText(s);
            if (tvAutoStatus != null) tvAutoStatus.setText(s);
        } catch (Throwable ignored) {}
    }

    public void updateStats(int shots, int acc) {
        if (view == null) return;
        try {
            if (tvShots != null) tvShots.setText("" + shots);
            if (tvAccuracy != null) tvAccuracy.setText(acc + "%");
        } catch (Throwable ignored) {}
    }

    public void hide() {
        if (view == null) return;
        try { wm.removeView(view); } catch (Throwable ignored) {}
        view = null;
    }
}
