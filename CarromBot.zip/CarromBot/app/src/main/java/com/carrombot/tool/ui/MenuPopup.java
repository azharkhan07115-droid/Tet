package com.carrombot.tool.ui;

import android.content.Context;
import android.content.Intent;
import android.graphics.PixelFormat;
import android.os.Build;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.RadioGroup;
import android.widget.Switch;
import android.widget.TextView;
import com.carrombot.tool.R;
import com.carrombot.tool.util.Constants;
import com.carrombot.tool.util.Log;
import com.carrombot.tool.util.PermissionHelper;
import com.carrombot.tool.util.Prefs;

public class MenuPopup {
    public interface CB {
        void onAutoPlay(boolean on);
        void onLines(boolean on);
        void onMode(String mode);
        void onClose();
        void onLaunchGame();
    }
    private final Context ctx;
    private final WindowManager wm;
    private final CB cb;
    private View view;
    private WindowManager.LayoutParams lp;
    private Switch swAuto, swLines;
    private TextView tvStatusHeader, tvAutoStatus, tvShots, tvAccuracy, tvWins;
    private RadioGroup rgMode;

    public MenuPopup(Context c, CB cb) {
        this.ctx = c;
        this.wm = (WindowManager) c.getSystemService(Context.WINDOW_SERVICE);
        this.cb = cb;
    }

    public boolean isShowing() { return view != null; }

    public void showAt(int x, int y) {
        if (view != null) return;
        try {
            view = LayoutInflater.from(ctx).inflate(R.layout.menu_layout, null);
            int type = Build.VERSION.SDK_INT >= 26
                ? WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
                : WindowManager.LayoutParams.TYPE_PHONE;
            lp = new WindowManager.LayoutParams(
                WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.WRAP_CONTENT,
                type, WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
                PixelFormat.TRANSLUCENT);
            lp.gravity = Gravity.TOP | Gravity.START;
            lp.x = Math.max(20, x - 110);
            lp.y = y + 70;
            bind();
            wire();
            wm.addView(view, lp);
            refresh();
        } catch (Throwable t) { Log.e("menu show", t); }
    }

    private void bind() {
        swAuto = view.findViewById(R.id.sw_autoplay);
        swLines = view.findViewById(R.id.sw_lines);
        tvStatusHeader = view.findViewById(R.id.tv_status_header);
        tvAutoStatus = view.findViewById(R.id.tv_autoplay_status);
        tvShots = view.findViewById(R.id.tv_shots);
        tvAccuracy = view.findViewById(R.id.tv_accuracy);
        tvWins = view.findViewById(R.id.tv_wins);
        rgMode = view.findViewById(R.id.rg_mode);
        View close = view.findViewById(R.id.btn_close);
        if (close != null) close.setOnClickListener(v -> {
            if (cb != null) cb.onClose();
            hide();
        });
        Button launch = view.findViewById(R.id.btn_launch_game);
        if (launch != null) launch.setOnClickListener(v -> {
            if (cb != null) cb.onLaunchGame();
        });
    }

    private void wire() {
        if (swAuto != null) swAuto.setOnCheckedChangeListener((b, c) -> {
            if (cb != null) cb.onAutoPlay(c);
        });
        if (swLines != null) swLines.setOnCheckedChangeListener((b, c) -> {
            if (cb != null) cb.onLines(c);
        });
        if (rgMode != null) rgMode.setOnCheckedChangeListener((g, id) -> {
            String m = "SAFE";
            if (id == R.id.rb_aggro) m = "AGGRESSIVE";
            else if (id == R.id.rb_pro) m = "PRO";
            if (cb != null) cb.onMode(m);
        });
    }

    public void refresh() {
        if (view == null) return;
        try {
            if (swAuto != null) swAuto.setChecked(Prefs.getBool(Constants.PREF_AUTOPLAY, false));
            if (swLines != null) swLines.setChecked(Prefs.getBool(Constants.PREF_LINES, true));
            String mode = Prefs.getString(Constants.PREF_MODE, "PRO");
            if (rgMode != null) {
                if ("AGGRESSIVE".equals(mode)) rgMode.check(R.id.rb_aggro);
                else if ("PRO".equals(mode)) rgMode.check(R.id.rb_pro);
                else rgMode.check(R.id.rb_safe);
            }
            if (tvShots != null) tvShots.setText("" + Prefs.getInt(Constants.PREF_SHOTS_PLAYED, 0));
            if (tvAccuracy != null) tvAccuracy.setText(Prefs.getInt(Constants.PREF_ACCURACY, 0) + "%");
            if (tvWins != null) tvWins.setText("" + Prefs.getInt(Constants.PREF_WINS, 0));
        } catch (Throwable ignored) {}
    }

    public void setStatus(String s) {
        if (view == null) return;
        try {
            if (tvStatusHeader != null) tvStatusHeader.setText(s);
            if (tvAutoStatus != null) tvAutoStatus.setText(s);
        } catch (Throwable ignored) {}
    }

    public void updateStats(int shots, int acc) {
        if (view == null) return;
        try {
            if (tvShots != null) tvShots.setText("" + shots);
            if (tvAccuracy != null) tvAccuracy.setText(acc + "%");
        } catch (Throwable ignored) {}
    }

    public void hide() {
        if (view == null) return;
        try { wm.removeView(view); } catch (Throwable ignored) {}
        view = null;
    }
}
