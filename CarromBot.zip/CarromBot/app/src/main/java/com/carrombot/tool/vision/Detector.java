package com.carrombot.tool.vision;

import android.content.Context;
import android.graphics.Bitmap;
import com.carrombot.tool.data.GameConfig;
import com.carrombot.tool.data.GameState;
import com.carrombot.tool.data.Piece;
import com.carrombot.tool.data.PieceType;
import com.carrombot.tool.util.Log;

import java.util.ArrayList;
import java.util.List;

/** Reads the board through the C++ vision (NativeVision) and adds per-piece motion tracking. */
public class Detector {
    private final float[] buf = new float[20 + 4 * 48];
    private List<Piece> prev = null;
    private long prevTime = 0;
    private int lastCode = 0;

    public Detector(Context ctx, GameConfig c) { }
    public void updateConfig(GameConfig c) { }
    public int lastCode() { return lastCode; }

    public GameState detect(Bitmap frame) {
        if (frame == null) return null;
        if (!NativeVision.isLoaded()) { lastCode = -9; return null; }
        try {
            lastCode = NativeVision.detect(frame, buf, ScreenCapture.getWidth(), ScreenCapture.getHeight());
            if (lastCode != 1) return null;

            GameState s = new GameState();
            s.timestamp = System.currentTimeMillis();
            s.boardX = buf[0]; s.boardY = buf[1]; s.boardW = buf[2]; s.boardH = buf[3];
            s.fieldL = buf[4]; s.fieldT = buf[5]; s.fieldR = buf[6]; s.fieldB = buf[7];
            s.pockets = new double[4][2];
            for (int i = 0; i < 4; i++) { s.pockets[i][0] = buf[8 + i * 2]; s.pockets[i][1] = buf[9 + i * 2]; }
            s.thumbX = buf[16]; s.thumbY = buf[17];
            boolean mineBlack = buf[18] > 0.5f;
            double L = (s.boardW + s.boardH) / 2.0;
            s.pocketRadius = 0.05 * L;

            PieceType whiteType = mineBlack ? PieceType.OPP : PieceType.MINE;
            PieceType blackType = mineBlack ? PieceType.MINE : PieceType.OPP;
            int n = (int) buf[19];
            int is = 0, iw = 0, ib = 0, iq = 0;
            for (int i = 0; i < n; i++) {
                int t = (int) buf[20 + i * 4];
                double x = buf[21 + i * 4], y = buf[22 + i * 4], r = buf[23 + i * 4];
                Piece p;
                if (t == 0) p = new Piece("striker_" + (is++), PieceType.STRIKER, x, y, r);
                else if (t == 1) p = new Piece(whiteType.name().toLowerCase() + "_w" + (iw++), whiteType, x, y, r);
                else if (t == 2) p = new Piece(blackType.name().toLowerCase() + "_b" + (ib++), blackType, x, y, r);
                else p = new Piece("queen_" + (iq++), PieceType.QUEEN, x, y, r);
                p.confidence = 0.9f;
                s.pieces.add(p);
            }
            computeMotion(s.pieces, L, s.timestamp);
            float sum = 0;
            for (Piece p : s.pieces) sum += p.confidence;
            s.detectionConfidence = s.pieces.isEmpty() ? 0 : sum / s.pieces.size();
            if (s.striker() == null) s.detectionConfidence *= 0.5f;
            return s;
        } catch (Throwable t) {
            Log.e("Detect err", t);
            return null;
        }
    }

    /** Per-piece movement since the previous frame (99 = unknown / moving fast). */
    private void computeMotion(List<Piece> cur, double L, long now) {
        boolean fresh = prev != null && (now - prevTime) < 700;
        double maxD = 0.3 * L;
        for (Piece p : cur) {
            if (!fresh) { p.motion = 99; continue; }
            double best = Double.MAX_VALUE;
            for (Piece q : prev) {
                if (q.type != p.type) continue;
                double d = Math.hypot(p.x - q.x, p.y - q.y);
                if (d < best) best = d;
            }
            p.motion = best > maxD ? 99 : best;
        }
        List<Piece> snap = new ArrayList<>();
        for (Piece p : cur) snap.add(p.copy());
        prev = snap;
        prevTime = now;
    }
}
