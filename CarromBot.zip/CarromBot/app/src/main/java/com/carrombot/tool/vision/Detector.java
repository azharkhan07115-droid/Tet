package com.carrombot.tool.vision;

import android.content.Context;
import android.graphics.Bitmap;
import com.carrombot.tool.data.GameConfig;
import com.carrombot.tool.data.GameState;
import com.carrombot.tool.data.Piece;
import com.carrombot.tool.data.PieceType;
import com.carrombot.tool.util.Log;
import org.opencv.android.Utils;
import org.opencv.core.Core;
import org.opencv.core.CvType;
import org.opencv.core.Mat;
import org.opencv.core.MatOfPoint;
import org.opencv.core.Point;
import org.opencv.core.Rect;
import org.opencv.core.Scalar;
import org.opencv.core.Size;
import org.opencv.imgproc.Imgproc;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * OpenCV based board reader.
 * 1) finds the wooden board (HSV wood colour) -> board rect
 * 2) pockets / piece sizes are derived from board size (works on any screen)
 * 3) white / black / red discs are found with a distance-transform so touching
 *    discs (opening formation) are separated correctly
 * 4) bigger white disc = striker
 */
public class Detector {
    private GameConfig config;
    private List<Piece> prev = null;
    private long prevTime = 0;
    private Rect boardCache = null;   // board rect is re-checked only every 20 frames (speed)
    private int frameNo = 0;
    private boolean mineBlack = true;

    public Detector(Context ctx, GameConfig c) { this.config = c; }
    public void updateConfig(GameConfig c) { this.config = c; }

    public GameState detect(Bitmap frame) {
        if (frame == null) return null;
        Mat rgba = new Mat();
        Mat rgb = new Mat();
        Mat hsv = new Mat();
        try {
            Utils.bitmapToMat(frame, rgba);
            Imgproc.cvtColor(rgba, rgb, Imgproc.COLOR_RGBA2RGB);

            if (boardCache == null || (frameNo++ % 20) == 0) {
                Imgproc.cvtColor(rgb, hsv, Imgproc.COLOR_RGB2HSV);
                Rect b = findBoard(hsv);
                if (b == null) { boardCache = null; return null; }
                boardCache = b;
                mineBlack = isMineBlack(hsv);
            }
            Rect board = boardCache;

            double bx = board.x, by = board.y, bw = board.width, bh = board.height;
            double L = (bw + bh) / 2.0;
            double inset = 0.068 * L;
            double puckR = 0.025 * L;

            GameState s = new GameState();
            s.timestamp = System.currentTimeMillis();
            s.boardX = bx; s.boardY = by; s.boardW = bw; s.boardH = bh;
            s.pockets = new double[][]{
                {bx + inset, by + inset}, {bx + bw - inset, by + inset},
                {bx + inset, by + bh - inset}, {bx + bw - inset, by + bh - inset}};
            s.pocketRadius = 0.05 * L;

            Point[] pk = new Point[4];
            for (int i = 0; i < 4; i++)
                pk[i] = new Point(s.pockets[i][0] - bx, s.pockets[i][1] - by);
            double paintR = 0.055 * L;
            double suppress = 1.2 * puckR;

            Mat roiRgb = rgb.submat(board);
            Mat roi = new Mat();
            Imgproc.cvtColor(roiRgb, roi, Imgproc.COLOR_RGB2HSV);
            roiRgb.release();

            Mat whiteMask = new Mat();
            Core.inRange(roi, new Scalar(0, 0, 151), new Scalar(179, 69, 255), whiteMask);
            Mat blackMask = new Mat();
            Core.inRange(roi, new Scalar(0, 0, 0), new Scalar(179, 59, 89), blackMask);
            Mat redA = new Mat();
            Mat redB = new Mat();
            Mat redMask = new Mat();
            Core.inRange(roi, new Scalar(0, 131, 121), new Scalar(5, 255, 255), redA);
            Core.inRange(roi, new Scalar(171, 131, 121), new Scalar(179, 255, 255), redB);
            Core.bitwise_or(redA, redB, redMask);

            List<double[]> whites = findDiscs(whiteMask, pk, paintR, L, 0.011 * L, suppress);
            List<double[]> blacks = findDiscs(blackMask, pk, paintR, L, 0.011 * L, suppress);
            List<double[]> reds = findDiscs(redMask, pk, paintR, L, 0.011 * L, suppress);

            boolean mineIsBlack = mineBlack;
            PieceType whiteType = mineIsBlack ? PieceType.OPP : PieceType.MINE;
            PieceType blackType = mineIsBlack ? PieceType.MINE : PieceType.OPP;

            int iw = 0, ib = 0, ir = 0, is = 0;
            for (double[] w : whites) {
                if (w[2] > 0.0285 * L) {
                    Piece p = new Piece("striker_" + (is++), PieceType.STRIKER,
                        bx + w[0], by + w[1], Math.min(w[2], 0.04 * L));
                    p.confidence = 0.9f;
                    s.pieces.add(p);
                } else {
                    Piece p = new Piece(whiteType.name().toLowerCase() + "_w" + (iw++), whiteType,
                        bx + w[0], by + w[1], puckR);
                    p.confidence = 0.9f;
                    s.pieces.add(p);
                }
            }
            for (double[] b : blacks) {
                Piece p = new Piece(blackType.name().toLowerCase() + "_b" + (ib++), blackType,
                    bx + b[0], by + b[1], puckR);
                p.confidence = 0.9f;
                s.pieces.add(p);
            }
            for (double[] r : reds) {
                Piece p = new Piece("queen_" + (ir++), PieceType.QUEEN,
                    bx + r[0], by + r[1], puckR);
                p.confidence = 0.9f;
                s.pieces.add(p);
            }

            computeMotion(s.pieces, L, s.timestamp);

            float sum = 0; int n = 0;
            for (Piece p : s.pieces) { sum += p.confidence; n++; }
            s.detectionConfidence = n > 0 ? sum / n : 0;
            if (s.striker() == null) s.detectionConfidence *= 0.5f;

            whiteMask.release(); blackMask.release();
            redA.release(); redB.release(); redMask.release();
            roi.release();
            return s;
        } catch (Throwable t) {
            Log.e("Detect err", t);
            boardCache = null;
            return null;
        } finally {
            rgba.release(); rgb.release(); hsv.release();
        }
    }

    /** Wooden board = biggest wood coloured, roughly square region. */
    private Rect findBoard(Mat hsv) {
        Mat m = new Mat();
        try {
            Core.inRange(hsv, new Scalar(6, 70, 100), new Scalar(22, 160, 255), m);
            Mat k = Imgproc.getStructuringElement(Imgproc.MORPH_ELLIPSE, new Size(15, 15));
            Imgproc.morphologyEx(m, m, Imgproc.MORPH_CLOSE, k);
            List<MatOfPoint> cs = new ArrayList<>();
            Imgproc.findContours(m, cs, new Mat(),
                Imgproc.RETR_EXTERNAL, Imgproc.CHAIN_APPROX_SIMPLE);
            MatOfPoint best = null;
            double bestArea = 0;
            for (MatOfPoint c : cs) {
                double a = Imgproc.contourArea(c);
                if (a > bestArea) { bestArea = a; best = c; }
            }
            if (best == null) return null;
            Rect r = Imgproc.boundingRect(best);
            double ratio = r.width / (double) r.height;
            if (r.width < hsv.cols() * 0.5) return null;
            if (ratio < 0.85 || ratio > 1.15) return null;
            return r;
        } finally {
            m.release();
        }
    }

    /**
     * Distance-transform peaks of a binary mask. Returns {x, y, radius} in mask coords.
     * Pocket areas are blanked first so the black pockets are not seen as pucks.
     */
    private List<double[]> findDiscs(Mat mask, Point[] pockets, double paintR, double L,
                                     double minDt, double suppress) {
        List<double[]> keep = new ArrayList<>();
        for (Point p : pockets)
            Imgproc.circle(mask, p, (int) paintR, new Scalar(0), -1);
        Mat k3 = Imgproc.getStructuringElement(Imgproc.MORPH_ELLIPSE, new Size(3, 3));
        Imgproc.morphologyEx(mask, mask, Imgproc.MORPH_OPEN, k3);

        List<MatOfPoint> cs = new ArrayList<>();
        Mat hier = new Mat();
        Imgproc.findContours(mask, cs, hier, Imgproc.RETR_EXTERNAL, Imgproc.CHAIN_APPROX_SIMPLE);
        hier.release();
        if (cs.isEmpty()) return keep;

        Mat filled = Mat.zeros(mask.size(), CvType.CV_8UC1);
        Imgproc.drawContours(filled, cs, -1, new Scalar(255), -1);

        Mat dt = new Mat();
        Imgproc.distanceTransform(filled, dt, Imgproc.DIST_L2, 5);
        int ks = Math.max(3, ((int) (0.03 * L)) | 1);
        Mat mx = new Mat();
        Imgproc.dilate(dt, mx, Imgproc.getStructuringElement(Imgproc.MORPH_ELLIPSE, new Size(ks, ks)));
        Mat isMax = new Mat();
        Core.compare(dt, mx, isMax, Core.CMP_GE);
        Mat big = new Mat();
        Core.compare(dt, new Scalar(minDt), big, Core.CMP_GT);
        Core.bitwise_and(isMax, big, isMax);

        MatOfPoint nz = new MatOfPoint();
        Core.findNonZero(isMax, nz);
        Point[] pts = nz.toArray();
        List<double[]> all = new ArrayList<>();
        float[] buf = new float[1];
        for (Point p : pts) {
            dt.get((int) p.y, (int) p.x, buf);
            all.add(new double[]{p.x, p.y, buf[0]});
        }
        Collections.sort(all, (a, b) -> Double.compare(b[2], a[2]));
        for (double[] o : all) {
            boolean ok = true;
            for (double[] kk : keep) {
                if (Math.hypot(o[0] - kk[0], o[1] - kk[1]) < suppress) { ok = false; break; }
            }
            if (ok) keep.add(o);
        }

        filled.release(); dt.release(); mx.release();
        isMax.release(); big.release(); nz.release(); k3.release();
        return keep;
    }

    /** Which colour am I? Read the small puck icon next to my score (top-left). */
    private boolean isMineBlack(Mat hsv) {
        int w = hsv.cols(), h = hsv.rows();
        int cx = (int) (0.111 * w), cy = (int) (0.146 * h);
        int r = Math.max(4, (int) (0.012 * w));
        int x0 = Math.max(0, cx - r), y0 = Math.max(0, cy - r);
        int x1 = Math.min(w, cx + r + 1), y1 = Math.min(h, cy + r + 1);
        if (x1 <= x0 || y1 <= y0) return true;
        Mat sub = hsv.submat(new Rect(x0, y0, x1 - x0, y1 - y0));
        double v = Core.mean(sub).val[2];
        sub.release();
        return v < 130;
    }

    /** Per-piece movement since the previous frame (99 = unknown / moving fast). */
    private void computeMotion(List<Piece> cur, double L, long now) {
        boolean fresh = prev != null && (now - prevTime) < 700;
        double maxD = 0.3 * L;
        for (Piece p : cur) {
            if (!fresh) { p.motion = 99; continue; }
            double best = Double.MAX_VALUE;
            for (Piece q : prev) {
                if (q.type != p.type) continue;
                double d = Math.hypot(p.x - q.x, p.y - q.y);
                if (d < best) best = d;
            }
            p.motion = best > maxD ? 99 : best;
        }
        List<Piece> snap = new ArrayList<>();
        for (Piece p : cur) snap.add(p.copy());
        prev = snap;
        prevTime = now;
    }
}
