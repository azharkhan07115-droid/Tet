package com.carrombot.tool.vision;

import android.content.Context;
import android.graphics.Bitmap;
import com.carrombot.tool.data.GameConfig;
import com.carrombot.tool.data.GameState;
import com.carrombot.tool.data.Piece;
import com.carrombot.tool.data.PieceType;
import com.carrombot.tool.util.Log;
import org.opencv.android.Utils;
import org.opencv.core.Core;
import org.opencv.core.Mat;
import org.opencv.core.MatOfPoint;
import org.opencv.core.MatOfPoint2f;
import org.opencv.core.Point;
import org.opencv.core.Scalar;
import org.opencv.core.Size;
import org.opencv.imgproc.Imgproc;
import org.opencv.imgproc.Moments;

import java.util.ArrayList;
import java.util.List;

public class Detector {
    private GameConfig config;
    public Detector(Context ctx, GameConfig c) { this.config = c; }
    public void updateConfig(GameConfig c) { this.config = c; }

    public GameState detect(Bitmap frame) {
        if (frame == null) return null;
        try {
            Mat rgba = new Mat();
            Utils.bitmapToMat(frame, rgba);
            Mat rgb = new Mat();
            Imgproc.cvtColor(rgba, rgb, Imgproc.COLOR_RGBA2RGB);

            GameState s = new GameState();
            s.timestamp = System.currentTimeMillis();
            double w = rgb.cols(), h = rgb.rows();
            double pm = Math.min(w, h) * 0.06;
            s.pockets = new double[][]{{pm,pm},{w-pm,pm},{pm,h-pm},{w-pm,h-pm}};
            s.pocketRadius = pm * 1.1;

            s.pieces.addAll(detect(rgb, config.strikerLow, config.strikerHigh, PieceType.STRIKER));
            s.pieces.addAll(detect(rgb, config.whiteLow, config.whiteHigh, PieceType.MINE));
            s.pieces.addAll(detect(rgb, config.blackLow, config.blackHigh, PieceType.OPP));
            s.pieces.addAll(detect(rgb, config.queenLow, config.queenHigh, PieceType.QUEEN));

            float sum = 0; int n = 0;
            for (Piece p : s.pieces) { sum += p.confidence; n++; }
            s.detectionConfidence = n > 0 ? sum / n : 0;
            if (s.striker() == null) s.detectionConfidence *= 0.5f;

            rgb.release(); rgba.release();
            return s;
        } catch (Throwable t) { Log.e("Detect err", t); return null; }
    }

    private List<Piece> detect(Mat rgb, double[] lo, double[] hi, PieceType type) {
        List<Piece> out = new ArrayList<>();
        try {
            Mat mask = new Mat();
            Core.inRange(rgb, new Scalar(lo[0],lo[1],lo[2]),
                             new Scalar(hi[0],hi[1],hi[2]), mask);
            Mat k = Imgproc.getStructuringElement(Imgproc.MORPH_ELLIPSE, new Size(5,5));
            Imgproc.morphologyEx(mask, mask, Imgproc.MORPH_OPEN, k);
            Imgproc.morphologyEx(mask, mask, Imgproc.MORPH_CLOSE, k);

            List<MatOfPoint> contours = new ArrayList<>();
            Imgproc.findContours(mask, contours, new Mat(),
                Imgproc.RETR_EXTERNAL, Imgproc.CHAIN_APPROX_SIMPLE);

            double minR = Math.min(rgb.cols(), rgb.rows()) * 0.015;
            double maxR = Math.min(rgb.cols(), rgb.rows()) * 0.08;
            int i = 0;
            for (MatOfPoint c : contours) {
                double area = Imgproc.contourArea(c);
                if (area < 50) continue;
                Point center = new Point();
                float[] radius = new float[1];
                Imgproc.minEnclosingCircle(new MatOfPoint2f(c.toArray()), center, radius);
                double r = radius[0];
                if (r < minR || r > maxR) continue;
                double peri = Imgproc.arcLength(new MatOfPoint2f(c.toArray()), true);
                if (peri < 1) continue;
                double circ = 4 * Math.PI * area / (peri * peri);
                if (circ < 0.6) continue;
                Moments m = Imgproc.moments(c);
                double cx = center.x, cy = center.y;
                if (m.m00 > 0) { cx = m.m10 / m.m00; cy = m.m01 / m.m00; }
                Piece p = new Piece(type.name().toLowerCase()+"_"+(i++), type, cx, cy, r);
                p.confidence = (float) Math.min(1.0, 0.5 + 0.5 * circ);
                out.add(p);
            }
            mask.release();
        } catch (Throwable t) { Log.e("detect cir err", t); }
        return out;
    }
}
