package com.carrombot.tool.engine;

import com.carrombot.tool.data.GameConfig;
import com.carrombot.tool.data.GameState;
import com.carrombot.tool.data.Piece;
import com.carrombot.tool.data.Shot;

/** Shot geometry helper (the planner itself is in C++: cpp/brain.cpp). */
public class ShotPlanner {
    /** Builds a shot incl. the finger drag: pull-back length = power * dragFull * board width. */
    public static Shot makeShot(GameConfig cfg, GameState s, Piece st, double angle, double power) {
        double W = s.fieldW() > 0 ? s.fieldW() : cfg.screenW * 0.9;
        double len = power * cfg.dragFull * W;
        double ar = Math.toRadians(angle);
        double dir = cfg.aimPullBack ? -1.0 : 1.0;
        Shot shot = new Shot(st, angle, power,
            st.x + dir * Math.cos(ar) * len, st.y + dir * Math.sin(ar) * len);
        shot.dragLen = len;
        return shot;
    }
}
