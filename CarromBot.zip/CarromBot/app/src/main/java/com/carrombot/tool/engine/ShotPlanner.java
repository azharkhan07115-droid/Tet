package com.carrombot.tool.engine;

import com.carrombot.tool.data.GameConfig;
import com.carrombot.tool.data.GameState;
import com.carrombot.tool.data.Piece;
import com.carrombot.tool.data.Shot;

/** Shot geometry helper (the planner itself is in C++: cpp/brain.cpp). */
public class ShotPlanner {
    /** The game's power gauge is NOT linear: speed fraction q = 1 - sqrt(1 - g) (g = pull / max pull).
     *  So to get the speed fraction q the finger must pull g = 1 - (1 - q)^2 of the full distance. */
    public static double gaugeForSpeed(double q) {
        q = Math.max(0.0, Math.min(1.0, q));
        return 1.0 - (1.0 - q) * (1.0 - q);
    }
    public static double speedForGauge(double g) {
        g = Math.max(0.0, Math.min(1.0, g));
        return 1.0 - Math.sqrt(1.0 - g);
    }

    /** Builds a shot incl. the finger drag: pull-back length = gauge(q) * dragFull * board width. */
    public static Shot makeShot(GameConfig cfg, GameState s, Piece st, double angle, double power) {
        double W = s.fieldW() > 0 ? s.fieldW() : cfg.screenW * 0.9;
        double len = gaugeForSpeed(power) * cfg.dragFull * W;
        double ar = Math.toRadians(angle);
        double dir = cfg.aimPullBack ? -1.0 : 1.0;
        Shot shot = new Shot(st, angle, power,
            st.x + dir * Math.cos(ar) * len, st.y + dir * Math.sin(ar) * len);
        shot.dragLen = len;
        return shot;
    }
}
