package com.carrombot.tool.engine;

import com.carrombot.tool.data.GameConfig;
import com.carrombot.tool.data.GameState;
import com.carrombot.tool.data.Piece;
import com.carrombot.tool.data.PieceType;
import com.carrombot.tool.data.Shot;

import java.util.ArrayList;
import java.util.List;

/**
 * Fast geometric shot calculator (takes ~1 ms instead of 36,000 simulations).
 * For every own piece and every pocket it computes the "ghost" striker position
 * that sends the piece into the pocket, then checks both paths are free.
 */
public class ShotPlanner {
    private final GameConfig cfg;

    public ShotPlanner(GameConfig cfg) { this.cfg = cfg; }

    public Shot plan(GameState s, String mode) {
        Piece st = s.striker();
        if (st == null) return null;

        double L = s.boardW > 0 ? (s.boardW + s.boardH) / 2.0 : 1000.0;
        boolean aggro = mode != null && mode.startsWith("AGGR");
        boolean safe = mode != null && mode.startsWith("SAFE");
        double minCos = safe ? 0.55 : (aggro ? 0.15 : 0.35);

        List<Piece> targets = new ArrayList<>();
        for (Piece p : s.pieces)
            if (!p.potted && p.type == PieceType.MINE) targets.add(p);
        boolean haveMine = !targets.isEmpty();
        for (Piece p : s.pieces)
            if (!p.potted && p.type == PieceType.QUEEN && (aggro || !haveMine)) targets.add(p);

        double bestScore = -1e9;
        double bestAngle = 0, bestDist = 0;
        boolean found = false;

        for (Piece t : targets) {
            for (double[] pk : s.pockets) {
                double tx = pk[0] - t.x, ty = pk[1] - t.y;
                double dTP = Math.hypot(tx, ty);
                if (dTP < 1) continue;
                double dx = tx / dTP, dy = ty / dTP;

                double gx = t.x - dx * (st.r + t.r);
                double gy = t.y - dy * (st.r + t.r);
                if (!onBoard(s, gx, gy, st.r)) continue;

                double sx = gx - st.x, sy = gy - st.y;
                double dSG = Math.hypot(sx, sy);
                if (dSG < 1) continue;
                double cos = (sx / dSG) * dx + (sy / dSG) * dy;
                if (cos < minCos) continue;

                if (blocked(s, st, t, st.x, st.y, gx, gy, st.r)) continue;
                if (blocked(s, st, t, t.x, t.y, pk[0], pk[1], t.r)) continue;

                double score = 10.0 * cos - 4.0 * (dSG + dTP) / L;
                if (t.type == PieceType.QUEEN && aggro) score += 2.0;
                if (score > bestScore) {
                    bestScore = score;
                    bestAngle = Math.toDegrees(Math.atan2(sy, sx));
                    bestDist = dSG + dTP;
                    found = true;
                }
            }
        }

        double angle, power, expected;
        if (found) {
            angle = bestAngle;
            power = clamp(cfg.powerBase + cfg.powerScale * bestDist / L, 0.40, 1.0);
            expected = 10.0 + bestScore;
        } else {
            // no clean pot: hit the nearest own piece (or any piece) so the turn is not wasted
            Piece near = null;
            double nd = 1e18;
            for (Piece p : s.pieces) {
                if (p == st || p.potted || p.type == PieceType.STRIKER) continue;
                if (haveMine && p.type != PieceType.MINE) continue;
                double d = Math.hypot(p.x - st.x, p.y - st.y);
                if (d < nd) { nd = d; near = p; }
            }
            if (near != null) angle = Math.toDegrees(Math.atan2(near.y - st.y, near.x - st.x));
            else angle = -90;
            power = 0.55;
            expected = 0;
        }

        double ar = Math.toRadians(angle);
        double len = power * 400.0;
        Shot shot = new Shot(st, angle, power,
            st.x + Math.cos(ar) * len, st.y + Math.sin(ar) * len);
        shot.expectedScore = expected;
        return shot;
    }

    private boolean onBoard(GameState s, double x, double y, double r) {
        if (s.boardW <= 0) return true;
        double m = 0.03 * s.boardW + r;
        return x > s.boardX + m && x < s.boardX + s.boardW - m
            && y > s.boardY + m && y < s.boardY + s.boardH - m;
    }

    /** true if any other piece touches the segment a->b travelled by a disc of radius mr. */
    private boolean blocked(GameState s, Piece striker, Piece target,
                            double ax, double ay, double bx, double by, double mr) {
        double vx = bx - ax, vy = by - ay;
        double len2 = vx * vx + vy * vy;
        for (Piece q : s.pieces) {
            if (q == striker || q == target || q.potted) continue;
            double u = len2 < 1e-9 ? 0 : ((q.x - ax) * vx + (q.y - ay) * vy) / len2;
            u = Math.max(0, Math.min(1, u));
            double cx = ax + u * vx, cy = ay + u * vy;
            if (Math.hypot(q.x - cx, q.y - cy) < (mr + q.r) * 0.98) return true;
        }
        return false;
    }

    private static double clamp(double v, double lo, double hi) {
        return Math.max(lo, Math.min(hi, v));
    }
}
