package com.carrombot.tool.engine;

import com.carrombot.tool.data.GameConfig;
import com.carrombot.tool.data.GameState;
import com.carrombot.tool.data.Piece;
import com.carrombot.tool.data.PieceType;
import com.carrombot.tool.data.Shot;

import java.util.ArrayList;
import java.util.List;

/**
 * Offline geometric shot calculator (~1 ms, no server / database needed).
 * For every own piece and every pocket it computes the "ghost" striker position
 * that sends the piece into the pocket and checks both paths are free.
 * It can also pick the best striker spot on the baseline (bestBaselineX).
 */
public class ShotPlanner {
    private final GameConfig cfg;

    public ShotPlanner(GameConfig cfg) { this.cfg = cfg; }

    private static double L(GameState s) {
        return s.boardW > 0 ? (s.boardW + s.boardH) / 2.0 : 1000.0;
    }

    private static double minCos(String mode) {
        if (mode != null && mode.startsWith("SAFE")) return 0.55;
        if (mode != null && mode.startsWith("AGGR")) return 0.15;
        return 0.35;
    }

    private static boolean aggro(String mode) { return mode != null && mode.startsWith("AGGR"); }

    private List<Piece> targets(GameState s, boolean aggro) {
        List<Piece> t = new ArrayList<>();
        for (Piece p : s.pieces)
            if (!p.potted && p.type == PieceType.MINE) t.add(p);
        boolean haveMine = !t.isEmpty();
        for (Piece p : s.pieces)
            if (!p.potted && p.type == PieceType.QUEEN && (aggro || !haveMine)) t.add(p);
        return t;
    }

    /** returns {found(1/0), score, angleDeg, pathLength} for a striker standing at (sx, sy). */
    private double[] evaluate(GameState s, Piece st, double sx0, double sy0,
                              List<Piece> targets, double minCos, boolean aggro) {
        double L = L(s);
        double bestScore = -1e9, bestAngle = 0, bestPower = 0;
        boolean found = false;
        for (Piece t : targets) {
            for (double[] pk : s.pockets) {
                double tx = pk[0] - t.x, ty = pk[1] - t.y;
                double dTP = Math.hypot(tx, ty);
                if (dTP < 1) continue;
                double dx = tx / dTP, dy = ty / dTP;

                double gx = t.x - dx * (st.r + t.r);
                double gy = t.y - dy * (st.r + t.r);
                if (!onBoard(s, gx, gy, st.r)) continue;

                double sx = gx - sx0, sy = gy - sy0;
                double dSG = Math.hypot(sx, sy);
                if (dSG < 1) continue;
                double cos = (sx / dSG) * dx + (sy / dSG) * dy;
                if (cos < minCos) continue;

                if (blocked(s, st, t, sx0, sy0, gx, gy, st.r)) continue;
                if (blocked(s, st, t, t.x, t.y, pk[0], pk[1], t.r)) continue;

                double score = 10.0 * cos - 4.0 * (dSG + dTP) / L;
                if (t.type == PieceType.QUEEN && aggro) score += 2.0;
                if (score > bestScore) {
                    bestScore = score;
                    bestAngle = Math.toDegrees(Math.atan2(sy, sx));
                    // distance the striker must roll: reach the ghost point, then push the piece
                    // (it keeps ~cos of the speed) all the way to the pocket, plus a safety margin
                    double need = dSG + cfg.shotMargin * dTP / Math.max(cos, 0.3) + 0.1 * L;
                    bestPower = clamp(need / (cfg.rangeL * L), 0.25, 1.0);
                    found = true;
                }
            }
        }
        return new double[]{found ? 1 : 0, bestScore, bestAngle, bestPower};
    }

    /** Best x for the striker on its baseline (screen px). Returns current x if moving does not help. */
    public double bestBaselineX(GameState s, String mode) {
        Piece st = s.striker();
        if (st == null) return 0;
        if (s.boardW <= 0) return st.x;
        double L = L(s);
        boolean ag = aggro(mode);
        List<Piece> targets = targets(s, ag);
        if (targets.isEmpty()) return st.x;
        double mc = minCos(mode);

        double bestX = st.x;
        double[] cur = evaluate(s, st, st.x, st.y, targets, mc, ag);
        double bestScore = cur[0] > 0 ? cur[1] : -1e9;

        double fl = s.hasField() ? s.fieldL : s.boardX;
        double fw = s.hasField() ? s.fieldW() : s.boardW;
        double from = fl + 0.23 * fw, to = fl + 0.77 * fw;
        for (double x = from; x <= to; x += 0.03 * L) {
            boolean occupied = false;
            for (Piece q : s.pieces) {
                if (q == st || q.potted) continue;
                if (Math.hypot(q.x - x, q.y - st.y) < st.r + q.r + 2) { occupied = true; break; }
            }
            if (occupied) continue;
            double[] r = evaluate(s, st, x, st.y, targets, mc, ag);
            if (r[0] < 1) continue;
            double sc = r[1] - 0.8 * Math.abs(x - st.x) / L;   // small penalty for moving far
            if (sc > bestScore) { bestScore = sc; bestX = x; }
        }
        return bestX;
    }

    /** Best shot from the striker's CURRENT position. */
    public Shot plan(GameState s, String mode) {
        Piece st = s.striker();
        if (st == null) return null;
        double L = L(s);
        boolean ag = aggro(mode);
        List<Piece> targets = targets(s, ag);
        boolean haveMine = false;
        for (Piece p : s.pieces) if (!p.potted && p.type == PieceType.MINE) { haveMine = true; break; }

        double[] r = evaluate(s, st, st.x, st.y, targets, minCos(mode), ag);

        double angle, power, expected;
        if (r[0] > 0) {
            angle = r[2];
            power = r[3];
            expected = 10.0 + r[1];
        } else {
            // no clean pot: hit the nearest own piece (or any piece) so the turn is not wasted
            Piece near = null;
            double nd = 1e18;
            for (Piece p : s.pieces) {
                if (p == st || p.potted || p.type == PieceType.STRIKER) continue;
                if (haveMine && p.type != PieceType.MINE) continue;
                double d = Math.hypot(p.x - st.x, p.y - st.y);
                if (d < nd) { nd = d; near = p; }
            }
            if (near != null) angle = Math.toDegrees(Math.atan2(near.y - st.y, near.x - st.x));
            else angle = -90;
            power = 0.55;
            expected = 0;
        }

        Shot shot = makeShot(cfg, s, st, angle, power);
        shot.expectedScore = expected;
        return shot;
    }

    /** Builds a shot incl. the finger drag: pull-back length = power * dragFull * board width. */
    public static Shot makeShot(GameConfig cfg, GameState s, Piece st, double angle, double power) {
        double W = s.fieldW() > 0 ? s.fieldW() : cfg.screenW * 0.9;
        double len = power * cfg.dragFull * W;
        double ar = Math.toRadians(angle);
        double dir = cfg.aimPullBack ? -1.0 : 1.0;
        Shot shot = new Shot(st, angle, power,
            st.x + dir * Math.cos(ar) * len, st.y + dir * Math.sin(ar) * len);
        shot.dragLen = len;
        return shot;
    }

    private boolean onBoard(GameState s, double x, double y, double r) {
        if (s.hasField())
            return x > s.fieldL + r && x < s.fieldR - r && y > s.fieldT + r && y < s.fieldB - r;
        if (s.boardW <= 0) return true;
        double m = 0.03 * s.boardW + r;
        return x > s.boardX + m && x < s.boardX + s.boardW - m
            && y > s.boardY + m && y < s.boardY + s.boardH - m;
    }

    /** true if any other piece touches the segment a->b travelled by a disc of radius mr. */
    private boolean blocked(GameState s, Piece striker, Piece target,
                            double ax, double ay, double bx, double by, double mr) {
        double vx = bx - ax, vy = by - ay;
        double len2 = vx * vx + vy * vy;
        for (Piece q : s.pieces) {
            if (q == striker || q == target || q.potted) continue;
            double u = len2 < 1e-9 ? 0 : ((q.x - ax) * vx + (q.y - ay) * vy) / len2;
            u = Math.max(0, Math.min(1, u));
            double cx = ax + u * vx, cy = ay + u * vy;
            if (Math.hypot(q.x - cx, q.y - cy) < (mr + q.r) * 0.98) return true;
        }
        return false;
    }

    private static double clamp(double v, double lo, double hi) {
        return Math.max(lo, Math.min(hi, v));
    }
}
