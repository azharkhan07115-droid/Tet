package com.carrombot.tool.util;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.content.Context;
import android.os.Build;
import androidx.core.app.NotificationCompat;
import com.carrombot.tool.R;

public class NotificationHelper {

    public static void ensureChannel(Context c) {
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationManager nm = (NotificationManager)
                c.getSystemService(Context.NOTIFICATION_SERVICE);
            NotificationChannel ch = new NotificationChannel(
                Constants.CHANNEL_ID, c.getString(R.string.notification_channel),
                NotificationManager.IMPORTANCE_LOW);
            nm.createNotificationChannel(ch);
        }
    }

    public static Notification build(Context c) {
        return new NotificationCompat.Builder(c, Constants.CHANNEL_ID)
            .setContentTitle(c.getString(R.string.notification_title))
            .setContentText(c.getString(R.string.notification_text))
            .setSmallIcon(R.drawable.ic_carrom_logo)
            .setOngoing(true)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .build();
    }
}
