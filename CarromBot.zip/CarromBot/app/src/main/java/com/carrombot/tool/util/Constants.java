package com.carrombot.tool.util;

public class Constants {
    /**
     * true  = bot downloads config + shot database from YOUR site and uploads match data to it.
     * false = fully offline. Either way the bot plays with built-in vision + geometry planner,
     *         so a dead / missing server never stops it.
     */
    public static final boolean ONLINE = false;   // set to true after your site is live

    /** >>> put your hosted web folder here (the "web" folder of this project) <<< */
    public static final String SERVER_BASE = "https://demo-carrom.example.com/carrom-bot";

    /** must match web/config/config.php (API_KEY / API_SECRET). CHANGE BOTH before going live. */
    public static final String API_KEY = "demo_api_key_change_me";
    public static final String API_SECRET = "demo_secret_change_me";
    public static final String API_CONFIG = SERVER_BASE + "/api/config";
    public static final String API_DATABASE = SERVER_BASE + "/api/database";
    public static final String API_UPLOAD = SERVER_BASE + "/api/upload";

    public static final String TARGET_PACKAGE = "com.miniclip.carrom";
    public static final String PLAYSTORE_URL = "market://details?id=" + TARGET_PACKAGE;

    public static final String PREFS = "carrombot_prefs";
    public static final String PREF_CONFIG = "config_json";
    public static final String PREF_SHOT_DB = "shot_db_json";
    public static final String PREF_LAST_FETCH = "last_fetch";
    public static final String PREF_AUTOPLAY = "autoplay";
    public static final String PREF_LINES = "lines";
    public static final String PREF_SHOW_PREDICTION = "show_prediction";
    public static final String PREF_HIGHLIGHT_POCKETS = "highlight_pockets";
    public static final String PREF_PREVIEW_MODE = "preview_mode"; // OFF / FREEZE / FOLLOW
    public static final String PREF_ICON_MENU = "icon_menu";
    public static final String PREF_THREE_FINGER_MENU = "three_finger_menu";
    public static final String PREF_MODE = "mode";
    public static final String PREF_LICENSE_KEY = "license_key";
    public static final String PREF_GAME_MODE = "game_mode";   // DISC / CARROM / FREESTYLE
    public static final String PREF_SPEED = "speed";   // LOW / MEDIUM / FULL
    public static final String PREF_LINE_STYLE = "line_style";   // DEFAULT / CUSTOM
    public static final String PREF_LINE_SUB = "line_sub";       // GLOW / SIMPLE / DARK (custom look)
    public static final String PREF_SHOTS_PLAYED = "shots_played";
    public static final String PREF_WINS = "wins";
    public static final String PREF_ACCURACY = "accuracy";

    public static final int NOTIF_ID = 1001;
    public static final String CHANNEL_ID = "carrombot_channel";

    // ---- license login (Sarkar API, see CLIENT_INTEGRATION.md) ----
    public static final String LICENSE_URL = "https://etzchciutckbwreroahg.supabase.co/functions/v1/sarkar-api/connect";
    public static final String LICENSE_GAME = "Software";
    /** Public-key pinning of the license server. Leave false unless you verified the pin below matches the live
     *  certificate chain (a wrong pin = nobody can log in). Standard TLS validation is always on. */
    public static final boolean PIN_ENFORCE = false;
    public static final String PIN_SHA256_B64 = "C/yvYpMUatsDUe02rfnVxIoe/hVtVpRAd9mB0Lm9hPU=";
}
