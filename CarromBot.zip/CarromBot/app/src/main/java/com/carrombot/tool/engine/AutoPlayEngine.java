package com.carrombot.tool.engine;

import android.content.Context;
import android.graphics.Bitmap;
import android.os.Build;
import com.carrombot.tool.data.*;
import com.carrombot.tool.input.Humanizer;
import com.carrombot.tool.input.InputInjector;
import com.carrombot.tool.remote.DataUploader;
import com.carrombot.tool.remote.RemoteConfig;
import com.carrombot.tool.remote.ShotDataCollector;
import com.carrombot.tool.remote.ShotDatabase;
import com.carrombot.tool.service.AutoAccessibilityService;
import com.carrombot.tool.ui.LineOverlayManager;
import com.carrombot.tool.util.Constants;
import com.carrombot.tool.util.Log;
import com.carrombot.tool.util.Prefs;
import com.carrombot.tool.vision.Detector;
import com.carrombot.tool.vision.NativeVision;
import com.carrombot.tool.vision.ScreenCapture;

/**
 * Two modes on one thread:
 *  - autoFire = true : the bot plays. Turn = the game's own orange glow ring around my striker.
 *                      It picks the piece with the best chance to drop (C++ physics), moves the striker
 *                      with the slider, aims, pulls to the right power and shoots.
 *  - autoFire = false: aim assistant. While YOU drag, the game's aim arrow is read every frame and the
 *                      lines show where every piece goes for that angle + power. Idle: best shot shown.
 * Vision, physics and planner run in C++ (libcarromvision.so). No server needed.
 */
public class AutoPlayEngine {

    public interface Listener {
        void onShot(int total, int acc);
        void onState(String state);
        void onStatus(String status);
    }

    private volatile boolean running = false;
    private volatile boolean autoFire = true;
    private volatile String currentStatus = "Idle";
    private Thread worker;
    private final Context ctx;
    private GameConfig config;
    private Listener listener;

    private Brain brain;
    private Detector detector;
    private ShotDatabase shotDb;
    private DataUploader uploader;
    private ShotDataCollector collector;
    private Pending pending;
    private LineOverlayManager lineMgr;
    private Humanizer humanizer;
    private boolean linesShown = false;

    private int totalShots = 0, successShots = 0;

    // ---- board geometry (measured by the full detector, used by the 1 ms tracker) ----
    private boolean geoOk = false;
    private final float[] geoField = new float[4];
    private float geoL = 700, geoR = 150, baselineY = 0;
    private final float[] trk = new float[11];
    private int missCount = 0;

    public AutoPlayEngine(Context ctx) { this.ctx = ctx.getApplicationContext(); }
    public void setListener(Listener l) { this.listener = l; }
    public boolean isRunning() { return running; }
    public String getStatus() { return currentStatus; }

    /** autoFire=true: play by itself. autoFire=false: aim assistant only. */
    public synchronized void start(boolean fire) {
        boolean modeChanged = fire != autoFire;
        autoFire = fire;
        if (running) { if (modeChanged) resetTurnState(); return; }
        running = true;
        worker = new Thread(this::loop, "bot-engine");
        worker.setPriority(Thread.NORM_PRIORITY + 1);
        worker.start();
        status("Starting...");
    }

    public synchronized void stop() {
        running = false;
        if (worker != null) { worker.interrupt(); worker = null; }
        if (lineMgr != null) lineMgr.hide();
        if (collector != null) collector.flush();
        status("Stopped");
    }

    private void resetTurnState() {
        baseState = null; aimingNow = false; suggestionShown = false;
        firedAt = 0; glowDropped = true; glowStable = 0;
        hideLines();
    }

    private void loop() {
        Log.i("Engine started");
        try {
            if (!NativeVision.isLoaded()) { status("Native library missing"); running = false; return; }
            RemoteConfig rc = new RemoteConfig(ctx);
            config = rc.fetchLatest();
            shotDb = rc.fetchShotDatabase();
            brain = new Brain(config);
            detector = new Detector(ctx, config);
            uploader = new DataUploader(ctx);
            collector = new ShotDataCollector(ctx, uploader, config);
            humanizer = new Humanizer(config);
            lineMgr = new LineOverlayManager();
            lineMgr.init(ctx);
            NativeVision.reset();
            geoOk = false;
            status("Watching for Carrom Pool...");

            while (running && !Thread.currentThread().isInterrupted()) {
                try {
                    if (!ScreenCapture.isReady()) { status("Screen capture not ready"); sleep(1000); continue; }
                    if (autoFire) {
                        if (Build.VERSION.SDK_INT < 24) {
                            status("Auto play needs Android 7+ (aim assist works on Android 6)");
                            sleep(1000); continue;
                        }
                        if (!InputInjector.isReady()) { status("Turn ON Accessibility service"); sleep(500); continue; }
                        autoStep();
                    } else {
                        aimStep();
                    }
                } catch (Throwable t) { Log.e("loop err", t); sleep(50); }
            }
        } catch (Throwable t) { Log.e("engine init err", t); }
        running = false;
        status("Engine stopped");
        Log.i("Engine ended");
    }

    // =====================================================================================
    //  geometry + tracker helpers
    // =====================================================================================
    private void updateGeo(GameState s) {
        geoField[0] = (float) s.fieldL; geoField[1] = (float) s.fieldT;
        geoField[2] = (float) s.fieldR; geoField[3] = (float) s.fieldB;
        geoL = (float) ((s.boardW + s.boardH) / 2.0);
        geoR = (float) (config.dragFull * s.fieldW());
        // my baseline sits at 84.4 % of the field height (both board themes measured)
        baselineY = (float) (s.fieldT + 0.844 * (s.fieldB - s.fieldT));
        geoOk = true;
    }

    /** 1-2 ms: my striker, turn glow, aim arrow. Result in trk[]. @return true if my striker is visible. */
    private boolean track(Bitmap frame) {
        int rc = NativeVision.track(frame, ScreenCapture.getWidth(), ScreenCapture.getHeight(),
            geoField, baselineY, geoL, geoR, trk);
        return rc == 1;
    }

    private GameState fullDetect(int tries) {
        for (int i = 0; i < tries; i++) {
            Bitmap f = ScreenCapture.grab();
            if (f == null) { sleep(10); continue; }
            GameState s = detector.detect(f);
            if (s != null) return s;
            sleep(15);
        }
        return null;
    }

    // =====================================================================================
    //  AUTO PLAY
    // =====================================================================================
    private long firedAt = 0;
    private boolean glowDropped = true;
    private int glowStable = 0;

    private void autoStep() {
        SpeedProfile sp = SpeedProfile.of(Prefs.getString(Constants.PREF_SPEED, "FULL"));
        Bitmap frame = ScreenCapture.grab();
        if (frame == null) { sleep(4); return; }
        if (!geoOk) {
            GameState s = detector.detect(frame);
            if (s == null) { noBoard(); return; }
            updateGeo(s);
        }
        boolean found = track(frame);
        float glow = found ? trk[4] : 0f;
        long now = System.currentTimeMillis();

        // did the game take our last shot? the glow must disappear at least once
        if (firedAt > 0) {
            if (!found || glow < 0.2f) glowDropped = true;
            long age = now - firedAt;
            if (age < sp.afterShotMs) { sleep(sp.pollMs); return; }
            if (!glowDropped && age < 4500) { status("Shot in progress"); sleep(sp.pollMs); return; }
        }

        if (!found || glow < 0.35f) {
            glowStable = 0;
            hideLines();
            if (!found && ++missCount > 80) { geoOk = false; missCount = 0; }   // layout changed? measure again
            status(found && trk[5] > 0.5f ? "Aiming..." : "Waiting for my turn");
            sleep(sp.pollMs);
            return;
        }
        missCount = 0;
        if (++glowStable < 2) { sleep(sp.pollMs); return; }
        glowStable = 0;
        firedAt = 0;
        playTurn(sp);
    }

    private void playTurn(SpeedProfile sp) {
        String mode = Prefs.getString(Constants.PREF_MODE, "PRO");
        int think = humanizer.reactionDelay(sp);
        if (think > 0) { status("Thinking..."); sleep(think); }

        GameState state = fullDetect(4);
        if (state == null) { noBoard(); return; }
        updateGeo(state);
        resolvePending(state);
        Piece st0 = state.striker();
        if (st0 == null || st0.y < (state.fieldT + state.fieldB) / 2.0) { status("Striker not on my side"); return; }
        double L = geoL;

        // 1) best striker spot on the baseline -> drag the slider there (closed loop)
        if (slideMiss < 3) {
            Brain.Plan p0 = brain.plan(state, mode, true);
            if (p0 != null && Math.abs(p0.strikerX - st0.x) > 0.02 * L) {
                status("Positioning striker...");
                GameState moved = slideStriker(state, p0.strikerX, sp);
                if (moved != null && moved.striker() != null) state = moved;
            }
        }

        // 2) angle + power from the striker's REAL position
        Piece st = state.striker();
        if (st == null) return;
        Shot best = shotDb.lookup(state, config);
        double angle, power, prob = 0;
        if (best != null) { angle = best.angleDeg; power = best.power; }
        else {
            Brain.Plan p = brain.plan(state, mode, false);
            if (p == null) return;
            angle = p.angle; power = p.power; prob = p.prob;
            best = ShotPlanner.makeShot(config, state, st, angle, power);
            best.expectedScore = p.found ? 10 + p.score : 0;
        }

        // 3) preview (same physics that chose the shot)
        SimResult pred = brain.simulate(state, angle, power, true, mode);
        if (config.linesEnabled && Prefs.getBool(Constants.PREF_LINES, true) && pred != null) {
            lineMgr.show(pred.trajectories, Brain.potMarkers(pred.trajectories), null);
            linesShown = true;
        }
        status("Shot: power " + Math.round(power * 100) + "%, chance " + Math.round(prob * 100) + "%");
        if (sp.previewMs > 0) sleep(sp.previewMs);

        // 4) pull back by the power in the aim direction and let go
        double[] swipe = humanizer.humanize(best, sp, config.dragFull * state.fieldW());
        InputInjector.get().swipe((float) swipe[0], (float) swipe[1],
            (float) swipe[2], (float) swipe[3], (long) swipe[4]);
        firedAt = System.currentTimeMillis();
        glowDropped = false;

        totalShots++;
        pending = new Pending();
        pending.before = state; pending.shot = best; pending.pred = pred;
        pending.t = firedAt; pending.dur = (long) swipe[4];
        if (best.expectedScore > 5) successShots++;
        int acc = totalShots > 0 ? (successShots * 100 / totalShots) : 0;
        Prefs.putInt(Constants.PREF_SHOTS_PLAYED, totalShots);
        Prefs.putInt(Constants.PREF_ACCURACY, acc);
        if (listener != null) listener.onShot(totalShots, acc);
        status("Shot fired (" + totalShots + ")");
        sleep(Math.min(sp.afterShotMs, 400));
        hideLines();
    }

    // =====================================================================================
    //  AIM ASSISTANT  (Auto Play OFF, Shot Preview ON) - no blinking
    // =====================================================================================
    private GameState baseState;       // clean snapshot of the pieces, taken ONCE per turn
    private boolean aimingNow = false;
    private boolean suggestionShown = false;

    private void aimStep() {
        String mode = Prefs.getString(Constants.PREF_MODE, "PRO");
        if (!Prefs.getBool(Constants.PREF_LINES, true)) { hideLines(); baseState = null; status("Lines off"); sleep(200); return; }

        Bitmap frame = ScreenCapture.grab();
        if (frame == null) { sleep(4); return; }
        if (!geoOk) {
            hideLines();
            GameState s = detector.detect(frame);
            if (s == null) { noBoard(); return; }
            updateGeo(s);
        }
        boolean found = track(frame);
        boolean aim = found && trk[5] > 0.5f;
        boolean myTurn = found && (trk[4] > 0.35f || aim);

        if (!myTurn) {
            // opponent's turn / pieces rolling / shot just taken: nothing to show, forget the snapshot
            if (baseState != null || linesShown) { hideLines(); baseState = null; aimingNow = false; suggestionShown = false; }
            if (!found && ++missCount > 80) { geoOk = false; missCount = 0; }
            status("Aim assist - waiting for my turn");
            sleep(25);
            return;
        }
        missCount = 0;

        // ---- one clean snapshot per turn (overlay is hidden at this moment) ----
        if (baseState == null) {
            if (linesShown) { hideLines(); sleep(90); frame = ScreenCapture.grab(); if (frame == null) return; }
            GameState s = detector.detect(frame);
            if (s == null) { noBoard(); return; }
            updateGeo(s);
            baseState = s; suggestionShown = false; aimingNow = false;
        }
        Piece st = baseState.striker();
        if (st == null) { baseState = null; return; }
        // the player may slide the striker: follow it live
        if (Math.abs(trk[1] - st.x) > 3 || Math.abs(trk[2] - st.y) > 3) {
            st.x = trk[1]; st.y = trk[2]; suggestionShown = false;
        }

        if (aim) {
            // the player is dragging: simulate exactly this angle + power, live
            aimingNow = true; suggestionShown = false;
            SimResult r = brain.simulate(baseState, trk[6], trk[7], true, mode);
            if (r != null) {
                lineMgr.show(r.trajectories, Brain.potMarkers(r.trajectories), null);
                linesShown = true;
                String msg = r.strikerPotted ? "Aim: STRIKER FOUL!"
                    : (r.pottedIds.isEmpty() ? "Aim: no pot" : "Aim: pots " + r.pottedIds.size());
                status(msg + " (power " + Math.round(trk[7] * 100) + "%)");
            }
            sleep(8);
            return;
        }
        aimingNow = false;

        // ---- not dragging: show the best shot (auto aim) and where to stand ----
        if (!suggestionShown) {
            Brain.Plan sug = brain.plan(baseState, mode, true);
            if (sug != null) {
                GameState hypo = baseState;
                if (Math.abs(sug.strikerX - st.x) > 0.02 * geoL) {
                    hypo = baseState.clone();
                    hypo.striker().x = sug.strikerX;
                }
                SimResult r = brain.simulate(hypo, sug.angle, sug.power, true, mode);
                if (r != null) {
                    lineMgr.show(r.trajectories, Brain.potMarkers(r.trajectories),
                        new double[]{sug.strikerX, st.y});
                    linesShown = true;
                }
                status("Aim assist - best shot (" + Math.round(sug.prob * 100) + "% chance)");
            }
            suggestionShown = true;
        }
        sleep(20);
    }

    private void noBoard() {
        hideLines();
        int code = detector.lastCode();
        status(code < 0 ? "Vision error " + code
            : (AutoAccessibilityService.isTargetAppForeground()
                ? "Board not found - close menu" : "Game not open - waiting"));
        sleep(100);
    }

    private void hideLines() {
        if (linesShown && lineMgr != null) { lineMgr.hide(); linesShown = false; }
    }

    // =====================================================================================
    //  striker slider (closed loop)
    // =====================================================================================
    private double sliderGain = 1.0;   // striker px moved per slider-thumb px (learned while playing)
    private int slideMiss = 0;         // consecutive turns where sliding did nothing

    private GameState slideStriker(GameState s, double targetX, SpeedProfile sp) {
        double L = geoL;
        GameState cur = s;
        boolean everMoved = false;
        for (int i = 0; i < 3; i++) {
            Piece st = cur.striker();
            if (st == null) return null;
            double err = targetX - st.x;
            if (Math.abs(err) < 0.012 * L) break;
            double dx = err / sliderGain;
            // thumb position from vision; if it is not visible assume it sits under the striker
            double tx = cur.thumbX > 0 ? cur.thumbX : st.x;
            double ty = cur.thumbY > 0 ? cur.thumbY : cur.boardY + cur.boardH + 0.35 * L;
            InputInjector.get().swipe((float) tx, (float) ty, (float) (tx + dx), (float) ty, sp.slideMs);
            sleep(sp.slideMs + 90);
            GameState next = fullDetect(6);
            if (next == null || next.striker() == null) return null;
            double moved = next.striker().x - st.x;
            if (Math.abs(moved) > 2) everMoved = true;
            if (Math.abs(dx) > 5 && Math.abs(moved) > 2) {
                double g = moved / dx;
                if (g > 0.3 && g < 3.0) sliderGain = g;
            }
            cur = next;
        }
        slideMiss = everMoved ? 0 : slideMiss + 1;
        return cur;
    }

    // =====================================================================================
    //  data collection (optional, only uploaded when Constants.ONLINE = true)
    // =====================================================================================
    private static class Pending {
        GameState before; Shot shot; SimResult pred; long t; long dur;
    }

    private void resolvePending(GameState now) {
        if (pending == null) return;
        long age = System.currentTimeMillis() - pending.t;
        if (age > 60000) { pending = null; return; }
        if (age < 1500) return;
        collector.record(pending.before, pending.shot, pending.pred, now, pending.dur, shotDb);
        pending = null;
    }

    private void status(String s) {
        if (s != null && s.equals(currentStatus)) return;
        currentStatus = s;
        if (listener != null) listener.onStatus(s);
    }

    private void sleep(long ms) {
        try { Thread.sleep(ms); }
        catch (InterruptedException e) { Thread.currentThread().interrupt(); }
    }
}
