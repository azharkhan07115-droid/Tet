package com.carrombot.tool.engine;

import android.content.Context;
import android.graphics.Bitmap;
import com.carrombot.tool.data.*;
import com.carrombot.tool.input.Humanizer;
import com.carrombot.tool.input.InputInjector;
import com.carrombot.tool.remote.DataUploader;
import com.carrombot.tool.remote.RemoteConfig;
import com.carrombot.tool.remote.ShotDataCollector;
import com.carrombot.tool.remote.ShotDatabase;
import com.carrombot.tool.service.AutoAccessibilityService;
import com.carrombot.tool.ui.LineOverlayManager;
import com.carrombot.tool.util.Constants;
import com.carrombot.tool.util.Log;
import com.carrombot.tool.util.Prefs;
import com.carrombot.tool.vision.Detector;
import com.carrombot.tool.vision.NativeVision;
import com.carrombot.tool.vision.ScreenCapture;

import java.util.List;

/**
 * Two modes (same thread):
 *  - autoFire = true : reads the board, plans (C++), moves the striker, aims, sets the power and shoots.
 *  - autoFire = false: aim assistant. Reads the game's own aim arrow while YOU drag and draws, in real time,
 *                      where every piece will go for that angle + power. Never touches the screen.
 * Everything heavy (vision, physics, planner) runs in C++ (libcarromvision.so). No server needed.
 */
public class AutoPlayEngine {

    public interface Listener {
        void onShot(int total, int acc);
        void onState(String state);
        void onStatus(String status);
    }

    private volatile boolean running = false;
    private volatile boolean autoFire = true;
    private volatile String currentStatus = "Idle";
    private Thread worker;
    private final Context ctx;
    private GameConfig config;
    private Listener listener;

    private Brain brain;
    private Detector detector;
    private TurnDetector turnDetector;
    private ShotDatabase shotDb;
    private DataUploader uploader;
    private ShotDataCollector collector;
    private Pending pending;
    private LineOverlayManager lineMgr;
    private Humanizer humanizer;
    private boolean linesShown = false;

    private int totalShots = 0, successShots = 0;

    public AutoPlayEngine(Context ctx) { this.ctx = ctx.getApplicationContext(); }
    public void setListener(Listener l) { this.listener = l; }
    public boolean isRunning() { return running; }
    public String getStatus() { return currentStatus; }

    /** autoFire=true: play by itself. autoFire=false: aim assistant only. */
    public synchronized void start(boolean fire) {
        autoFire = fire;
        if (running) return;
        running = true;
        worker = new Thread(this::loop, "bot-engine");
        worker.setPriority(Thread.NORM_PRIORITY + 1);
        worker.start();
        status("Starting...");
    }

    public synchronized void stop() {
        running = false;
        if (worker != null) { worker.interrupt(); worker = null; }
        if (lineMgr != null) lineMgr.hide();
        if (collector != null) collector.flush();
        status("Stopped");
    }

    private void loop() {
        Log.i("Engine started");
        try {
            if (!NativeVision.isLoaded()) { status("Native library missing"); running = false; return; }
            RemoteConfig rc = new RemoteConfig(ctx);
            config = rc.fetchLatest();
            shotDb = rc.fetchShotDatabase();
            brain = new Brain(config);
            detector = new Detector(ctx, config);
            turnDetector = new TurnDetector(config);
            uploader = new DataUploader(ctx);
            collector = new ShotDataCollector(ctx, uploader, config);
            humanizer = new Humanizer(config);
            lineMgr = new LineOverlayManager();
            lineMgr.init(ctx);
            status("Watching for Carrom Pool...");

            while (running && !Thread.currentThread().isInterrupted()) {
                try {
                    if (!ScreenCapture.isReady()) { status("Screen capture not ready"); sleep(1000); continue; }
                    if (autoFire) {
                        if (!InputInjector.isReady()) { status("Turn ON Accessibility service"); sleep(500); continue; }
                        autoStep();
                    } else {
                        aimStep();
                    }
                } catch (Throwable t) { Log.e("loop err", t); sleep(50); }
            }
        } catch (Throwable t) { Log.e("engine init err", t); }
        running = false;
        status("Engine stopped");
        Log.i("Engine ended");
    }

    // =====================================================================================
    //  AUTO PLAY
    // =====================================================================================
    private void autoStep() {
        String mode = Prefs.getString(Constants.PREF_MODE, "PRO");
        Bitmap frame = ScreenCapture.grab();
        if (frame == null) { sleep(5); return; }
        GameState state = detector.detect(frame);
        if (state == null) { noBoard(); return; }

        resolvePending(state);
        if (!turnDetector.isMyTurn(state)) {
            hideLines();
            status("Waiting for my turn");
            sleep(30);
            return;
        }

        // 1) best striker spot on the baseline -> move the slider there (closed loop)
        Piece st0 = state.striker();
        double L = (state.boardW + state.boardH) / 2.0;
        if (st0 != null && slideMiss < 3) {
            Brain.Plan p0 = brain.plan(state, mode, true);
            if (p0 != null && Math.abs(p0.strikerX - st0.x) > 0.02 * L) {
                status("Positioning striker...");
                GameState moved = slideStriker(state, p0.strikerX);
                if (moved != null && moved.striker() != null) state = moved;
            }
        }

        // 2) angle + power from the striker's REAL position
        Piece st = state.striker();
        if (st == null) { sleep(20); return; }
        Shot best = shotDb.lookup(state, config);
        double predAngle, predPower;
        if (best != null) { predAngle = best.angleDeg; predPower = best.power; }
        else {
            Brain.Plan p = brain.plan(state, mode, false);
            if (p == null) { sleep(20); return; }
            predAngle = p.angle; predPower = p.power;
            best = ShotPlanner.makeShot(config, state, st, p.angle, p.power);
            best.expectedScore = p.found ? 10 + p.score : 0;
        }

        // 3) preview (same physics that decided the shot)
        SimResult pred = brain.simulate(state, predAngle, predPower, true, mode);
        if (config.linesEnabled && Prefs.getBool(Constants.PREF_LINES, true) && pred != null) {
            lineMgr.show(pred.trajectories, Brain.potMarkers(pred.trajectories), null);
            linesShown = true;
            status("Shot ready");
            sleep(60);
        }

        // 4) drag: pull back by the power, in the aim direction
        double[] swipe = humanizer.humanize(best);
        InputInjector.get().swipe((float) swipe[0], (float) swipe[1],
            (float) swipe[2], (float) swipe[3], (long) swipe[4]);
        totalShots++;
        pending = new Pending();
        pending.before = state; pending.shot = best; pending.pred = pred;
        pending.t = System.currentTimeMillis(); pending.dur = (long) swipe[4];
        if (best.expectedScore > 5) successShots++;
        int acc = totalShots > 0 ? (successShots * 100 / totalShots) : 0;
        Prefs.putInt(Constants.PREF_SHOTS_PLAYED, totalShots);
        Prefs.putInt(Constants.PREF_ACCURACY, acc);
        if (listener != null) listener.onShot(totalShots, acc);
        status("Shot fired (" + totalShots + ")");
        sleep(350);
        hideLines();
    }

    // =====================================================================================
    //  AIM ASSISTANT  (Auto Play OFF, Shot Preview ON)
    // =====================================================================================
    private GameState baseState;       // clean board snapshot (taken while the overlay is hidden)
    private long baseTime = 0;
    private boolean aimingNow = false;
    private int aimMiss = 0;
    private boolean suggestionShown = false;
    private final float[] aimOut = new float[6];
    private final float[] fieldArr = new float[4];

    private void aimStep() {
        String mode = Prefs.getString(Constants.PREF_MODE, "PRO");
        if (!Prefs.getBool(Constants.PREF_LINES, true)) { hideLines(); status("Lines off"); sleep(200); return; }
        long now = System.currentTimeMillis();

        // ---- refresh the clean board snapshot (never while the player is aiming) ----
        if (baseState == null || (!aimingNow && now - baseTime > 700)) {
            hideLines();
            sleep(100);                                  // let the overlay disappear from the captured frame
            Bitmap f = ScreenCapture.grab();
            if (f == null) { sleep(10); return; }
            GameState s = detector.detect(f);
            if (s == null) { baseState = null; noBoard(); return; }
            if (!turnDetector.isMyTurnFast(s)) {
                baseState = null;
                status("Aim assist - waiting for my turn");
                sleep(80);
                return;
            }
            baseState = s; baseTime = now; suggestionShown = false; aimingNow = false; aimMiss = 0;
        }

        Piece st = baseState.striker();
        if (st == null) { baseState = null; return; }
        double L = (baseState.boardW + baseState.boardH) / 2.0;

        // ---- read the game's own aim arrow (angle + pull length) ----
        Bitmap frame = ScreenCapture.grab();
        if (frame == null) { sleep(5); return; }
        fieldArr[0] = (float) baseState.fieldL; fieldArr[1] = (float) baseState.fieldT;
        fieldArr[2] = (float) baseState.fieldR; fieldArr[3] = (float) baseState.fieldB;
        float R = (float) (config.dragFull * baseState.fieldW());
        int ok = NativeVision.detectAim(frame, ScreenCapture.getWidth(), ScreenCapture.getHeight(),
            (float) st.x, (float) st.y, (float) st.r, (float) L, R, fieldArr, aimOut);

        if (ok == 1) {
            // YOU are aiming: simulate exactly this angle + power and draw it live
            aimingNow = true; aimMiss = 0; suggestionShown = false;
            SimResult r = brain.simulate(baseState, aimOut[1], aimOut[2], true, mode);
            if (r != null) {
                lineMgr.show(r.trajectories, Brain.potMarkers(r.trajectories), null);
                linesShown = true;
                String msg = r.strikerPotted ? "Aim: STRIKER FOUL!" : (r.pottedIds.isEmpty()
                    ? "Aim: no pot" : "Aim: pots " + r.pottedIds.size());
                status(msg + " (power " + Math.round(aimOut[2] * 100) + "%)");
            }
            sleep(12);
            return;
        }

        if (aimingNow) {
            // arrow gone: you released (shot) or cancelled. Debounce a few frames, then re-read the board.
            if (++aimMiss < 4) { sleep(15); return; }
            aimingNow = false; baseState = null; hideLines();
            sleep(300);
            return;
        }

        // ---- not aiming: show the best shot as a suggestion (auto aim) ----
        if (!suggestionShown) {
            Brain.Plan sug = brain.plan(baseState, mode, true);
            if (sug != null) {
                GameState hypo = baseState;
                if (Math.abs(sug.strikerX - st.x) > 0.02 * L) {
                    hypo = baseState.clone();
                    hypo.striker().x = sug.strikerX;
                }
                SimResult r = brain.simulate(hypo, sug.angle, sug.power, true, mode);
                if (r != null) {
                    lineMgr.show(r.trajectories, Brain.potMarkers(r.trajectories),
                        new double[]{sug.strikerX, st.y});
                    linesShown = true;
                }
            }
            suggestionShown = true;
            status("Aim assist - best shot shown");
        }
        sleep(30);
    }

    private void noBoard() {
        hideLines();
        int code = detector.lastCode();
        status(code < 0 ? "Vision error " + code
            : (AutoAccessibilityService.isTargetAppForeground()
                ? "Board not found - close menu" : "Game not open - waiting"));
        sleep(100);
    }

    private void hideLines() {
        if (linesShown && lineMgr != null) { lineMgr.hide(); linesShown = false; }
    }

    // =====================================================================================
    //  striker slider (closed loop)
    // =====================================================================================
    private double sliderGain = 1.0;   // striker px moved per slider-thumb px (learned while playing)
    private int slideMiss = 0;         // consecutive turns where sliding did nothing

    private GameState observe(long timeoutMs) {
        long end = System.currentTimeMillis() + timeoutMs;
        while (System.currentTimeMillis() < end) {
            Bitmap f = ScreenCapture.grab();
            if (f == null) { sleep(8); continue; }
            return detector.detect(f);
        }
        return null;
    }

    private GameState slideStriker(GameState s, double targetX) {
        double L = (s.boardW + s.boardH) / 2.0;
        GameState cur = s;
        boolean everMoved = false;
        for (int i = 0; i < 3; i++) {
            Piece st = cur.striker();
            if (st == null) return null;
            double err = targetX - st.x;
            if (Math.abs(err) < 0.012 * L) break;
            double dx = err / sliderGain;
            // thumb position from vision; if it is not visible assume it sits under the striker
            double tx = cur.thumbX > 0 ? cur.thumbX : st.x;
            double ty = cur.thumbY > 0 ? cur.thumbY : cur.boardY + cur.boardH + 0.35 * L;
            InputInjector.get().swipe((float) tx, (float) ty, (float) (tx + dx), (float) ty, 160);
            sleep(260);
            GameState next = observe(400);
            if (next == null || next.striker() == null) return null;
            double moved = next.striker().x - st.x;
            if (Math.abs(moved) > 2) everMoved = true;
            if (Math.abs(dx) > 5 && Math.abs(moved) > 2) {
                double g = moved / dx;
                if (g > 0.3 && g < 3.0) sliderGain = g;
            }
            cur = next;
        }
        slideMiss = everMoved ? 0 : slideMiss + 1;
        return cur;
    }

    // =====================================================================================
    //  data collection (optional, only uploaded when Constants.ONLINE = true)
    // =====================================================================================
    private static class Pending {
        GameState before; Shot shot; SimResult pred; long t; long dur; int stable;
    }

    private void resolvePending(GameState now) {
        if (pending == null) return;
        long age = System.currentTimeMillis() - pending.t;
        if (age > 25000) { pending = null; return; }
        if (age < 600) return;
        if (now.maxMotion() > 0.006 * now.boardW) { pending.stable = 0; return; }
        if (++pending.stable < 3) return;
        collector.record(pending.before, pending.shot, pending.pred, now, pending.dur, shotDb);
        pending = null;
    }

    private void status(String s) {
        if (s != null && s.equals(currentStatus)) return;
        currentStatus = s;
        if (listener != null) listener.onStatus(s);
    }

    private void sleep(long ms) {
        try { Thread.sleep(ms); }
        catch (InterruptedException e) { Thread.currentThread().interrupt(); }
    }
}
