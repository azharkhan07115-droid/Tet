package com.carrombot.tool.engine;

import android.content.Context;
import android.graphics.Bitmap;
import com.carrombot.tool.data.*;
import com.carrombot.tool.input.Humanizer;
import com.carrombot.tool.input.InputInjector;
import com.carrombot.tool.remote.DataUploader;
import com.carrombot.tool.remote.RemoteConfig;
import com.carrombot.tool.remote.ShotDatabase;
import com.carrombot.tool.service.AutoAccessibilityService;
import com.carrombot.tool.ui.LineOverlayManager;
import com.carrombot.tool.util.Constants;
import com.carrombot.tool.util.Log;
import com.carrombot.tool.util.Prefs;
import com.carrombot.tool.vision.Detector;
import com.carrombot.tool.vision.ScreenCapture;

import java.util.List;

public class AutoPlayEngine {

    public interface Listener {
        void onShot(int total, int acc);
        void onState(String state);
        void onStatus(String status);
    }

    private volatile boolean running = false;
    private volatile String currentStatus = "Idle";
    private Thread worker;
    private final Context ctx;
    private GameConfig config;
    private Listener listener;

    private PhysicsSimulator physics;
    private TrajectorySimulator trajSim;
    private Detector detector;
    private TurnDetector turnDetector;
    private ShotDatabase shotDb;
    private DataUploader uploader;
    private LineOverlayManager lineMgr;
    private Humanizer humanizer;

    private int totalShots = 0, successShots = 0;

    public AutoPlayEngine(Context ctx) { this.ctx = ctx.getApplicationContext(); }
    public void setListener(Listener l) { this.listener = l; }
    public boolean isRunning() { return running; }
    public String getStatus() { return currentStatus; }

    public synchronized void start() {
        if (running) return;
        running = true;
        worker = new Thread(this::loop, "bot-engine");
        worker.setPriority(Thread.NORM_PRIORITY + 1);
        worker.start();
        status("Starting...");
    }

    public synchronized void stop() {
        running = false;
        if (worker != null) { worker.interrupt(); worker = null; }
        if (lineMgr != null) lineMgr.hide();
        status("Stopped");
    }

    private void loop() {
        Log.i("Engine started");
        try {
            try {
                if (org.opencv.android.OpenCVLoader.initDebug()) Log.i("OpenCV loaded");
                else Log.e("OpenCV init failed");
            } catch (Throwable t) { Log.e("OpenCV error", t); }
            RemoteConfig rc = new RemoteConfig(ctx);
            config = rc.fetchLatest();
            shotDb = rc.fetchShotDatabase();
            physics = new PhysicsSimulator(config);
            trajSim = new TrajectorySimulator(physics);
            detector = new Detector(ctx, config);
            turnDetector = new TurnDetector(config);
            uploader = new DataUploader(ctx);
            humanizer = new Humanizer(config);
            lineMgr = new LineOverlayManager();
            lineMgr.init(ctx);

            String mode = Prefs.getString(Constants.PREF_MODE, "SAFE");
            status("Watching for Carrom Pool...");

            while (running && !Thread.currentThread().isInterrupted()) {
                try {
                    // ─── LAYER 1: PACKAGE GUARD ───
                    if (!AutoAccessibilityService.isTargetAppForeground()) {
                        if (lineMgr != null) lineMgr.hide();
                        status("Game not open - waiting");
                        sleep(500);
                        continue;
                    }

                    if (!ScreenCapture.isReady()) {
                        status("Screen capture not ready");
                        sleep(1000);
                        continue;
                    }

                    Bitmap frame = ScreenCapture.grab();
                    if (frame == null) { sleep(20); continue; }

                    GameState state = detector.detect(frame);
                    frame.recycle();
                    if (state == null) { sleep(20); continue; }

                    if (!turnDetector.isMyTurn(state)) {
                        status("Waiting for my turn");
                        sleep(100);
                        continue;
                    }

                    Shot best = shotDb.lookup(state);
                    if (best == null) best = physics.findBestShot(state, mode);
                    if (best == null) { sleep(50); continue; }

                    if (Prefs.getBool(Constants.PREF_LINES, true)) {
                        List<Trajectory> trajs = trajSim.simulateLines(state, best);
                        List<double[]> pots = trajSim.getPotMarkers(trajs);
                        lineMgr.show(trajs, pots);
                        status("Preview...");
                        sleep(400);
                    }

                    double[] swipe = humanizer.humanize(best);
                    InputInjector.get().swipe((float) swipe[0], (float) swipe[1],
                        (float) swipe[2], (float) swipe[3], (long) swipe[4]);
                    totalShots++;
                    if (best.expectedScore > 5) successShots++;

                    int acc = totalShots > 0 ? (successShots * 100 / totalShots) : 0;
                    Prefs.putInt(Constants.PREF_SHOTS_PLAYED, totalShots);
                    Prefs.putInt(Constants.PREF_ACCURACY, acc);
                    if (listener != null) listener.onShot(totalShots, acc);

                    status("Shot fired (" + totalShots + ")");
                    sleep(1500);
                    if (lineMgr != null) lineMgr.hide();

                } catch (InterruptedException ie) { break; }
                catch (Throwable t) { Log.e("loop err", t); sleep(50); }
            }
        } catch (Throwable t) { Log.e("engine init err", t); }
        running = false;
        status("Engine stopped");
        Log.i("Engine ended");
    }

    private void status(String s) {
        currentStatus = s;
        if (listener != null) listener.onStatus(s);
    }

    private void sleep(long ms) {
        try { Thread.sleep(ms); }
        catch (InterruptedException e) { Thread.currentThread().interrupt(); }
    }
}
