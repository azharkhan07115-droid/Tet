package com.carrombot.tool.engine;

import android.content.Context;
import android.graphics.Bitmap;
import com.carrombot.tool.data.*;
import com.carrombot.tool.input.Humanizer;
import com.carrombot.tool.input.InputInjector;
import com.carrombot.tool.remote.DataUploader;
import com.carrombot.tool.remote.ShotDataCollector;
import com.carrombot.tool.remote.RemoteConfig;
import com.carrombot.tool.remote.ShotDatabase;
import com.carrombot.tool.service.AutoAccessibilityService;
import com.carrombot.tool.ui.LineOverlayManager;
import com.carrombot.tool.util.Constants;
import com.carrombot.tool.util.Log;
import com.carrombot.tool.util.Prefs;
import com.carrombot.tool.vision.Detector;
import com.carrombot.tool.vision.ScreenCapture;

import java.util.List;

public class AutoPlayEngine {

    public interface Listener {
        void onShot(int total, int acc);
        void onState(String state);
        void onStatus(String status);
    }

    private volatile boolean running = false;
    private volatile String currentStatus = "Idle";
    private Thread worker;
    private final Context ctx;
    private GameConfig config;
    private Listener listener;

    private ShotPlanner planner;
    private PhysicsSimulator physics;
    private TrajectorySimulator trajSim;
    private Detector detector;
    private TurnDetector turnDetector;
    private ShotDatabase shotDb;
    private DataUploader uploader;
    private ShotDataCollector collector;
    private Pending pending;
    private LineOverlayManager lineMgr;
    private Humanizer humanizer;

    private int totalShots = 0, successShots = 0;

    public AutoPlayEngine(Context ctx) { this.ctx = ctx.getApplicationContext(); }
    public void setListener(Listener l) { this.listener = l; }
    public boolean isRunning() { return running; }
    public String getStatus() { return currentStatus; }

    private volatile boolean autoFire = true;
    private boolean linesShown = false;

    /** autoFire=true: play by itself. autoFire=false: aim assistant only (draws the best shot, never touches the screen). */
    public synchronized void start(boolean fire) {
        autoFire = fire;
        if (running) return;
        running = true;
        worker = new Thread(this::loop, "bot-engine");
        worker.setPriority(Thread.NORM_PRIORITY + 1);
        worker.start();
        status("Starting...");
    }

    public synchronized void stop() {
        running = false;
        if (worker != null) { worker.interrupt(); worker = null; }
        if (lineMgr != null) lineMgr.hide();
        if (collector != null) collector.flush();
        status("Stopped");
    }

    private void loop() {
        Log.i("Engine started");
        try {
            RemoteConfig rc = new RemoteConfig(ctx);
            config = rc.fetchLatest();
            shotDb = rc.fetchShotDatabase();
            physics = new PhysicsSimulator(config);
            trajSim = new TrajectorySimulator(physics);
            planner = new ShotPlanner(config);
            detector = new Detector(ctx, config);
            turnDetector = new TurnDetector(config);
            uploader = new DataUploader(ctx);
            collector = new ShotDataCollector(ctx, uploader, config);
            humanizer = new Humanizer(config);
            lineMgr = new LineOverlayManager();
            lineMgr.init(ctx);

            status("Watching for Carrom Pool...");

            while (running && !Thread.currentThread().isInterrupted()) {
                try {
                    String mode = Prefs.getString(Constants.PREF_MODE, "SAFE");

                    if (autoFire && !InputInjector.isReady()) {
                        status("Turn ON Accessibility service");
                        sleep(500);
                        continue;
                    }
                    if (!ScreenCapture.isReady()) {
                        status("Screen capture not ready");
                        sleep(1000);
                        continue;
                    }

                    Bitmap frame = ScreenCapture.grab();
                    if (frame == null) { sleep(5); continue; }

                    GameState state = detector.detect(frame);
                    if (state == null) {
                        hideLines();
                        int code = detector.lastCode();
                        status(code < 0 ? "Vision error " + code
                            : (AutoAccessibilityService.isTargetAppForeground()
                                ? "Board not found - close menu" : "Game not open - waiting"));
                        sleep(100);
                        continue;
                    }

                    if (!autoFire) {
                        aimAssist(state, mode);
                        continue;
                    }

                    resolvePending(state);

                    if (!turnDetector.isMyTurn(state)) {
                        hideLines();
                        status("Waiting for my turn");
                        sleep(30);
                        continue;
                    }

                    // move the striker to the best spot on its baseline (closed loop, uses the slider)
                    Piece st0 = state.striker();
                    double L = (state.boardW + state.boardH) / 2.0;
                    if (st0 != null && slideMiss < 3) {
                        double bestX = planner.bestBaselineX(state, mode);
                        if (Math.abs(bestX - st0.x) > 0.02 * L) {
                            status("Positioning striker...");
                            GameState moved = slideStriker(state, bestX);
                            if (moved != null) state = moved;
                        }
                    }

                    Shot best = shotDb.lookup(state, config);
                    if (best == null) best = planner.plan(state, mode);
                    if (best == null) { sleep(20); continue; }
                    best = refine(state, best);

                    SimResult pred = trajSim.run(state, best.angleDeg, best.power, true);
                    if (config.linesEnabled && Prefs.getBool(Constants.PREF_LINES, true) && pred != null) {
                        List<Trajectory> trajs = pred.trajectories;
                        List<double[]> pots = trajSim.getPotMarkers(trajs);
                        lineMgr.show(trajs, pots, null);
                        linesShown = true;
                        status("Preview...");
                        sleep(60);
                    }

                    double[] swipe = humanizer.humanize(best);
                    InputInjector.get().swipe((float) swipe[0], (float) swipe[1],
                        (float) swipe[2], (float) swipe[3], (long) swipe[4]);
                    totalShots++;
                    pending = new Pending();
                    pending.before = state; pending.shot = best; pending.pred = pred;
                    pending.t = System.currentTimeMillis(); pending.dur = (long) swipe[4];
                    if (best.expectedScore > 5) successShots++;

                    int acc = totalShots > 0 ? (successShots * 100 / totalShots) : 0;
                    Prefs.putInt(Constants.PREF_SHOTS_PLAYED, totalShots);
                    Prefs.putInt(Constants.PREF_ACCURACY, acc);
                    if (listener != null) listener.onShot(totalShots, acc);

                    status("Shot fired (" + totalShots + ")");
                    sleep(350);
                    hideLines();

                } catch (Throwable t) { Log.e("loop err", t); sleep(50); }
            }
        } catch (Throwable t) { Log.e("engine init err", t); }
        running = false;
        status("Engine stopped");
        Log.i("Engine ended");
    }

    // ---- striker slider (closed loop) ----
    private double sliderGain = 1.0;   // striker px moved per slider-thumb px (learned while playing)
    private int slideMiss = 0;         // consecutive turns where sliding did nothing

    private GameState observe(long timeoutMs) {
        long end = System.currentTimeMillis() + timeoutMs;
        while (System.currentTimeMillis() < end) {
            Bitmap f = ScreenCapture.grab();
            if (f == null) { sleep(8); continue; }
            GameState gs = detector.detect(f);
            return gs;
        }
        return null;
    }

    private GameState slideStriker(GameState s, double targetX) {
        double L = (s.boardW + s.boardH) / 2.0;
        GameState cur = s;
        boolean everMoved = false;
        for (int i = 0; i < 3; i++) {
            Piece st = cur.striker();
            if (st == null) return null;
            double err = targetX - st.x;
            if (Math.abs(err) < 0.012 * L) break;
            double dx = err / sliderGain;
            // thumb position from vision; if it is not visible assume it sits under the striker
            double tx = cur.thumbX > 0 ? cur.thumbX : st.x;
            double ty = cur.thumbY > 0 ? cur.thumbY : cur.boardY + cur.boardH + 0.35 * L;
            InputInjector.get().swipe((float) tx, (float) ty, (float) (tx + dx), (float) ty, 160);
            sleep(260);
            GameState next = observe(400);
            if (next == null || next.striker() == null) return null;
            double moved = next.striker().x - st.x;
            if (Math.abs(moved) > 2) everMoved = true;
            if (Math.abs(dx) > 5 && Math.abs(moved) > 2) {
                double g = moved / dx;
                if (g > 0.3 && g < 3.0) sliderGain = g;
            }
            cur = next;
        }
        slideMiss = everMoved ? 0 : slideMiss + 1;
        return cur;
    }

    // ---- power refinement: pick the power the simulator says actually pots ----
    private double mineScore(GameState st, SimResult r) {
        if (r == null) return -1e9;
        double sc = 0;
        for (String id : r.pottedIds)
            for (Piece p : st.pieces)
                if (p.id.equals(id)) {
                    if (p.type == PieceType.MINE) sc += 10;
                    else if (p.type == PieceType.QUEEN) sc += 6;
                    else if (p.type == PieceType.OPP) sc -= 8;
                }
        if (r.strikerPotted) sc -= 15;
        return sc;
    }

    private Shot refine(GameState state, Shot shot) {
        Piece st = state.striker();
        if (st == null || shot.expectedScore < 5) return shot;
        double[] f = {1.0, 1.12, 0.9, 1.25, 0.8, 1.4, 0.7};
        double bestSc = -1e9, bestP = shot.power;
        for (double k : f) {
            double pw = Math.max(0.2, Math.min(1.0, shot.power * k));
            double sc = mineScore(state, trajSim.run(state, shot.angleDeg, pw, false));
            if (sc > bestSc + 1e-9) { bestSc = sc; bestP = pw; }
            if (sc >= 10) break;
        }
        if (Math.abs(bestP - shot.power) < 1e-9) return shot;
        Shot s2 = ShotPlanner.makeShot(config, state, st, shot.angleDeg, bestP);
        s2.expectedScore = shot.expectedScore;
        return s2;
    }

    // ---- data collection: compare what the simulator predicted with what really happened ----
    private static class Pending {
        GameState before; Shot shot; SimResult pred; long t; long dur; int stable;
    }

    private void resolvePending(GameState now) {
        if (pending == null) return;
        long age = System.currentTimeMillis() - pending.t;
        if (age > 25000) { pending = null; return; }
        if (age < 600) return;
        if (now.maxMotion() > 0.006 * now.boardW) { pending.stable = 0; return; }
        if (++pending.stable < 3) return;
        collector.record(pending.before, pending.shot, pending.pred, now, pending.dur, shotDb);
        pending = null;
    }

    private void hideLines() {
        if (linesShown && lineMgr != null) { lineMgr.hide(); linesShown = false; }
    }

    /**
     * Aim assistant (Auto Play OFF, Shot Preview ON): shows the best shot as lines + a ring where the
     * striker should stand. Never touches the screen. The lines blink off for ~90 ms between updates so
     * the next frame is read without the overlay on top of it.
     */
    private void aimAssist(GameState state, String mode) {
        if (!Prefs.getBool(Constants.PREF_LINES, true) || !turnDetector.isMyTurnFast(state)) {
            hideLines();
            status("Aim assist - waiting for my turn");
            sleep(60);
            return;
        }
        Piece st = state.striker();
        double L = (state.boardW + state.boardH) / 2.0;
        double bestX = planner.bestBaselineX(state, mode);
        GameState hypo = state;
        if (Math.abs(bestX - st.x) > 0.02 * L) {
            hypo = state.clone();
            hypo.striker().x = bestX;
        }
        Shot best = planner.plan(hypo, mode);
        if (best == null) { sleep(60); return; }
        best = refine(hypo, best);
        SimResult pred = trajSim.run(hypo, best.angleDeg, best.power, true);
        if (pred != null) {
            lineMgr.show(pred.trajectories, trajSim.getPotMarkers(pred.trajectories),
                new double[]{bestX, st.y});
            linesShown = true;
        }
        status("Aim assist");
        sleep(450);
        hideLines();
        sleep(90);
    }

    private void status(String s) {
        if (s != null && s.equals(currentStatus)) return;
        currentStatus = s;
        if (listener != null) listener.onStatus(s);
    }

    private void sleep(long ms) {
        try { Thread.sleep(ms); }
        catch (InterruptedException e) { Thread.currentThread().interrupt(); }
    }
}
