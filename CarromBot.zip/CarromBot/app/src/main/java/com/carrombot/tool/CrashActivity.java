package com.carrombot.tool;

import android.app.Activity;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.graphics.Typeface;
import android.os.Bundle;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;
import com.carrombot.tool.util.Constants;

/** Alag process (:crash) me chalti hai taaki main app crash ho tab bhi error dikhe. */
public class CrashActivity extends Activity {

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        final String trace = getIntent() != null && getIntent().getStringExtra("trace") != null
            ? getIntent().getStringExtra("trace") : "(details nahi mile)";
        try {
            getSharedPreferences(Constants.PREFS, MODE_PRIVATE).edit().remove("last_crash").commit();
        } catch (Throwable ignored) {}

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(0xFF0A0A0C);
        root.setPadding(32, 32, 32, 32);
        root.setFitsSystemWindows(true);

        TextView title = new TextView(this);
        title.setText("App crash ho gaya.\nIs screen ka screenshot sukuna ko do.");
        title.setTextColor(0xFFFF3355);
        title.setTextSize(16);
        title.setTypeface(Typeface.DEFAULT_BOLD);
        root.addView(title);

        ScrollView sv = new ScrollView(this);
        TextView tv = new TextView(this);
        tv.setText(trace);
        tv.setTextColor(0xFFE8E8ED);
        tv.setTextSize(10);
        tv.setTypeface(Typeface.MONOSPACE);
        tv.setTextIsSelectable(true);
        tv.setPadding(0, 24, 0, 24);
        sv.addView(tv);
        root.addView(sv, new LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));

        Button copy = new Button(this);
        copy.setText("COPY ERROR");
        copy.setOnClickListener(v -> {
            ClipboardManager cm = (ClipboardManager) getSystemService(CLIPBOARD_SERVICE);
            if (cm != null) cm.setPrimaryClip(ClipData.newPlainText("crash", trace));
            Toast.makeText(this, "Copied", Toast.LENGTH_SHORT).show();
        });
        root.addView(copy);

        Button close = new Button(this);
        close.setText("CLOSE");
        close.setOnClickListener(v -> {
            finishAffinity();
            android.os.Process.killProcess(android.os.Process.myPid());
        });
        root.addView(close);

        setContentView(root);
    }
}
