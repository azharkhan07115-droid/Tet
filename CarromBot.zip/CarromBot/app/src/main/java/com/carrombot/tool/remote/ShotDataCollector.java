package com.carrombot.tool.remote;

import android.content.Context;
import android.os.Build;
import com.carrombot.tool.data.*;
import com.carrombot.tool.util.Log;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.UUID;

/**
 * Builds one JSON "match" out of many shots (board state, shot, predicted vs real result,
 * all coordinates normalised 0..1 so any phone resolution produces comparable data)
 * and hands it to DataUploader. Gameplay data only - no personal data.
 */
public class ShotDataCollector {
    private final DataUploader uploader;
    private final GameConfig cfg;
    private String matchId = UUID.randomUUID().toString();
    private JSONArray shots = new JSONArray();

    public ShotDataCollector(Context ctx, DataUploader up, GameConfig cfg) {
        this.uploader = up; this.cfg = cfg;
    }

    private static int count(GameState s, PieceType t) {
        int n = 0;
        for (Piece p : s.pieces) if (p.type == t && !p.potted) n++;
        return n;
    }

    private static JSONArray pt(GameState s, double x, double y) throws Exception {
        return new JSONArray().put(Double.parseDouble(ShotDatabase.q(s.nx(x))))
                              .put(Double.parseDouble(ShotDatabase.q(s.ny(y))));
    }

    public void record(GameState before, Shot shot, SimResult pred, GameState after,
                       long durationMs, ShotDatabase hasher) {
        try {
            Piece st = before.striker();
            if (st == null) return;

            int mineBefore = count(before, PieceType.MINE), mineAfter = count(after, PieceType.MINE);
            int oppBefore = count(before, PieceType.OPP), oppAfter = count(after, PieceType.OPP);
            int qBefore = count(before, PieceType.QUEEN), qAfter = count(after, PieceType.QUEEN);
            int actualMine = Math.max(0, mineBefore - mineAfter);
            int actualOpp = Math.max(0, oppBefore - oppAfter);
            int actualQ = Math.max(0, qBefore - qAfter);

            JSONArray predIds = new JSONArray();
            int predMine = 0;
            boolean strikerPotted = false;
            double predScore = 0;
            if (pred != null) {
                for (String id : pred.pottedIds) {
                    predIds.put(id);
                    for (Piece p : before.pieces) if (p.id.equals(id) && p.type == PieceType.MINE) predMine++;
                }
                strikerPotted = pred.strikerPotted;
                predScore = pred.score;
            }
            double conf = Math.min(before.detectionConfidence, after.detectionConfidence);
            String tier = DataQualityFilter.tier(conf, predMine, actualMine);
            if (DataQualityFilter.DISCARD.equals(tier)) return;

            JSONObject board = new JSONObject();
            board.put("striker", pt(before, st.x, st.y));
            JSONArray pucks = new JSONArray();
            for (Piece p : before.pucks()) {
                String ty = p.type == PieceType.MINE ? "mine" : (p.type == PieceType.OPP ? "opp" : "queen");
                pucks.put(new JSONObject().put("id", p.id).put("type", ty).put("pos", pt(before, p.x, p.y)));
            }
            board.put("pucks", pucks);
            JSONArray pockets = new JSONArray();
            for (double[] pk : before.pockets) pockets.put(pt(before, pk[0], pk[1]));
            board.put("pockets", pockets);

            double W = before.fieldW() > 0 ? before.fieldW() : 1;
            JSONObject exec = new JSONObject()
                .put("angle_deg", Math.round(shot.angleDeg * 100) / 100.0)
                .put("power", Math.round(shot.power * 1000) / 1000.0)
                .put("start_pos", pt(before, shot.startX, shot.startY))
                .put("end_pos", pt(before, shot.endX, shot.endY))
                .put("drag_len", Math.round(shot.dragLen / W * 1000) / 1000.0)
                .put("duration_ms", durationMs);

            JSONObject sim = new JSONObject()
                .put("potted", predIds).put("striker_potted", strikerPotted).put("score", predScore);

            boolean nextMe = after.striker() != null && after.hasField()
                && after.striker().y > (after.fieldT + after.fieldB) / 2.0;
            JSONObject actual = new JSONObject()
                .put("potted_mine", actualMine).put("potted_opp", actualOpp).put("potted_queen", actualQ)
                .put("detection_confidence", Math.round(conf * 1000) / 1000.0)
                .put("next_turn", nextMe ? "me" : "opponent");

            JSONObject shotJson = new JSONObject()
                .put("shot_id", UUID.randomUUID().toString())
                .put("board_hash", hasher.generateHash(before))
                .put("board_state", board)
                .put("shot_executed", exec)
                .put("simulation_predicted", sim)
                .put("actual_result", actual)
                .put("turn_info", new JSONObject().put("was_my_turn", true).put("votes", cfg.votesRequired))
                .put("tier", tier);
            shots.put(shotJson);
            if (shots.length() >= 10) flush();
        } catch (Throwable t) { Log.e("collector", t); }
    }

    /** Packs the collected shots into one match JSON and queues it for upload. */
    public void flush() {
        try {
            if (shots.length() == 0) return;
            JSONObject match = new JSONObject();
            match.put("match_id", matchId);
            match.put("game_version", cfg.gameVersion);
            match.put("device", new JSONObject()
                .put("resolution", cfg.screenW + "x" + cfg.screenH)
                .put("dpi", cfg.dpi)
                .put("android_version", Build.VERSION.SDK_INT));
            match.put("shots", shots);
            uploader.enqueue(match.toString());
            shots = new JSONArray();
            matchId = UUID.randomUUID().toString();
        } catch (Throwable t) { Log.e("flush", t); }
    }
}
