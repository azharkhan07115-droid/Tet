package com.carrombot.tool.data;

import java.util.ArrayList;
import java.util.List;

public class SimResult {
    public List<String> pottedIds = new ArrayList<>();
    public boolean strikerPotted;
    public boolean queenPotted;
    public double score;
    public double strikerEndX, strikerEndY;
    public List<Trajectory> trajectories = new ArrayList<>();
}
