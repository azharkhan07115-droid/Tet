package com.carrombot.tool;

import android.app.Activity;
import android.content.Intent;
import android.media.projection.MediaProjectionManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;
import com.carrombot.tool.service.OverlayService;
import com.carrombot.tool.util.PermissionHelper;

public class MainActivity extends Activity {

    private static final int REQ_OVERLAY = 100;
    private static final int REQ_PROJECTION = 101;

    private TextView tvOverlay, tvAcc, tvGame, tvDevice, tvRam, tvStatus, tvGameName, tvGameVersion;
    private com.carrombot.tool.ui.StorageRingView ring;
    private android.widget.ImageView ivGameIcon;
    private boolean ringShown = false;

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        setContentView(R.layout.activity_main);
        applyInsets();
        tvOverlay = findViewById(R.id.tv_overlay_status);
        tvAcc = findViewById(R.id.tv_acc_status);
        tvGame = findViewById(R.id.tv_game_status);
        tvDevice = findViewById(R.id.tv_device);
        tvRam = findViewById(R.id.tv_ram);
        tvStatus = findViewById(R.id.tv_status);
        tvGameName = findViewById(R.id.tv_game_name);
        tvGameVersion = findViewById(R.id.tv_game_version);
        ring = findViewById(R.id.ring_storage);
        ivGameIcon = findViewById(R.id.iv_game_icon);

        findViewById(R.id.btn_overlay).setOnClickListener(v -> {
            if (!PermissionHelper.hasOverlay(this))
                startActivityForResult(PermissionHelper.overlayIntent(this), REQ_OVERLAY);
            else Toast.makeText(this, "Already granted", Toast.LENGTH_SHORT).show();
        });

        findViewById(R.id.btn_accessibility).setOnClickListener(v -> {
            startActivity(PermissionHelper.accessibilityIntent());
            Toast.makeText(this, "Enable Carrom Bot in Accessibility", Toast.LENGTH_LONG).show();
        });

        findViewById(R.id.btn_play).setOnClickListener(v -> launchGame());
        findViewById(R.id.fab_settings).setOnClickListener(v -> showSettings());
        findViewById(R.id.btn_start).setOnClickListener(v -> requestProjection());
        updateUI();
        if (Build.VERSION.SDK_INT >= 33) {
            requestPermissions(new String[]{"android.permission.POST_NOTIFICATIONS"}, 7);
        }
        showLastCrash();
    }

    /** Android 15+ draws apps edge-to-edge: keep the content below the status bar / above the nav bar. */
    private void applyInsets() {
        try {
            final android.view.View root = findViewById(android.R.id.content);
            root.setOnApplyWindowInsetsListener((v, insets) -> {
                int l, t, r, b;
                if (Build.VERSION.SDK_INT >= 30) {
                    android.graphics.Insets i = insets.getInsets(
                        android.view.WindowInsets.Type.systemBars() | android.view.WindowInsets.Type.displayCutout());
                    l = i.left; t = i.top; r = i.right; b = i.bottom;
                } else {
                    l = insets.getSystemWindowInsetLeft(); t = insets.getSystemWindowInsetTop();
                    r = insets.getSystemWindowInsetRight(); b = insets.getSystemWindowInsetBottom();
                }
                v.setPadding(l, t, r, b);
                return insets;
            });
            root.requestApplyInsets();
        } catch (Throwable ignored) {}
    }

    private void showLastCrash() {
        try {
            android.content.SharedPreferences sp =
                getSharedPreferences(com.carrombot.tool.util.Constants.PREFS, MODE_PRIVATE);
            String crash = sp.getString("last_crash", null);
            if (crash == null) return;
            sp.edit().remove("last_crash").commit();
            TextView tv = new TextView(this);
            tv.setText(crash);
            tv.setTextIsSelectable(true);
            tv.setTextSize(11);
            tv.setTextColor(0xFFFFFFFF);
            tv.setPadding(32, 32, 32, 32);
            android.widget.ScrollView sv = new android.widget.ScrollView(this);
            sv.addView(tv);
            new android.app.AlertDialog.Builder(this,
                    android.R.style.Theme_DeviceDefault_Dialog_Alert)
                .setTitle("Last crash (screenshot bhejo)")
                .setView(sv)
                .setPositiveButton("OK", null)
                .show();
        } catch (Throwable ignored) {}
    }

    private void launchGame() {
        if (!PermissionHelper.isGameInstalled(this)) {
            Toast.makeText(this, "Carrom Pool not installed. Opening Play Store...",
                Toast.LENGTH_LONG).show();
            try {
                startActivity(new Intent(Intent.ACTION_VIEW,
                    Uri.parse("market://details?id=com.miniclip.carrom")));
            } catch (Throwable t) {
                startActivity(new Intent(Intent.ACTION_VIEW,
                    Uri.parse("https://play.google.com/store/apps/details?id=com.miniclip.carrom")));
            }
            return;
        }
        Intent i = PermissionHelper.launchGame(this);
        startActivity(i);
    }

    private void requestProjection() {
        if (!PermissionHelper.hasOverlay(this)) {
            Toast.makeText(this, "Grant overlay first", Toast.LENGTH_SHORT).show();
            return;
        }
        MediaProjectionManager mpm = (MediaProjectionManager)
            getSystemService(MEDIA_PROJECTION_SERVICE);
        startActivityForResult(mpm.createScreenCaptureIntent(), REQ_PROJECTION);
    }

    @Override protected void onActivityResult(int req, int res, Intent data) {
        super.onActivityResult(req, res, data);
        if (req == REQ_OVERLAY) updateUI();
        else if (req == REQ_PROJECTION && res == RESULT_OK && data != null) {
            Intent svc = new Intent(this, OverlayService.class);
            svc.putExtra("resultCode", res);
            svc.putExtra("data", data);
            try {
                if (Build.VERSION.SDK_INT >= 26) startForegroundService(svc);
                else startService(svc);
                Toast.makeText(this, "Floating menu started", Toast.LENGTH_SHORT).show();
            } catch (Throwable t) {
                Toast.makeText(this, "Service start fail: " + t, Toast.LENGTH_LONG).show();
            }
        }
    }

    private void updateUI() {
        boolean ov = PermissionHelper.hasOverlay(this);
        boolean ac = PermissionHelper.isAccessibilityEnabled(this);
        boolean gm = PermissionHelper.isGameInstalled(this);
        tvOverlay.setText(ov ? "✓" : "✗");
        tvOverlay.setTextColor(ov ? 0xFF00E676 : 0xFFFF3355);
        tvAcc.setText(ac ? "✓" : "✗");
        tvAcc.setTextColor(ac ? 0xFF00E676 : 0xFFFF3355);
        tvGame.setText(gm ? "✓" : "✗");
        tvGame.setTextColor(gm ? 0xFF2BD67B : 0xFFE5484D);
        tvOverlay.setTextColor(ov ? 0xFF2BD67B : 0xFFE5484D);
        tvAcc.setTextColor(ac ? 0xFF2BD67B : 0xFFE5484D);

        // ---- dashboard cards (real device data) ----
        tvDevice.setText("Android " + Build.VERSION.RELEASE);
        try {
            android.app.ActivityManager am = (android.app.ActivityManager) getSystemService(ACTIVITY_SERVICE);
            android.app.ActivityManager.MemoryInfo mi = new android.app.ActivityManager.MemoryInfo();
            am.getMemoryInfo(mi);
            tvRam.setText(String.format(java.util.Locale.US, "%.2f GB", mi.totalMem / 1073741824.0));
        } catch (Throwable t) { tvRam.setText("-"); }
        tvStatus.setText(ov && ac ? "Ready" : "Setup needed");
        tvStatus.setTextColor(ov && ac ? 0xFF2BD67B : 0xFFE5484D);
        try {
            android.os.StatFs sf = new android.os.StatFs(android.os.Environment.getDataDirectory().getPath());
            double total = sf.getTotalBytes() / 1e9, free = sf.getAvailableBytes() / 1e9, used = total - free;
            if (!ringShown) { ring.setData((int) Math.round(used / total * 100.0), (float) used, (float) total); ringShown = true; }
        } catch (Throwable ignored) {}
        try {
            android.content.pm.PackageInfo pi = getPackageManager().getPackageInfo(
                com.carrombot.tool.util.Constants.TARGET_PACKAGE, 0);
            tvGameVersion.setText(pi.versionName != null ? pi.versionName : "installed");
            ivGameIcon.setImageDrawable(getPackageManager().getApplicationIcon(
                com.carrombot.tool.util.Constants.TARGET_PACKAGE));
        } catch (Throwable t) { tvGameVersion.setText("not installed"); }
    }

    /** Settings dialog (sparkle button): how the shot lines look. */
    private void showSettings() {
        final String[] names = {"Default lines (classic)", "Custom - Glow", "Custom - Simple", "Custom - Dark"};
        String style = com.carrombot.tool.util.Prefs.getString(com.carrombot.tool.util.Constants.PREF_LINE_STYLE, "DEFAULT");
        String sub = com.carrombot.tool.util.Prefs.getString(com.carrombot.tool.util.Constants.PREF_LINE_SUB, "GLOW");
        int checked = "DEFAULT".equals(style) ? 0 : "SIMPLE".equals(sub) ? 2 : "DARK".equals(sub) ? 3 : 1;
        new android.app.AlertDialog.Builder(this, android.R.style.Theme_DeviceDefault_Dialog_Alert)
            .setTitle("Shot line style")
            .setSingleChoiceItems(names, checked, (d, which) -> {
                com.carrombot.tool.util.Prefs.putString(com.carrombot.tool.util.Constants.PREF_LINE_STYLE,
                    which == 0 ? "DEFAULT" : "CUSTOM");
                if (which > 0)
                    com.carrombot.tool.util.Prefs.putString(com.carrombot.tool.util.Constants.PREF_LINE_SUB,
                        which == 1 ? "GLOW" : which == 2 ? "SIMPLE" : "DARK");
                d.dismiss();
            })
            .setNegativeButton("Close", null)
            .show();
    }

    @Override protected void onResume() { super.onResume(); updateUI(); }
}
