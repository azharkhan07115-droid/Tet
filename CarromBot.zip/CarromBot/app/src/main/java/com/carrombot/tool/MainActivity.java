package com.carrombot.tool;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.media.projection.MediaProjectionManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.text.InputType;
import android.view.View;
import android.view.WindowInsets;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import com.carrombot.tool.auth.LicenseManager;
import com.carrombot.tool.service.OverlayService;
import com.carrombot.tool.ui.StorageRingView;
import com.carrombot.tool.util.Constants;
import com.carrombot.tool.util.PermissionHelper;

/**
 * VORZEX ENGINE dashboard.  Flow: press PLAY -> license key (asked once, saved) -> server verifies ->
 * permissions -> floating menu starts -> the game opens. Nothing starts without a verified key.
 */
public class MainActivity extends Activity {

    private static final int REQ_OVERLAY = 100;
    private static final int REQ_PROJECTION = 101;
    private static final int REQ_NOTIF = 102;

    private TextView tvOverlay, tvAcc, tvGame, tvDevice, tvRam, tvStatus, tvGameVersion, tvLicDot, tvLic;
    private StorageRingView ring;
    private android.widget.ImageView ivGameIcon;
    private boolean ringShown = false;
    private boolean continueAfterOverlay = false;
    private AlertDialog busy;

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        setContentView(R.layout.activity_main);
        applyInsets();
        tvOverlay = findViewById(R.id.tv_overlay_status);
        tvAcc = findViewById(R.id.tv_acc_status);
        tvGame = findViewById(R.id.tv_game_status);
        tvDevice = findViewById(R.id.tv_device);
        tvRam = findViewById(R.id.tv_ram);
        tvStatus = findViewById(R.id.tv_status);
        tvGameVersion = findViewById(R.id.tv_game_version);
        tvLicDot = findViewById(R.id.tv_license_dot);
        tvLic = findViewById(R.id.tv_license_status);
        ring = findViewById(R.id.ring_storage);
        ivGameIcon = findViewById(R.id.iv_game_icon);

        findViewById(R.id.btn_overlay).setOnClickListener(v -> {
            if (!PermissionHelper.hasOverlay(this))
                startActivityForResult(PermissionHelper.overlayIntent(this), REQ_OVERLAY);
            else Toast.makeText(this, "Already granted", Toast.LENGTH_SHORT).show();
        });
        findViewById(R.id.btn_accessibility).setOnClickListener(v -> {
            startActivity(PermissionHelper.accessibilityIntent());
            Toast.makeText(this, "Enable VORZEX ENGINE in Accessibility", Toast.LENGTH_LONG).show();
        });
        findViewById(R.id.btn_play).setOnClickListener(v -> onPlay());

        showLastCrash();
        updateUI();
    }

    @Override protected void onResume() { super.onResume(); updateUI(); }

    // =============================================================================================
    //  PLAY -> license -> permissions -> floating menu -> game
    // =============================================================================================
    private void onPlay() {
        if (LicenseManager.isUnlocked()) { afterLicense(); return; }
        String saved = LicenseManager.savedKey();
        if (!saved.isEmpty()) verifyKey(saved, null);     // verified silently with the saved key
        else askKey(null);
    }

    private void verifyKey(final String key, final String ignored) {
        showBusy("Verifying license...");
        LicenseManager.verify(this, key, (ok, msg) -> {
            hideBusy();
            updateUI();
            if (ok) { Toast.makeText(this, msg, Toast.LENGTH_SHORT).show(); afterLicense(); }
            else askKey(msg);
        });
    }

    private void askKey(String error) {
        float d = getResources().getDisplayMetrics().density;
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding((int) (22 * d), (int) (10 * d), (int) (22 * d), (int) (4 * d));
        final EditText et = new EditText(this);
        et.setHint("XXXX-XXXX-XXXX-XXXX");
        et.setHintTextColor(0xFF5E7568);
        et.setTextColor(0xFFEAF2ED);
        et.setSingleLine(true);
        et.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS | InputType.TYPE_TEXT_FLAG_CAP_CHARACTERS);
        String saved = LicenseManager.savedKey();
        if (!saved.isEmpty()) et.setText(saved);
        box.addView(et);
        if (error != null) {
            TextView err = new TextView(this);
            err.setText(error); err.setTextColor(0xFFE5484D); err.setTextSize(12);
            err.setPadding(0, (int) (8 * d), 0, 0);
            box.addView(err);
        }
        new AlertDialog.Builder(this, android.R.style.Theme_DeviceDefault_Dialog_Alert)
            .setTitle("VORZEX ENGINE - license key")
            .setMessage("Enter your license key to continue.")
            .setView(box)
            .setPositiveButton("Activate", (dlg, w) -> {
                String k = et.getText().toString().trim();
                if (k.isEmpty()) { askKey("Enter your key first."); return; }
                verifyKey(k, null);
            })
            .setNegativeButton("Cancel", null)
            .show();
    }

    private void showBusy(String msg) {
        hideBusy();
        busy = new AlertDialog.Builder(this, android.R.style.Theme_DeviceDefault_Dialog_Alert)
            .setMessage(msg).setCancelable(false).create();
        busy.show();
    }
    private void hideBusy() { try { if (busy != null) busy.dismiss(); } catch (Throwable ignored) {} busy = null; }

    private void afterLicense() {
        if (!LicenseManager.isUnlocked()) { askKey("Session expired. Enter your key again."); return; }
        if (!PermissionHelper.hasOverlay(this)) {
            continueAfterOverlay = true;
            Toast.makeText(this, "Allow 'Display over other apps' for VORZEX ENGINE", Toast.LENGTH_LONG).show();
            startActivityForResult(PermissionHelper.overlayIntent(this), REQ_OVERLAY);
            return;
        }
        if (Build.VERSION.SDK_INT >= 33
            && checkSelfPermission(android.Manifest.permission.POST_NOTIFICATIONS) != android.content.pm.PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{android.Manifest.permission.POST_NOTIFICATIONS}, REQ_NOTIF);
            return;
        }
        continueAfterNotif();
    }

    @Override public void onRequestPermissionsResult(int req, String[] perms, int[] res) {
        super.onRequestPermissionsResult(req, perms, res);
        if (req == REQ_NOTIF) continueAfterNotif();       // notifications are optional - go on either way
    }

    private void continueAfterNotif() {
        if (!PermissionHelper.isAccessibilityEnabled(this))
            Toast.makeText(this, "Auto play needs the VORZEX ENGINE accessibility service (aim assist works without it)", Toast.LENGTH_LONG).show();
        MediaProjectionManager mpm = (MediaProjectionManager) getSystemService(MEDIA_PROJECTION_SERVICE);
        startActivityForResult(mpm.createScreenCaptureIntent(), REQ_PROJECTION);
    }

    @Override protected void onActivityResult(int req, int res, Intent data) {
        super.onActivityResult(req, res, data);
        if (req == REQ_OVERLAY) {
            updateUI();
            if (continueAfterOverlay && PermissionHelper.hasOverlay(this)) { continueAfterOverlay = false; afterLicense(); }
        } else if (req == REQ_PROJECTION) {
            if (res == RESULT_OK && data != null && LicenseManager.isUnlocked()) startEverything(res, data);
            else Toast.makeText(this, "Screen capture permission is needed", Toast.LENGTH_LONG).show();
        }
    }

    private void startEverything(int res, Intent data) {
        Intent svc = new Intent(this, OverlayService.class);
        svc.putExtra("resultCode", res);
        svc.putExtra("data", data);
        try {
            if (Build.VERSION.SDK_INT >= 26) startForegroundService(svc); else startService(svc);
        } catch (Throwable t) {
            Toast.makeText(this, "Service start failed: " + t, Toast.LENGTH_LONG).show();
            return;
        }
        // the floating menu is up -> open the game
        getWindow().getDecorView().postDelayed(this::launchGame, 450);
    }

    private void launchGame() {
        if (!PermissionHelper.isGameInstalled(this)) {
            Toast.makeText(this, "Carrom Pool is not installed. Opening Play Store...", Toast.LENGTH_LONG).show();
            try { startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("market://details?id=com.miniclip.carrom"))); }
            catch (Throwable t) { startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("https://play.google.com/store/apps/details?id=com.miniclip.carrom"))); }
            return;
        }
        startActivity(PermissionHelper.launchGame(this));
    }

    // =============================================================================================
    //  dashboard data
    // =============================================================================================
    private void updateUI() {
        boolean ov = PermissionHelper.hasOverlay(this);
        boolean ac = PermissionHelper.isAccessibilityEnabled(this);
        boolean gm = PermissionHelper.isGameInstalled(this);
        boolean lic = LicenseManager.isUnlocked();
        setTick(tvOverlay, ov); setTick(tvAcc, ac); setTick(tvGame, gm); setTick(tvLicDot, lic);
        tvLic.setText(lic ? "License: " + (LicenseManager.daysLeft() > 0 ? LicenseManager.daysLeft() + " days left" : "active")
            : (LicenseManager.savedKey().isEmpty() ? "License: not activated" : "License: press play to verify"));

        tvDevice.setText("Android " + Build.VERSION.RELEASE);
        try {
            android.app.ActivityManager am = (android.app.ActivityManager) getSystemService(ACTIVITY_SERVICE);
            android.app.ActivityManager.MemoryInfo mi = new android.app.ActivityManager.MemoryInfo();
            am.getMemoryInfo(mi);
            tvRam.setText(String.format(java.util.Locale.US, "%.2f GB", mi.totalMem / 1073741824.0));
        } catch (Throwable t) { tvRam.setText("-"); }
        tvStatus.setText(!lic ? "License needed" : (ov ? "Ready" : "Setup needed"));
        tvStatus.setTextColor(lic && ov ? 0xFF2BD67B : 0xFFE5484D);
        try {
            android.os.StatFs sf = new android.os.StatFs(android.os.Environment.getDataDirectory().getPath());
            double total = sf.getTotalBytes() / 1e9, free = sf.getAvailableBytes() / 1e9, used = total - free;
            if (!ringShown) { ring.setData((int) Math.round(used / total * 100.0), (float) used, (float) total); ringShown = true; }
        } catch (Throwable ignored) {}
        try {
            android.content.pm.PackageInfo pi = getPackageManager().getPackageInfo(Constants.TARGET_PACKAGE, 0);
            tvGameVersion.setText(pi.versionName != null ? pi.versionName : "installed");
            ivGameIcon.setImageDrawable(getPackageManager().getApplicationIcon(Constants.TARGET_PACKAGE));
        } catch (Throwable t) { tvGameVersion.setText("not installed"); }
    }

    private void setTick(TextView tv, boolean ok) {
        tv.setText(ok ? "✓" : "✗");
        tv.setTextColor(ok ? 0xFF2BD67B : 0xFFE5484D);
    }

    /** Android 15+ draws apps edge-to-edge: keep the content below the status bar / above the nav bar. */
    private void applyInsets() {
        try {
            final View root = findViewById(android.R.id.content);
            root.setOnApplyWindowInsetsListener((v, insets) -> {
                int l, t, r, b;
                if (Build.VERSION.SDK_INT >= 30) {
                    android.graphics.Insets i = insets.getInsets(WindowInsets.Type.systemBars() | WindowInsets.Type.displayCutout());
                    l = i.left; t = i.top; r = i.right; b = i.bottom;
                } else {
                    l = insets.getSystemWindowInsetLeft(); t = insets.getSystemWindowInsetTop();
                    r = insets.getSystemWindowInsetRight(); b = insets.getSystemWindowInsetBottom();
                }
                v.setPadding(l, t, r, b);
                return insets;
            });
            root.requestApplyInsets();
        } catch (Throwable ignored) {}
    }

    private void showLastCrash() {
        try {
            android.content.SharedPreferences sp = getSharedPreferences(Constants.PREFS, MODE_PRIVATE);
            String crash = sp.getString("last_crash", null);
            if (crash == null) return;
            sp.edit().remove("last_crash").commit();
            TextView tv = new TextView(this);
            tv.setText(crash); tv.setTextIsSelectable(true); tv.setTextSize(11);
            tv.setTextColor(0xFFFFFFFF); tv.setPadding(32, 32, 32, 32);
            android.widget.ScrollView sv = new android.widget.ScrollView(this);
            sv.addView(tv);
            new AlertDialog.Builder(this, android.R.style.Theme_DeviceDefault_Dialog_Alert)
                .setTitle("Last crash (send a screenshot)").setView(sv).setPositiveButton("OK", null).show();
        } catch (Throwable ignored) {}
    }
}
