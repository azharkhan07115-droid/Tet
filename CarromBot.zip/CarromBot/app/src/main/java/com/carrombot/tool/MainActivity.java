package com.carrombot.tool;

import android.app.Activity;
import android.content.Intent;
import android.media.projection.MediaProjectionManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;
import com.carrombot.tool.service.OverlayService;
import com.carrombot.tool.util.PermissionHelper;

public class MainActivity extends Activity {

    private static final int REQ_OVERLAY = 100;
    private static final int REQ_PROJECTION = 101;

    private TextView tvOverlay, tvAcc, tvGame;

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        setContentView(R.layout.activity_main);
        tvOverlay = findViewById(R.id.tv_overlay_status);
        tvAcc = findViewById(R.id.tv_acc_status);
        tvGame = findViewById(R.id.tv_game_status);

        findViewById(R.id.btn_overlay).setOnClickListener(v -> {
            if (!PermissionHelper.hasOverlay(this))
                startActivityForResult(PermissionHelper.overlayIntent(this), REQ_OVERLAY);
            else Toast.makeText(this, "Already granted", Toast.LENGTH_SHORT).show();
        });

        findViewById(R.id.btn_accessibility).setOnClickListener(v -> {
            startActivity(PermissionHelper.accessibilityIntent());
            Toast.makeText(this, "Enable Carrom Bot in Accessibility", Toast.LENGTH_LONG).show();
        });

        findViewById(R.id.btn_launch).setOnClickListener(v -> launchGame());
        findViewById(R.id.btn_start).setOnClickListener(v -> requestProjection());
        updateUI();
        if (Build.VERSION.SDK_INT >= 33) {
            requestPermissions(new String[]{"android.permission.POST_NOTIFICATIONS"}, 7);
        }
        showLastCrash();
    }

    private void showLastCrash() {
        try {
            android.content.SharedPreferences sp =
                getSharedPreferences(com.carrombot.tool.util.Constants.PREFS, MODE_PRIVATE);
            String crash = sp.getString("last_crash", null);
            if (crash == null) return;
            sp.edit().remove("last_crash").commit();
            TextView tv = new TextView(this);
            tv.setText(crash);
            tv.setTextIsSelectable(true);
            tv.setTextSize(11);
            tv.setTextColor(0xFFFFFFFF);
            tv.setPadding(32, 32, 32, 32);
            android.widget.ScrollView sv = new android.widget.ScrollView(this);
            sv.addView(tv);
            new android.app.AlertDialog.Builder(this,
                    android.R.style.Theme_DeviceDefault_Dialog_Alert)
                .setTitle("Last crash (screenshot bhejo)")
                .setView(sv)
                .setPositiveButton("OK", null)
                .show();
        } catch (Throwable ignored) {}
    }

    private void launchGame() {
        if (!PermissionHelper.isGameInstalled(this)) {
            Toast.makeText(this, "Carrom Pool not installed. Opening Play Store...",
                Toast.LENGTH_LONG).show();
            try {
                startActivity(new Intent(Intent.ACTION_VIEW,
                    Uri.parse("market://details?id=com.miniclip.carrom")));
            } catch (Throwable t) {
                startActivity(new Intent(Intent.ACTION_VIEW,
                    Uri.parse("https://play.google.com/store/apps/details?id=com.miniclip.carrom")));
            }
            return;
        }
        Intent i = PermissionHelper.launchGame(this);
        startActivity(i);
    }

    private void requestProjection() {
        if (!PermissionHelper.hasOverlay(this)) {
            Toast.makeText(this, "Grant overlay first", Toast.LENGTH_SHORT).show();
            return;
        }
        MediaProjectionManager mpm = (MediaProjectionManager)
            getSystemService(MEDIA_PROJECTION_SERVICE);
        startActivityForResult(mpm.createScreenCaptureIntent(), REQ_PROJECTION);
    }

    @Override protected void onActivityResult(int req, int res, Intent data) {
        super.onActivityResult(req, res, data);
        if (req == REQ_OVERLAY) updateUI();
        else if (req == REQ_PROJECTION && res == RESULT_OK && data != null) {
            Intent svc = new Intent(this, OverlayService.class);
            svc.putExtra("resultCode", res);
            svc.putExtra("data", data);
            try {
                if (Build.VERSION.SDK_INT >= 26) startForegroundService(svc);
                else startService(svc);
                Toast.makeText(this, "Floating menu started", Toast.LENGTH_SHORT).show();
            } catch (Throwable t) {
                Toast.makeText(this, "Service start fail: " + t, Toast.LENGTH_LONG).show();
            }
        }
    }

    private void updateUI() {
        boolean ov = PermissionHelper.hasOverlay(this);
        boolean ac = PermissionHelper.isAccessibilityEnabled(this);
        boolean gm = PermissionHelper.isGameInstalled(this);
        tvOverlay.setText(ov ? "✓" : "✗");
        tvOverlay.setTextColor(ov ? 0xFF00E676 : 0xFFFF3355);
        tvAcc.setText(ac ? "✓" : "✗");
        tvAcc.setTextColor(ac ? 0xFF00E676 : 0xFFFF3355);
        tvGame.setText(gm ? "✓" : "✗");
        tvGame.setTextColor(gm ? 0xFF00E676 : 0xFFFF3355);
    }

    @Override protected void onResume() { super.onResume(); updateUI(); }
}
