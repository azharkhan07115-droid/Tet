package com.carrombot.tool.ui;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.DashPathEffect;
import android.graphics.Paint;
import android.graphics.Path;
import android.view.View;
import com.carrombot.tool.data.Trajectory;

import java.util.ArrayList;
import java.util.List;

public class TrajectoryOverlay extends View {
    private final Paint sp = new Paint();
    private final Paint pp = new Paint();
    private final Paint qp = new Paint();
    private final Paint potP = new Paint();
    private List<Trajectory> trajs = new ArrayList<>();
    private List<double[]> pots = new ArrayList<>();

    public TrajectoryOverlay(Context c) {
        super(c);
        setLayerType(LAYER_TYPE_HARDWARE, null);
        sp.setColor(0xFF00E5FF); sp.setStyle(Paint.Style.STROKE);
        sp.setStrokeWidth(3f); sp.setAntiAlias(true);
        sp.setShadowLayer(8, 0, 0, 0x6600E5FF);
        pp.setColor(0xFFFFD700); pp.setStyle(Paint.Style.STROKE);
        pp.setStrokeWidth(2.5f); pp.setAntiAlias(true);
        pp.setPathEffect(new DashPathEffect(new float[]{15, 8}, 0));
        qp.setColor(0xFFFF3355); qp.setStyle(Paint.Style.STROKE);
        qp.setStrokeWidth(3f); qp.setAntiAlias(true);
        potP.setColor(0x6600E676); potP.setStyle(Paint.Style.FILL);
        potP.setAntiAlias(true);
    }

    public void set(List<Trajectory> t, List<double[]> p) {
        trajs = t != null ? t : new ArrayList<>();
        pots = p != null ? p : new ArrayList<>();
        invalidate();
    }
    public void clear() { trajs.clear(); pots.clear(); invalidate(); }

    @Override protected void onDraw(Canvas c) {
        super.onDraw(c);
        for (Trajectory t : trajs) {
            if (t.points.isEmpty()) continue;
            Path path = new Path();
            double[] p0 = t.points.get(0);
            path.moveTo((float)p0[0], (float)p0[1]);
            for (int i = 1; i < t.points.size(); i++) {
                double[] p = t.points.get(i);
                path.lineTo((float)p[0], (float)p[1]);
            }
            Paint paint = t.type == Trajectory.Type.STRIKER ? sp
                : t.type == Trajectory.Type.QUEEN ? qp : pp;
            c.drawPath(path, paint);
            if (t.points.size() > 1) drawArrow(c, t, paint);
        }
        for (double[] pot : pots) {
            c.drawCircle((float)pot[0], (float)pot[1], 40, potP);
            c.drawCircle((float)pot[0], (float)pot[1], 25, potP);
        }
    }

    private void drawArrow(Canvas c, Trajectory t, Paint p) {
        double[] last = t.points.get(t.points.size()-1);
        double[] prev = t.points.get(t.points.size()-2);
        double a = Math.atan2(last[1]-prev[1], last[0]-prev[0]);
        float sz = 15f;
        double p1x = last[0] - sz*Math.cos(a - Math.PI/6);
        double p1y = last[1] - sz*Math.sin(a - Math.PI/6);
        double p2x = last[0] - sz*Math.cos(a + Math.PI/6);
        double p2y = last[1] - sz*Math.sin(a + Math.PI/6);
        Path ap = new Path();
        ap.moveTo((float)last[0], (float)last[1]);
        ap.lineTo((float)p1x, (float)p1y);
        ap.lineTo((float)p2x, (float)p2y);
        ap.close();
        c.drawPath(ap, p);
    }
}
