package com.carrombot.tool.ui;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.view.View;
import com.carrombot.tool.data.Trajectory;

import java.util.ArrayList;
import java.util.List;

/**
 * Prediction overlay: thin multi-bounce polyline per moving piece + a coloured dot
 * where that piece ends up (pocket for potted pieces). Same look as the reference video.
 */
public class TrajectoryOverlay extends View {
    private static final int[] PALETTE = {
        0xFFB06BFF, 0xFF4FE07A, 0xFF7FB2FF, 0xFF5CE1C6, 0xFFE08CFF, 0xFFB8F26B};
    private List<Trajectory> trajs = new ArrayList<>();
    private List<double[]> pots = new ArrayList<>();
    private double[] hint = null;   // where the striker should stand (aim assistant)
    private final Paint line = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint dot = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint ring = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Path path = new Path();

    public TrajectoryOverlay(Context c) {
        super(c);
        float d = c.getResources().getDisplayMetrics().density;
        line.setStyle(Paint.Style.STROKE);
        line.setStrokeWidth(Math.max(2f, 1.3f * d));
        line.setStrokeJoin(Paint.Join.ROUND);
        line.setStrokeCap(Paint.Cap.ROUND);
        dot.setStyle(Paint.Style.FILL);
        ring.setStyle(Paint.Style.STROKE);
        ring.setStrokeWidth(Math.max(2f, 1.5f * d));
        ring.setColor(0xFF4FE07A);
    }

    public void set(List<Trajectory> t, List<double[]> p, double[] h) {
        trajs = t != null ? t : new ArrayList<Trajectory>();
        pots = p != null ? p : new ArrayList<double[]>();
        hint = h;
        invalidate();
    }

    public void clear() { trajs = new ArrayList<>(); pots = new ArrayList<>(); hint = null; }

    @Override protected void onDraw(Canvas c) {
        int i = 0;
        for (Trajectory t : trajs) {
            if (t.points.size() < 2) continue;
            int col = t.type == Trajectory.Type.STRIKER ? 0xFF2EC4E6 : PALETTE[(i++) % PALETTE.length];
            path.reset();
            boolean first = true;
            for (double[] p : t.points) {
                if (first) { path.moveTo((float) p[0], (float) p[1]); first = false; }
                else path.lineTo((float) p[0], (float) p[1]);
            }
            line.setColor((col & 0x00FFFFFF) | 0xB0000000);
            c.drawPath(path, line);
            float r = (float) Math.max(t.r, 10);
            dot.setColor((col & 0x00FFFFFF) | 0xE0000000);
            c.drawCircle((float) t.endX, (float) t.endY, r, dot);
            if (t.potted) c.drawCircle((float) t.potX, (float) t.potY, r * 1.4f, ring);
        }
        if (hint != null) c.drawCircle((float) hint[0], (float) hint[1], 0.045f * c.getWidth(), ring);
    }
}
