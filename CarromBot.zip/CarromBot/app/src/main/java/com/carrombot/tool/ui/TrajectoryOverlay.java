package com.carrombot.tool.ui;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.view.View;
import com.carrombot.tool.data.Trajectory;
import com.carrombot.tool.util.Constants;
import com.carrombot.tool.util.Prefs;

import java.util.ArrayList;
import java.util.List;

/**
 * Prediction overlay: thin multi-bounce polyline per moving piece + a coloured dot
 * where that piece ends up (pocket for potted pieces). Same look as the reference video.
 */
public class TrajectoryOverlay extends View {
    private static final int[] PALETTE = {
        0xFFB06BFF, 0xFF4FE07A, 0xFF7FB2FF, 0xFF5CE1C6, 0xFFE08CFF, 0xFFB8F26B};
    private List<Trajectory> trajs = new ArrayList<>();
    private List<double[]> pots = new ArrayList<>();
    private double[] hint = null;   // where the striker should stand (aim assistant)
    private final Paint line = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint dot = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint ring = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Path path = new Path();

    public TrajectoryOverlay(Context c) {
        super(c);
        float d = c.getResources().getDisplayMetrics().density;
        line.setStyle(Paint.Style.STROKE);
        line.setStrokeWidth(Math.max(2f, 1.3f * d));
        line.setStrokeJoin(Paint.Join.ROUND);
        line.setStrokeCap(Paint.Cap.ROUND);
        dot.setStyle(Paint.Style.FILL);
        ring.setStyle(Paint.Style.STROKE);
        ring.setStrokeWidth(Math.max(2f, 1.5f * d));
        ring.setColor(0xFF4FE07A);
    }

    public void set(List<Trajectory> t, List<double[]> p, double[] h) {
        trajs = t != null ? t : new ArrayList<Trajectory>();
        pots = p != null ? p : new ArrayList<double[]>();
        hint = h;
        invalidate();
    }

    public void clear() { trajs = new ArrayList<>(); pots = new ArrayList<>(); hint = null; }

    @Override protected void onDraw(Canvas c) {
        String style = "DEFAULT", sub = "GLOW";
        try {
            style = Prefs.getString(Constants.PREF_LINE_STYLE, "DEFAULT");
            sub = Prefs.getString(Constants.PREF_LINE_SUB, "GLOW");
        } catch (Throwable ignored) {}
        if ("CUSTOM".equals(style)) { drawCustom(c, sub); return; }
        int i = 0;
        for (Trajectory t : trajs) {
            if (t.points.size() < 2) continue;
            int col = t.type == Trajectory.Type.STRIKER ? 0xFF2EC4E6 : PALETTE[(i++) % PALETTE.length];
            path.reset();
            boolean first = true;
            for (double[] p : t.points) {
                if (first) { path.moveTo((float) p[0], (float) p[1]); first = false; }
                else path.lineTo((float) p[0], (float) p[1]);
            }
            line.setColor((col & 0x00FFFFFF) | 0xB0000000);
            c.drawPath(path, line);
            float r = (float) Math.max(t.r, 10);
            dot.setColor((col & 0x00FFFFFF) | 0xE0000000);
            c.drawCircle((float) t.endX, (float) t.endY, r, dot);
            if (t.potted) c.drawCircle((float) t.potX, (float) t.potY, r * 1.4f, ring);
        }
        if (hint != null) c.drawCircle((float) hint[0], (float) hint[1], 0.045f * c.getWidth(), ring);
    }

    // ------------------------------------------------------------------------------------
    //  CUSTOM look (dark green / red theme). GLOW = neon glow, SIMPLE = thin clean line, DARK = dark outline.
    //  green  = the striker's path          mint = my (black) piece          red = a white / red piece moves
    // ------------------------------------------------------------------------------------
    private static final int GREEN = 0xFF2BD67B, MINT = 0xFF8CFFC0, RED = 0xFFE5484D;

    private void drawCustom(Canvas c, String sub) {
        float d = getResources().getDisplayMetrics().density;
        for (Trajectory t : trajs) {
            if (t.points.size() < 2) continue;
            int col = t.type == Trajectory.Type.STRIKER ? GREEN
                : t.type == Trajectory.Type.PUCK ? MINT : RED;
            path.reset();
            boolean first = true;
            for (double[] p : t.points) {
                if (first) { path.moveTo((float) p[0], (float) p[1]); first = false; }
                else path.lineTo((float) p[0], (float) p[1]);
            }
            float r = (float) Math.max(t.r, 10);
            line.setStyle(Paint.Style.STROKE);
            if ("SIMPLE".equals(sub)) {
                line.setStrokeWidth(1.3f * d); line.setColor(withAlpha(col, 0xD0));
                c.drawPath(path, line);
                dot.setColor(withAlpha(col, 0xE6));
                c.drawCircle((float) t.endX, (float) t.endY, r * 0.45f, dot);
                if (t.potted) { ring.setColor(col); c.drawCircle((float) t.potX, (float) t.potY, r * 1.2f, ring); }
            } else if ("DARK".equals(sub)) {
                line.setStrokeWidth(4.2f * d); line.setColor(0xB0000000);
                c.drawPath(path, line);
                line.setStrokeWidth(1.8f * d); line.setColor(col);
                c.drawPath(path, line);
                dot.setColor(0xB0000000);
                c.drawCircle((float) t.endX, (float) t.endY, r, dot);
                ring.setColor(col); c.drawCircle((float) t.endX, (float) t.endY, r, ring);
                if (t.potted) c.drawCircle((float) t.potX, (float) t.potY, r * 1.4f, ring);
            } else {   // GLOW
                line.setStrokeWidth(9f * d);  line.setColor(withAlpha(col, 0x1C)); c.drawPath(path, line);
                line.setStrokeWidth(5.5f * d); line.setColor(withAlpha(col, 0x45)); c.drawPath(path, line);
                line.setStrokeWidth(1.7f * d); line.setColor(col);                 c.drawPath(path, line);
                dot.setColor(withAlpha(col, 0x30));
                c.drawCircle((float) t.endX, (float) t.endY, r * 1.35f, dot);
                dot.setColor(withAlpha(col, 0x70));
                c.drawCircle((float) t.endX, (float) t.endY, r * 0.9f, dot);
                ring.setColor(col); c.drawCircle((float) t.endX, (float) t.endY, r * 0.9f, ring);
                if (t.potted) { ring.setColor(0xFFFFFFFF); c.drawCircle((float) t.potX, (float) t.potY, r * 1.5f, ring); }
            }
        }
        ring.setColor(0xFF4FE07A);
        if (hint != null) c.drawCircle((float) hint[0], (float) hint[1], 0.045f * c.getWidth(), ring);
    }

    private static int withAlpha(int color, int a) { return (color & 0x00FFFFFF) | (a << 24); }
}
