package com.carrombot.tool.data;

public class GameConfig {
    public int configVersion = 1;
    public String gameVersion = "1.4.2";
    public double friction = 0.985;
    public double maxSpeed = 80.0;

    public double[] strikerLow = {220, 220, 220};
    public double[] strikerHigh = {255, 255, 255};
    public double[] whiteLow = {200, 200, 190};
    public double[] whiteHigh = {240, 240, 230};
    public double[] blackLow = {10, 10, 10};
    public double[] blackHigh = {60, 60, 60};
    public double[] queenLow = {180, 20, 20};
    public double[] queenHigh = {240, 60, 60};

    public int votesRequired = 2;
    public int durationJitterMin = 100;
    public int durationJitterMax = 150;
    public double angleJitterDeg = 0.1;
    public int reactionDelayMin = 10;
    public int reactionDelayMax = 40;

    public double powerBase = 0.35;     // shot power = base + scale * (path length / board size)
    public double powerScale = 0.45;
    public boolean aimPullBack = false;  // true if the game shoots opposite to the drag (slingshot style)

    public int screenW = 1080;
    public int screenH = 2340;
    public int dpi = 420;
}
