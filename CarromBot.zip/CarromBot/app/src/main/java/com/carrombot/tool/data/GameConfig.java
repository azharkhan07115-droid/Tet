package com.carrombot.tool.data;

public class GameConfig {
    public int configVersion = 1;
    public String gameVersion = "1.4.2";
    public double friction = 0.985;
    public double maxSpeed = 80.0;

    public double[] strikerLow = {220, 220, 220};
    public double[] strikerHigh = {255, 255, 255};
    public double[] whiteLow = {200, 200, 190};
    public double[] whiteHigh = {240, 240, 230};
    public double[] blackLow = {10, 10, 10};
    public double[] blackHigh = {60, 60, 60};
    public double[] queenLow = {180, 20, 20};
    public double[] queenHigh = {240, 60, 60};

    public int votesRequired = 2;
    public int durationJitterMin = 150;
    public int durationJitterMax = 250;
    public double angleJitterDeg = 0.3;
    public int reactionDelayMin = 800;
    public int reactionDelayMax = 1400;

    public int screenW = 1080;
    public int screenH = 2340;
    public int dpi = 420;
}
