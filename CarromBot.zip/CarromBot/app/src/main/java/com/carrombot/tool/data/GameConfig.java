package com.carrombot.tool.data;

public class GameConfig {
    public int configVersion = 1;
    public String gameVersion = "1.4.2";

    // ---- physics (all tunable from the server: config/latest.json) ----
    public double friction = 0.985;      // velocity multiplier per step
    public double restitution = 0.80;    // wall bounce energy kept
    public double maxSpeed = 80.0;       // legacy brute-force search only
    public double rangeL = 3.0;          // distance a FULL power striker rolls, in board lengths
    public double dragFull = 0.222;      // full-power pull length as a fraction of board width
    public double shotMargin = 1.25;     // extra power so the object piece reaches the pocket

    // ---- timing / humanize ----
    public int votesRequired = 2;
    public int durationJitterMin = 180;
    public int durationJitterMax = 260;
    public double angleJitterDeg = 0.1;
    public int reactionDelayMin = 10;
    public int reactionDelayMax = 40;

    /** true = game shoots opposite to the drag (slingshot / pull-back). Carrom Pool does this. */
    public boolean aimPullBack = true;

    public boolean linesEnabled = true;
    public int maxBounces = 6;

    public int screenW = 1080;
    public int screenH = 2340;
    public int dpi = 420;
}
