package com.carrombot.tool.remote;

import com.carrombot.tool.data.GameConfig;
import com.carrombot.tool.data.GameState;
import com.carrombot.tool.data.PieceType;
import com.carrombot.tool.engine.ShotPlanner;
import com.carrombot.tool.data.Piece;
import com.carrombot.tool.data.Shot;
import com.carrombot.tool.util.Log;

import org.json.JSONObject;
import java.util.*;

public class ShotDatabase {
    private final Map<String, Entry> map = new HashMap<>();

    public static class Entry {
        public double angle, power, successRate;
        public long duration;
    }

    public static ShotDatabase parse(String json) {
        ShotDatabase db = new ShotDatabase();
        try {
            JSONObject root = new JSONObject(json);
            JSONObject shots = root.optJSONObject("shots");
            if (shots == null) return db;
            Iterator<String> keys = shots.keys();
            while (keys.hasNext()) {
                String k = keys.next();
                JSONObject s = shots.optJSONObject(k);
                if (s == null) continue;
                JSONObject sh = s.optJSONObject("shot");
                if (sh == null) continue;
                Entry e = new Entry();
                e.angle = sh.optDouble("angle", 0);
                e.power = sh.optDouble("power", 0.5);
                e.duration = sh.optLong("duration_ms", 200);
                e.successRate = s.optDouble("success_rate", 0);
                db.map.put(k, e);
            }
            Log.i("ShotDB: " + db.map.size());
        } catch (Throwable t) { Log.e("DB parse err", t); }
        return db;
    }

    public Shot lookup(GameState state, GameConfig cfg) {
        if (map.isEmpty()) return null;
        Entry e = map.get(generateHash(state));
        if (e == null || e.successRate < 0.85) return null;
        Piece striker = state.striker();
        if (striker == null) return null;
        Shot s = ShotPlanner.makeShot(cfg, state, striker, e.angle, e.power);
        s.durationMs = e.duration;
        s.expectedScore = e.successRate * 10;
        return s;
    }

    /** Board-size independent key: pieces on the 0..1 board grid, rounded to 0.01, sorted, ';' separated. */
    public String generateHash(GameState state) {
        List<String> parts = new ArrayList<>();
        Piece s = state.striker();
        String head = s == null ? "S:none" : "S:" + q(state.nx(s.x)) + "," + q(state.ny(s.y));
        for (Piece p : state.pucks()) {
            char t = p.type == PieceType.MINE ? 'M' : (p.type == PieceType.OPP ? 'O' : 'Q');
            parts.add(t + ":" + q(state.nx(p.x)) + "," + q(state.ny(p.y)));
        }
        Collections.sort(parts);
        StringBuilder sb = new StringBuilder(head);
        for (String x : parts) sb.append(';').append(x);
        return sb.toString();
    }

    public static String q(double v) {
        return String.format(Locale.US, "%.2f", Math.round(v * 100) / 100.0);
    }
}
