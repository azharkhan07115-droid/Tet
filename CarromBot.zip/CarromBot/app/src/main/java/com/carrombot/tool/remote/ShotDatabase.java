package com.carrombot.tool.remote;

import com.carrombot.tool.data.GameState;
import com.carrombot.tool.data.Piece;
import com.carrombot.tool.data.Shot;
import com.carrombot.tool.util.Log;

import org.json.JSONObject;
import java.util.*;

public class ShotDatabase {
    private final Map<String, Entry> map = new HashMap<>();

    public static class Entry {
        public double angle, power, successRate;
        public long duration;
    }

    public static ShotDatabase parse(String json) {
        ShotDatabase db = new ShotDatabase();
        try {
            JSONObject root = new JSONObject(json);
            JSONObject shots = root.optJSONObject("shots");
            if (shots == null) return db;
            Iterator<String> keys = shots.keys();
            while (keys.hasNext()) {
                String k = keys.next();
                JSONObject s = shots.optJSONObject(k);
                if (s == null) continue;
                JSONObject sh = s.optJSONObject("shot");
                if (sh == null) continue;
                Entry e = new Entry();
                e.angle = sh.optDouble("angle", 0);
                e.power = sh.optDouble("power", 0.5);
                e.duration = sh.optLong("duration_ms", 200);
                e.successRate = s.optDouble("success_rate", 0);
                db.map.put(k, e);
            }
            Log.i("ShotDB: " + db.map.size());
        } catch (Throwable t) { Log.e("DB parse err", t); }
        return db;
    }

    public Shot lookup(GameState state) {
        String hash = generateHash(state);
        Entry e = map.get(hash);
        if (e == null || e.successRate < 0.85) return null;
        Piece striker = state.striker();
        if (striker == null) return null;
        double ar = e.angle * Math.PI / 180.0;
        double len = e.power * 400;
        Shot s = new Shot(striker, e.angle, e.power,
            striker.x + Math.cos(ar) * len, striker.y + Math.sin(ar) * len);
        s.durationMs = e.duration;
        s.expectedScore = e.successRate * 10;
        return s;
    }

    public String generateHash(GameState state) {
        StringBuilder sb = new StringBuilder();
        Piece s = state.striker();
        if (s != null) sb.append("S").append(Math.round(s.x*100)).append(",")
            .append(Math.round(s.y*100)).append("|");
        List<Piece> pucks = state.pucks();
        pucks.sort((a, b) -> {
            int c = Double.compare(a.x, b.x);
            return c != 0 ? c : Double.compare(a.y, b.y);
        });
        for (Piece p : pucks) sb.append(p.type.name().charAt(0)).append(":")
            .append(Math.round(p.x*100)).append(",")
            .append(Math.round(p.y*100)).append("|");
        return sb.toString();
    }
}
