package com.carrombot.tool.queue;

import android.content.Context;
import android.graphics.Bitmap;
import com.carrombot.tool.input.InputInjector;
import com.carrombot.tool.util.Log;
import com.carrombot.tool.util.Prefs;
import com.carrombot.tool.vision.ScreenCapture;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

/**
 * Auto queue without touching the phone.
 *  - You teach it ONCE: "Teach queue" = the taps from the lobby to the table you want (Play -> table), and
 *    "Teach after-match" = the taps on the result screen. The first screen of each teaching is remembered.
 *  - Afterwards, whenever the screen looks like the lobby it replays the queue taps, and when it looks like the
 *    result screen it replays the after-match taps. The same table is joined every time.
 */
public class AutoQueue {
    private static AutoQueue instance;
    public static synchronized AutoQueue get() { if (instance == null) instance = new AutoQueue(); return instance; }

    public static final String K_ENABLED = "aq_enabled", K_MODE = "aq_mode";
    private static final String K_QMACRO = "aq_queue_macro", K_RMACRO = "aq_result_macro";
    private static final String K_QSIG = "aq_queue_sig", K_RSIG = "aq_result_sig";
    private static final double THR_LOBBY = 0.11, THR_RESULT = 0.16;

    public static class Step { public float x, y; public long waitMs; Step(float x, float y, long w) { this.x = x; this.y = y; waitMs = w; } }

    private volatile boolean running = false;
    private long lastCheck = 0, lastMacroEnd = 0;
    private int lobbyHits = 0, resultHits = 0;
    private final Random rnd = new Random();
    private volatile String status = "";

    public boolean enabled() { try { return Prefs.getBool(K_ENABLED, false); } catch (Throwable t) { return false; } }
    public void setEnabled(boolean on) { Prefs.putBool(K_ENABLED, on); lobbyHits = resultHits = 0; }
    public boolean fast() { return "FAST".equals(Prefs.getString(K_MODE, "NORMAL")); }
    public String status() { return status; }
    public boolean isRunning() { return running; }

    public int queueSteps() { return load(K_QMACRO).size(); }
    public int resultSteps() { return load(K_RMACRO).size(); }

    // ------------------------------------------------------------------ teaching
    /** kind = "queue" or "result". taps = {xRel, yRel, waitAfterMs}. sig = fingerprint of the screen at the start. */
    public void saveTeaching(String kind, List<float[]> taps, byte[] sig) {
        JSONArray a = new JSONArray();
        try {
            for (float[] t : taps) a.put(new JSONObject().put("x", t[0]).put("y", t[1]).put("w", (long) t[2]));
        } catch (Throwable ignored) { }
        boolean q = "queue".equals(kind);
        Prefs.putString(q ? K_QMACRO : K_RMACRO, a.toString());
        if (sig != null) Prefs.putString(q ? K_QSIG : K_RSIG, ScreenSig.encode(sig));
        Log.i("auto queue taught " + kind + ": " + taps.size() + " taps");
    }

    private List<Step> load(String key) {
        List<Step> out = new ArrayList<>();
        try {
            JSONArray a = new JSONArray(Prefs.getString(key, "[]"));
            for (int i = 0; i < a.length(); i++) {
                JSONObject o = a.getJSONObject(i);
                out.add(new Step((float) o.getDouble("x"), (float) o.getDouble("y"), o.optLong("w", 1200)));
            }
        } catch (Throwable ignored) { }
        return out;
    }

    // ------------------------------------------------------------------ running
    /**
     * Called by the engine while no match is being played. Cheap (a fingerprint every 0.4 s).
     * @return true when it did something (the engine should simply continue its loop)
     */
    public boolean step(Bitmap frame) {
        if (!enabled() || frame == null || running) return false;
        long now = System.currentTimeMillis();
        if (now - lastMacroEnd < 6000) { status = "Auto queue: waiting for the game..."; return false; }
        if (now - lastCheck < 400) return false;
        lastCheck = now;

        byte[] qs = ScreenSig.decode(Prefs.getString(K_QSIG, ""));
        byte[] rs = ScreenSig.decode(Prefs.getString(K_RSIG, ""));
        if (qs == null && rs == null) { status = "Auto queue: teach it first (menu)"; return false; }
        byte[] cur = ScreenSig.of(frame, ScreenCapture.getWidth(), ScreenCapture.getHeight());
        double dq = qs == null ? 1 : ScreenSig.dist(cur, qs);
        double dr = rs == null ? 1 : ScreenSig.dist(cur, rs);

        if (dq < THR_LOBBY && dq <= dr) { lobbyHits++; resultHits = 0; }
        else if (dr < THR_RESULT) { resultHits++; lobbyHits = 0; }
        else { lobbyHits = resultHits = 0; status = "Auto queue: watching..."; return false; }

        if (lobbyHits >= 2 && queueSteps() > 0) { lobbyHits = 0; play(load(K_QMACRO), "Joining the table..."); return true; }
        if (resultHits >= 2 && resultSteps() > 0) { resultHits = 0; play(load(K_RMACRO), "Leaving the result screen..."); return true; }
        return false;
    }

    private void play(List<Step> steps, String label) {
        running = true;
        status = "Auto queue: " + label;
        try {
            int w = ScreenCapture.getWidth(), h = ScreenCapture.getHeight();
            double factor = fast() ? 0.55 : 1.0;
            for (Step s : steps) {
                float jx = (float) ((rnd.nextDouble() - 0.5) * 6), jy = (float) ((rnd.nextDouble() - 0.5) * 6);
                InputInjector.get().tap(s.x * w + jx, s.y * h + jy);
                long wait = (long) (s.waitMs * factor) + (fast() ? 0 : rnd.nextInt(350));
                Thread.sleep(Math.max(250, wait));
            }
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        } catch (Throwable t) { Log.e("auto queue", t); }
        running = false;
        lastMacroEnd = System.currentTimeMillis();
    }
}
