package com.carrombot.tool.service;

import android.accessibilityservice.AccessibilityService;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;
import android.view.accessibility.AccessibilityWindowInfo;
import com.carrombot.tool.input.InputInjector;
import com.carrombot.tool.util.Constants;
import com.carrombot.tool.util.Log;

import java.util.List;

public class AutoAccessibilityService extends AccessibilityService {

    private static volatile String currentPackage = "";
    private static volatile long lastUpdate = 0;
    private static volatile AutoAccessibilityService instance;
    private static volatile boolean cachedForeground = false;
    private static volatile long cachedAt = 0;

    @Override public void onServiceConnected() {
        super.onServiceConnected();
        instance = this;
        InputInjector.setService(this);
        Log.i("A11y connected");
    }

    @Override public void onAccessibilityEvent(AccessibilityEvent e) {
        if (e == null) return;
        int t = e.getEventType();
        if (t == AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED
            || t == AccessibilityEvent.TYPE_WINDOWS_CHANGED) {
            if (e.getPackageName() != null) {
                String pkg = e.getPackageName().toString();
                // our own overlay (menu / lines) and system UI must NOT replace the game package
                if (pkg.equals(getPackageName()) || pkg.equals("com.android.systemui")) return;
                if (!pkg.equals(currentPackage)) {
                    currentPackage = pkg;
                    lastUpdate = System.currentTimeMillis();
                    Log.d("Foreground: " + pkg);
                }
            }
        }
    }

    @Override public void onInterrupt() {
        InputInjector.setService(null);
        currentPackage = "";
    }

    @Override public boolean onUnbind(android.content.Intent i) {
        InputInjector.setService(null);
        instance = null;
        currentPackage = "";
        return super.onUnbind(i);
    }

    public static String getCurrentPackage() { return currentPackage; }
    public static long getLastUpdate() { return lastUpdate; }

    /** TRUE when Carrom Pool has a visible window (checked via window list, cached 300 ms). */
    public static boolean isTargetAppForeground() {
        long now = System.currentTimeMillis();
        if (now - cachedAt < 300) return cachedForeground;
        boolean fg = Constants.TARGET_PACKAGE.equals(currentPackage);
        AutoAccessibilityService s = instance;
        if (s != null) {
            try {
                List<AccessibilityWindowInfo> ws = s.getWindows();
                if (ws != null) {
                    for (AccessibilityWindowInfo w : ws) {
                        if (w.getType() != AccessibilityWindowInfo.TYPE_APPLICATION) continue;
                        AccessibilityNodeInfo root = w.getRoot();
                        if (root == null) continue;
                        CharSequence pn = root.getPackageName();
                        root.recycle();
                        if (pn != null && Constants.TARGET_PACKAGE.contentEquals(pn)) { fg = true; break; }
                    }
                }
            } catch (Throwable ignored) {}
        }
        cachedForeground = fg;
        cachedAt = now;
        return fg;
    }
}
