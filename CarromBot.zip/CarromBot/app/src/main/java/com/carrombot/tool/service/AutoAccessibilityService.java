package com.carrombot.tool.service;

import android.accessibilityservice.AccessibilityService;
import android.accessibilityservice.AccessibilityServiceInfo;
import android.os.Build;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;
import android.view.accessibility.AccessibilityWindowInfo;
import com.carrombot.tool.input.InputInjector;
import com.carrombot.tool.util.Constants;
import com.carrombot.tool.util.Log;
import com.carrombot.tool.util.Prefs;

import java.util.List;

public class AutoAccessibilityService extends AccessibilityService {

    private static volatile String currentPackage = "";
    private static volatile long lastUpdate = 0;
    private static volatile AutoAccessibilityService instance;
    private static volatile boolean cachedForeground = false;
    private static volatile long cachedAt = 0;

    @Override public void onServiceConnected() {
        super.onServiceConnected();
        instance = this;
        InputInjector.setService(this);
        updateGestureFlags();
        Log.i("A11y connected");
    }

    /** Android 11+ system gesture. No touch-blocking overlay is used. */
    @Override protected boolean onGesture(int gestureId) {
        if (Build.VERSION.SDK_INT >= 30
            && gestureId == GESTURE_3_FINGER_SINGLE_TAP
            && Prefs.getBool(Constants.PREF_THREE_FINGER_MENU, false)) {
            OverlayService.requestMenuToggle();
            return true;
        }
        return super.onGesture(gestureId);
    }

    public static void setThreeFingerEnabled(boolean enabled) {
        AutoAccessibilityService s = instance;
        if (s != null) s.updateGestureFlags();
    }

    private void updateGestureFlags() {
        if (Build.VERSION.SDK_INT < 30) return;
        try {
            AccessibilityServiceInfo info = getServiceInfo();
            if (info == null) return;
            final int gestureFlags = AccessibilityServiceInfo.FLAG_REQUEST_TOUCH_EXPLORATION_MODE
                | AccessibilityServiceInfo.FLAG_REQUEST_MULTI_FINGER_GESTURES;
            if (Prefs.getBool(Constants.PREF_THREE_FINGER_MENU, false)) {
                info.flags |= gestureFlags;
                if (Build.VERSION.SDK_INT >= 31)
                    info.flags |= AccessibilityServiceInfo.FLAG_REQUEST_2_FINGER_PASSTHROUGH;
            } else {
                info.flags &= ~gestureFlags;
                if (Build.VERSION.SDK_INT >= 31)
                    info.flags &= ~AccessibilityServiceInfo.FLAG_REQUEST_2_FINGER_PASSTHROUGH;
            }
            setServiceInfo(info);
        } catch (Throwable t) { Log.e("3-finger config", t); }
    }

    @Override public void onAccessibilityEvent(AccessibilityEvent e) {
        if (e == null) return;
        int t = e.getEventType();
        if (t == AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED
            || t == AccessibilityEvent.TYPE_WINDOWS_CHANGED) {
            if (e.getPackageName() != null) {
                String pkg = e.getPackageName().toString();
                // our own overlay (menu / lines) and system UI must NOT replace the game package
                if (pkg.equals(getPackageName()) || pkg.equals("com.android.systemui")) return;
                if (!pkg.equals(currentPackage)) {
                    currentPackage = pkg;
                    lastUpdate = System.currentTimeMillis();
                    Log.d("Foreground: " + pkg);
                }
            }
        }
    }

    @Override public void onInterrupt() {
        InputInjector.setService(null);
        currentPackage = "";
    }

    @Override public boolean onUnbind(android.content.Intent i) {
        InputInjector.setService(null);
        instance = null;
        currentPackage = "";
        return super.onUnbind(i);
    }

    public static String getCurrentPackage() { return currentPackage; }
    public static long getLastUpdate() { return lastUpdate; }

    /** TRUE when Carrom Pool has a visible window (checked via window list, cached 300 ms). */
    public static boolean isTargetAppForeground() {
        long now = System.currentTimeMillis();
        if (now - cachedAt < 300) return cachedForeground;
        boolean fg = Constants.TARGET_PACKAGE.equals(currentPackage);
        AutoAccessibilityService s = instance;
        if (s != null) {
            try {
                List<AccessibilityWindowInfo> ws = s.getWindows();
                if (ws != null) {
                    for (AccessibilityWindowInfo w : ws) {
                        if (w.getType() != AccessibilityWindowInfo.TYPE_APPLICATION) continue;
                        AccessibilityNodeInfo root = w.getRoot();
                        if (root == null) continue;
                        CharSequence pn = root.getPackageName();
                        root.recycle();
                        if (pn != null && Constants.TARGET_PACKAGE.contentEquals(pn)) { fg = true; break; }
                    }
                }
            } catch (Throwable ignored) {}
        }
        cachedForeground = fg;
        cachedAt = now;
        return fg;
    }
}
