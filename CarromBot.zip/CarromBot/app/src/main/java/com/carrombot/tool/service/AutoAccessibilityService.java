package com.carrombot.tool.service;

import android.accessibilityservice.AccessibilityService;
import android.view.accessibility.AccessibilityEvent;
import com.carrombot.tool.input.InputInjector;
import com.carrombot.tool.util.Constants;
import com.carrombot.tool.util.Log;

public class AutoAccessibilityService extends AccessibilityService {

    private static volatile String currentPackage = "";
    private static volatile long lastUpdate = 0;

    @Override public void onServiceConnected() {
        super.onServiceConnected();
        InputInjector.setService(this);
        Log.i("A11y connected");
    }

    @Override public void onAccessibilityEvent(AccessibilityEvent e) {
        if (e == null) return;
        int t = e.getEventType();
        if (t == AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED
            || t == AccessibilityEvent.TYPE_WINDOWS_CHANGED) {
            if (e.getPackageName() != null) {
                String pkg = e.getPackageName().toString();
                if (!pkg.equals(currentPackage)) {
                    currentPackage = pkg;
                    lastUpdate = System.currentTimeMillis();
                    Log.d("Foreground: " + pkg);
                }
            }
        }
    }

    @Override public void onInterrupt() {
        InputInjector.setService(null);
        currentPackage = "";
    }

    @Override public boolean onUnbind(android.content.Intent i) {
        InputInjector.setService(null);
        currentPackage = "";
        return super.onUnbind(i);
    }

    public static String getCurrentPackage() { return currentPackage; }
    public static long getLastUpdate() { return lastUpdate; }

    /** TRUE only when Carrom Pool is foreground. */
    public static boolean isTargetAppForeground() {
        return Constants.TARGET_PACKAGE.equals(currentPackage);
    }
}
