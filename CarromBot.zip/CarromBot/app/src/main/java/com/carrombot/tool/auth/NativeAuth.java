package com.carrombot.tool.auth;

import com.carrombot.tool.vision.NativeVision;

/** License session kept in C++ (libcarromvision.so). The planner / physics / vision refuse to run while it is locked. */
public class NativeAuth {
    static { NativeVision.isLoaded(); }   // loads the library

    public static native String serial(String userKey, String androidId, String model, String brand);
    public static native boolean hasSecret();
    /** @return {timestamp, signature} or null when no real client secret is built in (then V1 is used) */
    public static native String[] sign(String endpoint, String body);
    /** License server URL - stored encrypted in the .so, decrypted only right before the request. */
    public static native String url();
    /** 1 = unlocked, -2 = token mismatch (fake server), -3 = stale answer, -5 = expired, other <0 = malformed */
    public static native int complete(String userKey, String game, String token, String serial, long rng, long remainingSeconds);
    public static native boolean healthy(String hwid);
    public static native boolean isUnlocked();
    public static native void lock();
}
