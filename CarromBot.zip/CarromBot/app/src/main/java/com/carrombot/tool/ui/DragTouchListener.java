package com.carrombot.tool.ui;

import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;

public class DragTouchListener implements View.OnTouchListener {
    private final WindowManager wm;
    private final View view;
    private final WindowManager.LayoutParams lp;
    private int initX, initY;
    private float rawX, rawY;
    private boolean moved;

    public DragTouchListener(WindowManager wm, View v, WindowManager.LayoutParams lp) {
        this.wm = wm; this.view = v; this.lp = lp;
    }
    @Override public boolean onTouch(View v, MotionEvent e) {
        switch (e.getActionMasked()) {
            case MotionEvent.ACTION_DOWN:
                initX = lp.x; initY = lp.y;
                rawX = e.getRawX(); rawY = e.getRawY();
                moved = false; return false;
            case MotionEvent.ACTION_MOVE:
                int dx = (int)(e.getRawX() - rawX);
                int dy = (int)(e.getRawY() - rawY);
                if (Math.abs(dx) > 8 || Math.abs(dy) > 8) moved = true;
                lp.x = initX + dx; lp.y = initY + dy;
                wm.updateViewLayout(view, lp);
                return true;
            case MotionEvent.ACTION_UP: return moved;
        }
        return false;
    }
}
