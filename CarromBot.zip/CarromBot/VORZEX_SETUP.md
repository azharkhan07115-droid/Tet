# VORZEX ENGINE - setup notes

## 1. Your icon
Replace this ONE file with your real icon.png (square, 512x512 is good):

    app/src/main/res/drawable-nodpi/icon.png

It is used for the app icon and for the floating bubble - nowhere else.
(A temporary placeholder icon is included because icon.png was not in the upload.)

## 2. License login (Sarkar API)
* Endpoint: `Constants.LICENSE_URL` (already your supabase `/connect` URL).
* The V2 HMAC signature needs your real CLIENT_AUTH_SECRET. Put it, split in 3-4 pieces, in
  `app/src/main/cpp/SecureLogin.h` -> `BuildSecret()`  (p1..p4).
  Until then the app uses the V1 static signature (`X-Client-Signature: SARKAR-CPP-V1`), which the
  guide says will be switched off after the transition period.
* Serial = SHA256(user_key + android_id + model + brand)  (exactly like the guide).
* Public-key pinning: `Constants.PIN_ENFORCE` (false by default). Turn it on only after you checked that the
  pin matches the live certificate chain, otherwise nobody can log in.

## 3. How it works
Play -> key dialog (first time, then saved) -> server verifies -> permissions -> floating menu opens ->
game opens. Swiping the app away from recents closes the floating menu. The vision / physics / planner are in
C++ and refuse to run unless the license session is valid (re-checked every 10 minutes).
